import { isMediaUrl } from './engine.js';

// Passive MV3 observation only. No response-body copies, cookies, or uploads.
export function attachRequestObserver({ getState, recover, publish, rescan }) {
  const requests = new Map();
  const filter = { urls: ['https://*.bilivideo.com/*', 'https://*.mcdn.bilivideo.cn/*',
    'https://upos-hz-mirrorakam.akamaized.net/*'] };
  const valid = details => details.tabId >= 0 && isMediaUrl(details.url);
  const before = details => {
    if (!valid(details)) return;
    const state = getState(details.tabId);
    if (!state) { rescan(details.tabId); return; }
    const path = new URL(details.url).pathname;
    if (state.trackKinds.get(path) !== 'video' || path !== state.observedVideoPath) return;
    if (requests.size >= 512) requests.delete(requests.keys().next().value);
    requests.set(details.requestId, { state, tabId: details.tabId, path, started: details.timeStamp,
      host: new URL(details.url).hostname });
  };
  const response = details => {
    const request = requests.get(details.requestId);
    if (!request || getState(request.tabId) !== request.state || request.path !== request.state.observedVideoPath) return;
    request.host = new URL(details.url).hostname;
    request.status = details.statusCode;
    request.ttfbMs = Math.max(0, details.timeStamp-request.started);
    request.cached = details.fromCache === true;
    request.state.actualHost = request.host;
    request.state.actualHostSource = 'network-response';
  };
  const finish = async (details, error = false) => {
    const request = requests.get(details.requestId);
    requests.delete(details.requestId);
    if (!request || getState(request.tabId) !== request.state || request.path !== request.state.observedVideoPath) return;
    const cancelled = error && /(?:ERR_ABORTED|ABORT_ERR|AbortError)/i.test(details.error || '');
    const failed = !cancelled && (error || request.status >= 400);
    // HTTP completion proves reachability, not adequate video throughput.
    // It must not resurrect a host rejected by the current-video probe.
    const previous = request.state.requestEvidence || { completed:0, failed:0, cacheHits:0 };
    request.state.requestEvidence = { completed:previous.completed + Number(!failed && !cancelled), failed:previous.failed + Number(failed),
      cancelled:(previous.cancelled || 0) + Number(cancelled),
      cacheHits:previous.cacheHits + Number(request.cached === true),
      lastStatus:request.status || 0, ttfbMs:request.ttfbMs || 0, lastAt:Date.now() };
    // An older request can finish after a replacement route has started (or
    // has just been selected). Preserve its failure statistic, but never let
    // that old transfer cancel recovery or condemn the new destination.
    const currentFailure = () => getState(request.tabId) === request.state
      && request.path === request.state.observedVideoPath
      && (!request.state.actualHost || request.state.actualHost === request.host)
      && (!request.state.selectedHost || request.state.selectedHost === request.host);
    if (failed && currentFailure()) {
      // Cancelled quality switches/seeks/pauses are not CDN failures.
      let timer;
      const snapshot = await Promise.race([
        chrome.tabs.sendMessage(request.tabId, {type:'get-playback-info'}).catch(() => null),
        new Promise(resolve => { timer=setTimeout(() => resolve(null), 500); }),
      ]).finally(() => clearTimeout(timer));
      const playback = snapshot?.playback;
      if (currentFailure()
        && playback?.hasVideo && ['buffering','stalled','error'].includes(playback.status)
        && Number.isFinite(playback.bufferedAhead) && playback.bufferedAhead < 8) {
        await recover(request.tabId, error ? 'request-error' : `http-${request.status}`,
          { host:request.host, path:request.path });
      }
    }
    if (getState(request.tabId) === request.state) await publish(request.tabId);
  };
  chrome.webRequest?.onBeforeRequest?.addListener(before, filter);
  chrome.webRequest?.onResponseStarted?.addListener(response, filter);
  chrome.webRequest?.onCompleted?.addListener(details => { finish(details).catch(() => {}); }, filter);
  chrome.webRequest?.onErrorOccurred?.addListener(details => { finish(details,true).catch(() => {}); }, filter);
  return { before, response, finish, clear(tabId) {
    for (const [id, item] of requests) if (item.tabId === tabId) requests.delete(id);
  }};
}
