import { isCdnTargetHost, rankResults, sanitizeBenchmarkCache } from './engine.js';

// This seed was already present in our MIT catalog; priority is based on our own playback evidence.
export const PREFERRED_ROUTE = 'upos-sz-mirror08ct.bilivideo.com';
// A completed real transfer below the bitrate safety margin is not a hard
// failure of the same host for another video's file. It still earns no winner
// or verification status; this exception affects only the next-video seed.
export function completedPlaybackBelowMargin(r) {
  return r?.ok === false && r.stage === 'playback'
    && Number.isInteger(r.status) && r.status >= 200 && r.status < 300
    && Number.isFinite(r.bytes) && r.bytes >= 1024 * 1024;
}
export function initialRoute(settings, cache, networkKey='') {
  if(!settings.enabled||settings.mode==='original')return '';
  const disabled=new Set(settings.disabledHosts||[]);
  if(settings.mode==='manual')return isCdnTargetHost(settings.manualHost)&&!disabled.has(settings.manualHost)?settings.manualHost:'';
  const safe=sanitizeBenchmarkCache(cache);
  const qualified=(!safe.networkKey||!networkKey||safe.networkKey===networkKey)
    ? rankResults(safe.results.filter(r=>r.fullSampledAt&&!disabled.has(r.host))) : [];
  const learned=qualified.find(r=>r.host===safe.winnerHost)||qualified[0];
  const failed=(!safe.networkKey||!networkKey||safe.networkKey===networkKey)
    &&safe.results.some(r=>r.host===PREFERRED_ROUTE&&!r.ok&&!completedPlaybackBelowMargin(r));
  return learned&&!disabled.has(learned.host)?learned.host:disabled.has(PREFERRED_ROUTE)||failed?'':PREFERRED_ROUTE;
}
