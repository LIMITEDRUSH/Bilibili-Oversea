import { replaceMediaHost, sampleCapacityKbps } from "./engine.js";

export const PROBE_REFERRER_RULE_ID = 900_000;

export function probeReferrerRule(extensionId) {
  if (!/^[a-p]{32}$/.test(extensionId || "")) throw new TypeError("invalid extension id");
  return {
    id: PROBE_REFERRER_RULE_ID,
    priority: 1,
    action: { type: "modifyHeaders", requestHeaders: [{ header: "referer", operation: "set", value: "https://www.bilibili.com/" }] },
    condition: { initiatorDomains: [extensionId], requestDomains: ["bilivideo.com"], regexFilter: "^https?://[^/]+/upgcxcode/", resourceTypes: ["xmlhttprequest"] },
  };
}

// Worker fetches have no playback tab id, so tab-scoped redirect rules cannot
// route one candidate's probe through another. No cookies or signed URL edits.
export async function fetchProbe({ sourceUrl, host, byteLimit, signal, startByte = 0, sampleSegments = 1 }) {
  if (sampleSegments !== 2) return fetchRangeProbe({sourceUrl,host,byteLimit,signal,startByte});
  const limit=Math.min(1024*1024,Math.max(2,Number(byteLimit)||128*1024));
  const offset=Number.isSafeInteger(startByte) && startByte>=0 && startByte<=2**40 ? startByte : 0;
  const started=performance.now(), firstLimit=Math.floor(limit/2), secondLimit=limit-firstLimit;
  const first=await fetchRangeProbe({sourceUrl,host,byteLimit:firstLimit,signal,startByte:offset});
  if (!first.ok || first.bytes<firstLimit || signal?.aborted) return {...first,ok:false,error:first.error || 'incomplete startup sample'};
  // A hot initialization prefix is not proof the next video segment exists
  // in this CDN's cache. Keep the SAME total byte/deadline budget, but sample
  // a second non-overlapping range. Never clone or alter the signed URL.
  const total=first.resourceBytes;
  const nextOffset=total ? Math.min(offset+512*1024,total-secondLimit) : offset+512*1024;
  if (nextOffset<offset+firstLimit || nextOffset>2**40) return {...first,ok:false,error:'incomplete startup sample'};
  const second=await fetchRangeProbe({sourceUrl,host,byteLimit:secondLimit,signal,startByte:nextOffset});
  const bytes=first.bytes+second.bytes, elapsedMs=performance.now()-started, headerWaitMs=first.ttfbMs+second.ttfbMs;
  return {host,responseHost:second.responseHost,ok:second.ok && second.bytes===secondLimit,status:second.status,
    bytes,elapsedMs,ttfbMs:first.ttfbMs,headerWaitMs,capacityKbps:sampleCapacityKbps(bytes,elapsedMs,headerWaitMs),sampleSegments:2,
    error:second.ok && second.bytes===secondLimit ? '' : second.error || 'incomplete startup sample'};
}

async function fetchRangeProbe({ sourceUrl, host, byteLimit, signal, startByte = 0 }) {
  const target = replaceMediaHost(sourceUrl, host);
  const limit = Math.min(1024 * 1024, Math.max(1, Number(byteLimit) || 128 * 1024));
  const offset = Number.isSafeInteger(startByte) && startByte >= 0 && startByte <= 2 ** 40 ? startByte : 0;
  const started = performance.now();
  let ttfbMs = 0;
  try {
    const response = await fetch(target, { cache: "no-store", credentials: "omit", headers: { Range: `bytes=${offset}-${offset + limit - 1}` }, signal });
    ttfbMs = performance.now() - started;
    const responseHost = response.url ? new URL(response.url).hostname : host;
    const contentType=String(response.headers?.get?.('content-type') || '');
    const range=String(response.headers?.get?.('content-range') || '').match(/^bytes (\d+)-(\d+)\/(\d+|\*)/i);
    const invalidBody=/text\/|json|html/i.test(contentType)
      || (response.status===206 && range && Number(range[1])!==offset)
      || (offset>0 && (response.status!==206 || !range));
    if (responseHost !== host || !response.ok || invalidBody) {
      await response.body?.cancel().catch(() => {});
      return { host, responseHost, ok: false, status: response.status, bytes: 0, elapsedMs: performance.now() - started, ttfbMs, error: invalidBody ? 'not a matching media range' : responseHost !== host ? "probe redirected to another CDN" : `HTTP ${response.status}` };
    }
    let bytes = 0;
    if (response.body) {
      const reader = response.body.getReader();
      try {
        while (bytes < limit) {
          const part = await reader.read();
          if (part.done) break;
          bytes += part.value?.byteLength || 0;
        }
      } finally { await reader.cancel().catch(() => {}); }
    }
    const sampledBytes = Math.min(bytes, limit), elapsedMs = performance.now() - started;
    return { host, responseHost, ok: bytes > 0, status: response.status, bytes: sampledBytes, elapsedMs, ttfbMs,
      resourceBytes:range && Number.isSafeInteger(Number(range[3])) ? Number(range[3]) : 0,
      capacityKbps: sampleCapacityKbps(sampledBytes, elapsedMs, ttfbMs) };
  } catch (error) {
    return { host, ok: false, status: 0, bytes: 0, elapsedMs: performance.now() - started, ttfbMs, error: error?.name === "AbortError" ? "cancelled or timed out" : "probe network error" };
  }
}
