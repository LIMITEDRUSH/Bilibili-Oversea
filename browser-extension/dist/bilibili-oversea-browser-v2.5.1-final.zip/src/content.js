(() => {
  "use strict";

  const SOURCE = "bili-cdn-auto-page-v2";
  const DISCOVERY_INTERVAL_MS = 10_000;
  const HEALTH_SAMPLE_INTERVAL_MS = 2_000;
  const FRAME_SAMPLE_INTERVAL_MS = 500;
  const FRAME_STALL_MS = 2_000;
  const STALL_CONFIRM_MS = 1_200;
  const STALL_COOLDOWN_MS = 8_000;
  const STARTUP_GRACE_MS = 10_000;
  const SEEK_GRACE_MS = 4_000;
  const HEALTHY_BUFFER_SECONDS = 12;
  const LOW_BUFFER_SECONDS = 8;
  const MIN_BUFFER_DRAIN_SECONDS = 4;
  const HEALTH_WINDOW_SAMPLES = 4;
  const MAX_PROBE_BYTES = 1024 * 1024;
  const MAX_PROBE_TIMEOUT_MS = 15_000;
  const discoveredUrls = new Set();
  const observedResourceUrls = new Set();
  const observedResponseUrls = new Set();
  const observedRequestUrls = new Set();
  const seenResourceEntries = new Set();
  const reportSignatures = new Map();
  const bufferHistory = [];
  const trackKinds = new Map();
  const trackBackups = new Map();
  const trackRates = new Map();
  let startupDeadline = 0;
  let routeConfiguration = null;
  let configurationReady = null;
  let preparedRouteHost = '';
  let lastRoutePolicyKey = '';
  let appliedRouteHost = '';
  let lastRoutedAudio = null, lastAudioRequestOrder = 0;
  let resumeGeneration = 0;
  const routePolicyWaiters = new Set();
  const startupTimeoutReports = new Set();
  let lastRoutedVideo = null;
  function clearStartupBindings() { lastRoutedAudio = null; lastRoutedVideo = null; }
  function publishRoutePolicy(settings, state={}) {
    if (!settings) return;
    routeConfiguration = settings;
    const preferred='upos-sz-mirror08ct.bilivideo.com';
    const host=settings.mode==='manual' ? settings.manualHost : state.routeHost !== undefined ? state.routeHost : preferred;
    const enabled=settings.enabled !== false && settings.mode !== 'original';
    const automatic=enabled && (!settings.mode || settings.mode==='auto');
    if(!automatic)clearStartupBindings();
    const routeHost=(settings.disabledHosts||[]).includes(host)?'':host||'';
    preparedRouteHost=enabled?routeHost:'';
    const key=JSON.stringify([playbackPageKey(location.href),enabled,automatic,routeHost]);
    if(key!==lastRoutePolicyKey){lastRoutePolicyKey=key;clearStartupBindings();send({type:'route-prepared',enabled,host:routeHost,pageUrl:location.href,networkKey:connectionSignature()});}
    window.postMessage({source:SOURCE,type:'route-policy',pageUrl:location.href,
      enabled,automatic,host:routeHost},location.origin);
  }
  const mediaOriginals = new Map();
  const probeControllers = new Set();
  let probeGeneration = 0;
  let nextProbeId = 0;
  let navigationResourceTime = 0;
  let activeVideo = null;
  let videoStartedAt = 0;
  let healthArmed = false;
  let userPaused = false, hasPlayed = false, pagePlaybackObserved = false;
  let lastSeekAt = 0;
  let seekEpisodeAt = 0, seekEpisodeFrames = null;
  let lastUserInteractionAt = 0;
  let userSeek = false;
  let lastStallAt = 0;
  let stallTimer = 0;
  let healthTimer = 0;
  let frameTimer = 0;
  let recoveryTimer = 0;
  let recoveryVideo = null;
  let lastRecoveryAt = 0;
  let progressTime = 0;
  let progressAt = 0;
  let displayedFrames = null;
  let frameProgressAt = 0;
  let lastUrl = playbackPageKey(location.href);
  const watchedVideos = new WeakSet();
  const discoveredCandidateHosts = new Set();

  function playbackPageKey(value) {
    try {
      const url = new URL(value);
      // Only video identity/part matters; tracking, time links and hash do not.
      const identity = url.pathname.replace(/\/$/, "");
      const part = Math.max(1, Number.parseInt(url.searchParams.get("p"), 10) || 1);
      return `${url.origin}${identity}?p=${part}&ep_id=${url.searchParams.get("ep_id") || ""}`;
    } catch { return String(value); }
  }

  // Read-only popup telemetry. No timer, network request, or routing message.
  const displayVideos = new WeakMap();
  let displayPage = playbackPageKey(location.href);
  let displayPreviousVideo = null;
  let displayPreviousSource = "";
  let displayNavigationPending = false;

  function displayVideo() {
    const videos = document.querySelectorAll ? [...document.querySelectorAll("video")]
      : [document.querySelector("video")].filter(Boolean);
    const primary = videos.filter(video => video.closest?.("#bilibili-player, #bilibiliPlayer, .bpx-player-container, .bilibili-player, .bilibili-player-video"));
    const pool = primary.length ? primary : videos;
    if (pool.length < 2) return pool[0] || null;
    return pool.sort((a, b) => {
      const score = video => {
        const rect = video.getBoundingClientRect?.() || {};
        const main = video.closest?.("#bilibili-player, #bilibiliPlayer, .bpx-player-container, .bilibili-player, .bilibili-player-video, .player-container");
        return (main ? 1e9 : 0) + Math.max(0, rect.width || 0) * Math.max(0, rect.height || 0);
      };
      return score(b) - score(a);
    })[0] || null;
  }

  function readPlaybackInfo() {
    const video = displayVideo();
    const source = String(video?.currentSrc || video?.src || "");
    const pageKey = playbackPageKey(location.href);
    if (displayPage !== pageKey) {
      displayPage = pageKey;
      displayNavigationPending = Boolean(video && video === displayPreviousVideo && source === displayPreviousSource
        && displayVideos.get(video)?.page !== displayPage);
      const old = video && displayVideos.get(video);
      if (old && displayNavigationPending) { old.status = "loading"; old.lastTime = Number(video.currentTime) || 0; }
    }
    const heading = document.querySelector("h1.video-title, .video-info-title, h1.media-title, .mediainfo_mediaTitle__yejlB");
    const title = String(heading?.getAttribute?.("title") || heading?.textContent || document.title || "")
      .replace(/[_\s-]*(?:哔哩哔哩|bilibili)(?:_.*)?$/i, "").trim().slice(0, 240);
    const candidateHosts = [...new Set([...discoveredCandidateHosts, ...[...discoveredUrls, ...observedRequestUrls, ...observedResourceUrls, ...observedResponseUrls]
      .filter(isMediaUrl).map(url => new URL(url).hostname)])].slice(0, 12);
    const result = { sampledAt: Date.now(), hasVideo: Boolean(video), title, status: "empty", candidateHosts };
    if (!video) { displayPreviousVideo = null; displayPreviousSource = ""; return result; }
    let display = displayVideos.get(video);
    if (!display) {
      display = { status: "loading", lastTime: Number(video.currentTime) || 0, lastAdvanceAt: Date.now(),
        lastFrames: displayedFrameCount(video), lastFrameAdvanceAt: Date.now(), page: displayPage };
      displayVideos.set(video, display);
      for (const name of ["playing", "waiting", "stalled", "pause", "ended", "seeking", "error", "loadstart", "emptied", "loadedmetadata", "timeupdate"]) {
        video.addEventListener(name, () => {
          // Ignore detached display sessions after a navigation.
          if (displayVideos.get(video) !== display || displayVideo() !== video) return;
          if (["playing", "pause", "ended", "seeking", "loadstart", "emptied", "loadedmetadata"].includes(name)) {
            display.lastFrames = displayedFrameCount(video);
            display.lastFrameAdvanceAt = Date.now();
          }
          if (name === "loadedmetadata" || name === "loadstart" || name === "emptied") {
            displayNavigationPending = false;
            display.page = playbackPageKey(location.href);
            display.status = "loading";
          } else if (name === "playing") {
            displayNavigationPending = false;
            display.page = playbackPageKey(location.href);
            display.status = "playing";
            display.lastAdvanceAt = Date.now();
          }
          else if (name === "waiting" || name === "stalled") display.status = "buffering";
          else if (name === "timeupdate") {
            if (Number(video.currentTime) > display.lastTime && !video.paused && !video.seeking) {
              display.status = "playing";
              display.lastAdvanceAt = Date.now();
            }
          } else display.status = name === "pause" ? "paused" : name;
        });
      }
    }
    if (displayNavigationPending && (video !== displayPreviousVideo || source !== displayPreviousSource)) displayNavigationPending = false;
    if (displayNavigationPending) return { ...result, hasVideo: false, status: "loading", title: "正在加载视频" };
    const currentTime = Number(video.currentTime);
    const moving = Number.isFinite(currentTime) && currentTime > display.lastTime && currentTime - display.lastTime < 5;
    if (moving) display.lastAdvanceAt = Date.now();
    const frames = displayedFrameCount(video), ahead = bufferedAhead(video);
    const frameMoving = frames !== null && display.lastFrames !== null && frames > display.lastFrames;
    if (frames === null || display.lastFrames === null || frames !== display.lastFrames
      || video.paused || video.seeking || video.ended || document.hidden) display.lastFrameAdvanceAt = Date.now();
    display.lastFrames = frames;
    const nearEnd = Number.isFinite(video.duration) && video.duration > 0 && currentTime >= video.duration - .5;
    const frameStarved = frames > 0 && !document.hidden && !nearEnd && ahead < .5
      && Date.now() - display.lastFrameAdvanceAt >= FRAME_STALL_MS;
    const status = video.error ? "error" : video.ended ? "ended" : video.seeking ? "seeking"
      : video.paused ? "paused" : Number(video.readyState) < 3 || frameStarved ? "buffering"
      : moving || frameMoving ? "playing" : display.status === "playing" && Date.now() - display.lastAdvanceAt > 2500 ? "stalled" : display.status;
    display.lastTime = currentTime;
    display.status = status;
    displayPreviousVideo = video;
    displayPreviousSource = source;
    return { ...result, status, currentTime, duration: Number.isFinite(video.duration) ? video.duration : null,
      width: Number(video.videoWidth) || 0, height: Number(video.videoHeight) || 0,
      bufferedAhead: Number(ahead.toFixed(3)) };
  }

  function writeDiagnostics(state = null) {
    const root = document.documentElement;
    if (!root?.dataset) return;
    root.dataset.biliCdnAutoVersion = chrome.runtime.getManifest?.()?.version || "";
    root.dataset.biliCdnAutoPhase = state?.phase || root.dataset.biliCdnAutoPhase || "waiting";
    root.dataset.biliCdnAutoSelectedHost = state?.selectedHost || "";
    root.dataset.biliCdnAutoActualHost = state?.actualHost || "";
    root.dataset.biliCdnAutoRuleInstalled = String(state?.ruleInstalled === true);
  }

  function send(message) {
    if (message.type === 'media-discovered' && configurationReady && !routeConfiguration) {
      // SSR metadata can arrive before the asynchronous preferences read.
      // Defer only its worker report, never the player's network request.
      configurationReady.then(() => {
        if (playbackPageKey(message.pageUrl) === playbackPageKey(location.href))
          send({ ...message, preparedRouteHost });
      });
      return;
    }
    if (message.type === 'media-discovered') {
      // The capability survives a provisional empty destination. Otherwise a
      // worker wakeup could mistake native passthrough for legacy startup mode.
      message = { ...message, earlyRouting: Boolean(routeConfiguration
        && routeConfiguration.enabled !== false && routeConfiguration.mode !== 'original') };
    }
    try {
      const pending = chrome.runtime.sendMessage(message);
      if (pending?.catch) pending.catch(() => {});
    } catch {}
  }

  function connectionHint() {
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    return {
      online: navigator.onLine,
      effectiveType: String(connection?.effectiveType || "unknown"),
      downlink: Number(connection?.downlink) || 0,
      rtt: Number(connection?.rtt) || 0,
    };
  }

  function connectionSignature() {
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    return [
      navigator.onLine ? "online" : "offline",
      String(connection?.type || "unknown"),
    ].join("|");
  }

  function isMediaHost(host) {
    const value = String(host || "").toLowerCase();
    return /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+bilivideo\.com$/.test(value)
      || /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+mcdn\.bilivideo\.cn$/.test(value)
      || value === "upos-hz-mirrorakam.akamaized.net";
  }

  function isMediaUrl(value) {
    try {
      const url = new URL(String(value));
      return ["http:", "https:"].includes(url.protocol)
        && isMediaHost(url.hostname)
        && url.pathname.includes("/upgcxcode/");
    } catch {
      return false;
    }
  }

  function sanitizeUrls(values) {
    const weight = url => ({ video: 0, audio: 2 }[trackKinds.get(new URL(url).pathname)] ?? 1);
    return [...new Set((Array.isArray(values) ? values : []).filter(isMediaUrl))]
      .sort((left, right) => weight(left) - weight(right)).slice(0, 8);
  }

  function backupsFor(value) {
    const requested = new URL(value);
    const exact = trackBackups.get(requested.href);
    if (exact) return exact;
    // The player may upgrade HTTP or append telemetry parameters. Match all
    // signed descriptor parameters, never just a shared path/reciprocal host.
    for (const [descriptor, backups] of trackBackups) {
      const source = new URL(descriptor);
      if (source.hostname !== requested.hostname || source.pathname !== requested.pathname) continue;
      if (source.protocol !== requested.protocol && !(source.protocol === 'http:' && requested.protocol === 'https:')) continue;
      if ([...source.searchParams].every(([key,v]) => requested.searchParams.getAll(key).includes(v))) return backups;
    }
    return [];
  }

  function reportUrls(values, source, observed = false) {
    const requested = source === "page-request";
    const known = requested ? observedRequestUrls : source === "page-response" ? observedResponseUrls : observed ? observedResourceUrls : discoveredUrls;
    const role = requested ? 'request' : source === 'page-response' ? 'response' : observed ? 'resource' : 'descriptor';
    const signature = url => JSON.stringify([trackKinds.get(new URL(url).pathname) || 'unknown',
      backupsFor(url), trackRates.get(new URL(url).pathname) || 0]);
    const urls = sanitizeUrls(values).filter(value => !known.has(value)
      || reportSignatures.get(role + ':' + value) !== signature(value));
    if (!urls.length) return;
    for (const value of urls) {
      known.add(value);
      reportSignatures.set(role + ':' + value, signature(value));
    }
    send({
      type: "media-discovered",
      preparedRouteHost,
      urls,
      source,
      observed,
      requested,
      tracks: urls.map(url => ({ url, kind: trackKinds.get(new URL(url).pathname) || "unknown",
        backups:backupsFor(url), bandwidth:trackRates.get(new URL(url).pathname) || 0 })),
      originals: source === "page-response" || requested ? urls.map(url => mediaOriginals.get(url)).filter(Boolean) : [],
      startupDeadline,
      networkKey: connectionSignature(),
      pageUrl: location.href,
      connection: connectionHint(),
    });
  }

  function probeUrl(sourceUrl, host) {
    const target = new URL(String(sourceUrl));
    if (!isMediaUrl(target.href) || !isMediaHost(host)) throw new Error("invalid media probe target");
    target.hostname = String(host).toLowerCase();
    return target.href;
  }

  async function probe(sourceUrl, host, byteLimit, timeoutMs, startByte = 0, batchSignal, sampleSegments = 1, playbackOptional = false) {
    const controller = new AbortController();
    controller.playbackOptional = playbackOptional;
    const probeId = Date.now().toString(36) + "-" + (++nextProbeId);
    controller.signal.addEventListener("abort", () => send({ type: "cancel-probe", probeId }), { once: true });
    const abortBatch = () => controller.abort();
    batchSignal?.addEventListener('abort', abortBatch, { once: true });
    probeControllers.add(controller);
    const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
    const started = performance.now();
    let ttfbMs = 0;
    try {
      if (batchSignal?.aborted) return { host, ok: false, error: 'cancelled' };
      probeUrl(sourceUrl, host); // Validate before crossing the message boundary.
      return await chrome.runtime.sendMessage({ type: "fetch-probe", sourceUrl, host, byteLimit, timeoutMs, probeId, startByte, sampleSegments });
    } catch (error) {
      return {
        host, ok: false, status: 0, bytes: 0,
        elapsedMs: performance.now() - started, ttfbMs,
        error: error?.name === "AbortError" ? "timeout" : String(error?.message || error),
      };
    } finally {
      batchSignal?.removeEventListener('abort', abortBatch);
      probeControllers.delete(controller);
      window.clearTimeout(timeout);
    }
  }

  function bufferedAhead(video) {
    if (!video) return 0;
    const time = Number(video.currentTime) || 0;
    for (let index = 0; index < video.buffered.length; index += 1) {
      if (video.buffered.start(index) <= time + 0.05 && video.buffered.end(index) >= time) {
        return Math.max(0, video.buffered.end(index) - time);
      }
    }
    return 0;
  }

  async function waitForSafeBuffer(minimumSeconds, maximumWaitMs, generation) {
    const minimum = Math.max(0, Number(minimumSeconds) || 0);
    if (!minimum) return true;
    if (!activeVideo || activeVideo.paused || activeVideo.ended || document.hidden) return false;
    const deadline = Date.now() + Math.max(0, Number(maximumWaitMs) || 0);
    do {
      if (generation !== probeGeneration || !activeVideo || activeVideo.paused
        || activeVideo.ended || activeVideo.seeking || document.hidden) return false;
      const remaining = Number(activeVideo.duration) - Number(activeVideo.currentTime);
      if (Number.isFinite(remaining) && remaining <= minimum + 2) return false;
      if (bufferedAhead(activeVideo) >= minimum) return true;
      if (Date.now() >= deadline) return false;
      await new Promise((resolve) => window.setTimeout(resolve, 500));
    } while (Date.now() <= deadline);
    return false;
  }

  async function probeCandidates(message) {
    const generation = probeGeneration;
    const sourceUrl = String(message?.sourceUrl || "");
    const hosts = [...new Set((Array.isArray(message?.hosts) ? message.hosts : [])
      .map((host) => String(host).toLowerCase()).filter(isMediaHost))].slice(0, 8);
    const byteLimit = Math.min(MAX_PROBE_BYTES, Math.max(1, Number(message?.byteLimit) || 128 * 1024));
    const timeoutMs = Math.min(MAX_PROBE_TIMEOUT_MS, Math.max(1_000, Number(message?.timeoutMs) || 4_500));
    if (!hosts.length) return { ok: false, error: "no valid probe hosts", results: [] };
    if (!await waitForSafeBuffer(message?.waitForBufferSeconds, message?.waitTimeoutMs, generation)
      || generation !== probeGeneration) {
      return { ok: false, skipped: true, error: "safe buffer unavailable", results: [] };
    }
    const startByte = Number.isSafeInteger(message?.startByte) && message.startByte >= 0 && message.startByte <= 2 ** 40 ? message.startByte : 0;
    let results;
    if (Number(message.deadline) > 0) {
      // A shared deadline, not a fresh timeout per queued host. Return only
      // completed samples; an unstarted/unfinished host is not a failed CDN.
      results = [];
      const deadline = Number(message.deadline);
      const batch = new AbortController();
      let cursor = 0, closed = false, timer;
      const consume = async () => {
        while (!closed && generation === probeGeneration && cursor < hosts.length && Date.now() < deadline) {
          const host = hosts[cursor++];
          const result = await probe(sourceUrl, host, byteLimit,
            Math.max(1, Math.min(timeoutMs, deadline - Date.now())), startByte, batch.signal, message.sampleSegments===2 ? 2 : 1);
          if (!closed && generation === probeGeneration && Date.now() < deadline) results.push(result);
        }
      };
      try {
        await Promise.race([
          Promise.all([consume(), consume()]),
          new Promise(resolve => { timer = window.setTimeout(resolve, Math.max(0, deadline - Date.now())); }),
        ]);
      } finally {
        closed = true; window.clearTimeout(timer); batch.abort();
      }
    } else if (message.firstSuccess) {
      const tasks = hosts.map(host => probe(sourceUrl, host, byteLimit, timeoutMs, startByte, undefined, message.sampleSegments===2 ? 2 : 1));
      try { results = [await Promise.any(tasks.map(task => task.then(result => {
        const kbps = Number.isFinite(result?.capacityKbps) ? result.capacityKbps
          : (Number(result?.bytes)||0)*8/Math.max(1,Number(result?.elapsedMs)||0);
        if (!result?.ok || kbps < (Number(message.minimumKbps)||0)) throw new Error('candidate insufficient'); return result;
      })))]; } catch { results = await Promise.all(tasks); }
    } else {
      results = [];
      let cursor = 0;
      const consume = async () => {
        while (cursor < hosts.length && generation === probeGeneration) {
          if (Number(message.waitForBufferSeconds)>0 && (!activeVideo || activeVideo.paused
            || activeVideo.ended || activeVideo.seeking || document.hidden
            || bufferedAhead(activeVideo)<LOW_BUFFER_SECONDS)) { cancelProbes(); return; }
          const host = hosts[cursor++];
          results.push(await probe(sourceUrl, host, byteLimit, timeoutMs, startByte, undefined, 1, Number(message.waitForBufferSeconds)>0));
        }
      };
      await Promise.all([consume(), consume()]);
    }
    if (generation !== probeGeneration) return { ok: false, skipped: true, results: [] };
    return { ok: true, results };
  }

  function startupProtected() {
    return !healthArmed && Date.now() - videoStartedAt < STARTUP_GRACE_MS;
  }

  function currentVideoPath() {
    for (const url of [...observedRequestUrls].reverse()) {
      const path = new URL(url).pathname;
      if (trackKinds.get(path) === 'video') return path;
    }
    return '';
  }

  function startupFailureKey(kind, host, path, videoPath = path) {
    // One report per actually requested host/track, not a controller allowance
    // for the whole video. A failed replacement remains independently eligible.
    return JSON.stringify([playbackPageKey(location.href), videoPath, kind, host, path]);
  }

  function untouchedStartup(video, path) {
    const frames = displayedFrameCount(video);
    let total;
    try { total=video?.getVideoPlaybackQuality?.()?.totalVideoFrames ?? video?.webkitDecodedFrameCount; } catch {}
    return Boolean(video && video===activeVideo && path && path === currentVideoPath() && !hasPlayed && !pagePlaybackObserved && !userPaused
      && !video.paused && !video.seeking && !video.ended && !document.hidden
      && Number(video.readyState) === 0 && Number(video.currentTime) >= 0 && Number(video.currentTime) < .01
      && video.buffered?.length === 0 && bufferedAhead(video) === 0 && frames === 0 && Number.isFinite(total) && total === 0
      && Date.now() - lastUserInteractionAt > 1500);
  }

  function untouchedAudioStartup(video,path) {
    return Boolean(video && path && path===currentVideoPath() && !hasPlayed && !pagePlaybackObserved && !userPaused
      && !video.paused && !video.seeking && !video.ended && !document.hidden
      && [0,1].includes(Number(video.readyState)) && Number(video.currentTime)>=0 && Number(video.currentTime)<.01
      && bufferedAhead(video)===0 && displayedFrameCount(video)===0
      && Date.now()-lastUserInteractionAt>1500);
  }

  function displayedFrameCount(video) {
    if (!video) return null;
    try {
      const quality = video.getVideoPlaybackQuality?.();
      const total = Number(quality?.totalVideoFrames ?? video.webkitDecodedFrameCount);
      const dropped = Number(quality?.droppedVideoFrames ?? video.webkitDroppedFrameCount ?? 0);
      // Total includes dropped frames. A decoding backlog must not masquerade
      // as visible playback just because the total frame counter increases.
      return Number.isFinite(total) && Number.isFinite(dropped) && total >= dropped && dropped >= 0
        ? total - dropped : null;
    } catch { return null; }
  }

  function resetFrameProgress() {
    displayedFrames = displayedFrameCount(activeVideo);
    frameProgressAt = Date.now();
  }

  function resetSeekEpisode() {
    seekEpisodeAt = 0;
    seekEpisodeFrames = null;
  }

  function observeSeekEpisode(frames = displayedFrameCount(activeVideo)) {
    const video = activeVideo;
    if (!video || !video.seeking || video.paused || video.ended || document.hidden || userSeek || !lastSeekAt) {
      resetSeekEpisode();
      return 0;
    }
    // Native retries may repeatedly move currentTime without presenting a
    // frame. Keep their first start; real frame progress (or a counter reset)
    // invalidates that old stall evidence. No frame API keeps the time guard.
    if (!seekEpisodeAt || frames !== seekEpisodeFrames) seekEpisodeAt = Date.now();
    seekEpisodeFrames = frames;
    return seekEpisodeAt;
  }

  function sampleFrameHealth() {
    const video = activeVideo;
    const count = displayedFrameCount(video);
    const now = Date.now();
    if(currentVideoPath() && count>0)pagePlaybackObserved=true;
    observeSeekEpisode(count);
    if (count === null || displayedFrames === null || count !== displayedFrames) frameProgressAt = now;
    displayedFrames = count;
    if (!video || video.paused || video.ended || video.seeking || document.hidden
      || startupProtected() || now - lastSeekAt < SEEK_GRACE_MS) {
      frameProgressAt = now;
      return;
    }
    // No frame API (or no frame displayed yet) keeps the existing playhead and
    // waiting-event fallback. This sampler adds no periodic network traffic.
    if (!(count > 0) || now - frameProgressAt < FRAME_STALL_MS || bufferedAhead(video) >= .5) return;
    const duration = Number(video.duration);
    if (Number.isFinite(duration) && duration > 0 && Number(video.currentTime) >= duration - .5) return;
    reportStall('frame-stalled');
  }

  function reportStall(reason, snapshot = {}) {
    // Health evidence may rotate a bounded fallback; before first playback it
    // never authorizes a player operation or a new media request.
    const now = Date.now();
    const cooldown = reason === 'buffer-low' ? STALL_COOLDOWN_MS : 3_000;
    if (now - lastStallAt < cooldown) return;
    lastStallAt = now;
    cancelProbes();
    send({ type: "playback-stall", reason, connection: connectionHint(), ...snapshot });
  }

  function scheduleStallCheck(video, reason) {
    if (
      video !== activeVideo || document.hidden || video.paused || video.ended || video.seeking
      || startupProtected() || Date.now() - lastSeekAt < SEEK_GRACE_MS
    ) return;
    window.clearTimeout(stallTimer);
    stallTimer = window.setTimeout(() => {
      stallTimer = 0;
      if (
        video === activeVideo && !document.hidden && !video.paused && !video.ended && !video.seeking
        && !startupProtected() && Date.now() - lastSeekAt >= SEEK_GRACE_MS
        && bufferedAhead(video) < 0.5
      ) reportStall(reason);
    }, STALL_CONFIRM_MS);
  }

  function sampleHealth() {
    const seekStartedAt = observeSeekEpisode();
    if (!activeVideo || (activeVideo.paused && (userPaused || !hasPlayed || bufferedAhead(activeVideo)>=0.5)) || activeVideo.ended || document.hidden) {
      bufferHistory.length = 0;
      progressAt = Date.now();
      progressTime = Number(activeVideo?.currentTime) || 0;
      return;
    }
    const ahead = bufferedAhead(activeVideo);
    if(activeVideo.paused&&!userPaused&&hasPlayed&&ahead<0.5&&!startupProtected()&&Date.now()-progressAt>=3000){reportStall('player-paused-empty');return;}
    const time = Number(activeVideo.currentTime) || 0;
    if (time > progressTime + .01 || time < progressTime - .01) progressAt = Date.now();
    progressTime = time;
    if (activeVideo.seeking) {
      if (!userSeek && seekStartedAt > 0 && Date.now()-seekStartedAt >= STALL_COOLDOWN_MS && ahead < 0.5) {
        recoveryVideo = activeVideo;
        reportStall('player-seek-timeout');
      }
      bufferHistory.length = 0;
      return;
    }
    // Drop optional measurements before they compete with endangered playback.
    if (ahead < LOW_BUFFER_SECONDS && [...probeControllers].some(controller => controller.playbackOptional)) cancelProbes();
    if (ahead >= HEALTHY_BUFFER_SECONDS) {
      healthArmed = true;
      sendHeartbeat();
      bufferHistory.length = 0;
      return;
    }
    if (startupProtected() || Date.now() - lastSeekAt < SEEK_GRACE_MS) {
      bufferHistory.length = 0;
      return;
    }
    const duration = Number(activeVideo.duration);
    if (Number.isFinite(duration) && duration > 0 && activeVideo.currentTime + ahead >= duration - 0.5) {
      bufferHistory.length = 0;
      return;
    }
    // waiting/stalled can be missed while attaching or during player retries.
    // Only recover a non-progressing, empty-buffer player; decoded/UI lag with
    // healthy buffered media is not evidence that another CDN is needed.
    if (ahead < .5 && Date.now() - progressAt >= 2_000) {
      reportStall('playhead-stalled');
      bufferHistory.length = 0;
      return;
    }
    const now = Date.now(), path = currentVideoPath(), targetHost = preparedRouteHost;
    const pageUrl = location.href;
    const key = JSON.stringify([playbackPageKey(pageUrl), path, targetHost]);
    if (!routeConfiguration || routeConfiguration.enabled === false
      || (routeConfiguration.mode && routeConfiguration.mode !== 'auto')
      || !path || !isMediaHost(targetHost) || !(time > 0) || !(ahead > 0) || !Number.isFinite(ahead)) {
      bufferHistory.length = 0;
      return;
    }
    const previous = bufferHistory.at(-1);
    // A suspended timer, track/route change or burst of stale callbacks cannot
    // supply consecutive two-second health observations for the new route.
    if (previous && (key !== previous.key || now - previous.at < HEALTH_SAMPLE_INTERVAL_MS / 2
      || now - previous.at > HEALTH_SAMPLE_INTERVAL_MS * 1.5)) bufferHistory.length = 0;
    bufferHistory.push({ ahead, at: now, key });
    if (bufferHistory.length > HEALTH_WINDOW_SAMPLES) bufferHistory.shift();
    const fallingWindow = bufferHistory.length === HEALTH_WINDOW_SAMPLES
      && bufferHistory[0].ahead - ahead >= MIN_BUFFER_DRAIN_SECONDS
      && bufferHistory.every((value, index, values) => index === 0 || value.ahead <= values[index - 1].ahead + 0.25);
    const tail = bufferHistory.slice(-3);
    // Small segment refills can invalidate the six-second window until the
    // buffer is empty. A critical tail warns earlier, without touching playback.
    const criticalTail = ahead <= 4 && tail.length === 3 && tail[0].ahead - ahead >= 3
      && tail.every((value, index, values) => index === 0 || value.ahead < values[index - 1].ahead);
    if (ahead < LOW_BUFFER_SECONDS && (fallingWindow || criticalTail)) {
      reportStall("buffer-low", { pageUrl, path, targetHost, observedAt: now,
        activity: { bufferedAhead: ahead, currentTime: time, visible: !document.hidden,
          paused: activeVideo.paused === true, seeking: activeVideo.seeking === true, ended: activeVideo.ended === true } });
      bufferHistory.length = 0;
    }
  }

  function retryPlayback(message = {}) {
    // Repeated zero-response evidence changes future requests only, even if
    // an asynchronous caller delivers it after the buffer has since emptied.
    if (message.reason === 'repeated-zero-response' || !hasPlayed
      || String(message.reason || '').startsWith('startup-')) return false;
    const video = activeVideo;
    if (routeConfiguration && (routeConfiguration.enabled === false || routeConfiguration.mode === 'original'
      || (isMediaHost(message.targetHost) && message.targetHost !== preparedRouteHost))) return false;
    if (!video || document.hidden || (video.paused&&(userPaused||!hasPlayed)) || video.ended || (video.seeking && recoveryVideo !== video) || !Number.isFinite(video.currentTime)) return false;
    if (message.pageUrl && playbackPageKey(message.pageUrl) !== playbackPageKey(location.href)) return false;
    if (message.path && trackKinds.get(message.path) !== 'video') return false;
    // A route update affects the next segment without disturbing buffered
    // playback. Interrupt only a genuinely empty, non-user-seeking player.
    if (bufferedAhead(video) >= 0.5 || startupProtected() || (userSeek && video.seeking)) return false;
    if (!Number.isFinite(video.duration) || video.duration <= 0) return false;
    const now = Date.now();
    if (lastRecoveryAt && now - lastRecoveryAt < STALL_COOLDOWN_MS) return false;
    const frames = displayedFrameCount(video);
    if (frames !== null && displayedFrames !== null && frames > displayedFrames) {
      resetFrameProgress();
      return false;
    }
    // A new route may already be rendering by the time this asynchronous
    // message arrives. Do not cancel its request with a redundant seek.
    if (frames > 0 && now - frameProgressAt < STALL_CONFIRM_MS) return false;
    if(video.paused){try{video.play()?.catch?.(()=>{});}catch{return false;}}
    clearRecoveryWatchdog();
    resetSeekEpisode();
    recoveryVideo = video;
    lastRecoveryAt = now;
    // MAIN receives this asynchronously. Bound cancellation to requests that
    // predate the seek, so its freshly issued target request cannot be aborted.
    const cutoff = Math.max(0, Number(performance.now?.()) || 0);
    window.postMessage({source:SOURCE,type:'route-recovery',confirmedEmpty:true,path:message.path,
      cutoff,targetHost:isMediaHost(message.targetHost)?message.targetHost:'',
      reason:message.reason || 'recovery',pageUrl:location.href},location.origin);
    if (video.currentTime > 0.2) video.currentTime = Math.max(0, video.currentTime - 0.15);
    else if (Number.isFinite(video.duration) && video.duration > 0) video.currentTime = Math.min(0.001, video.duration / 2);
    else return false;
    // A recovery-triggered seek can itself hang on the failed request. Do not
    // let `seeking` suppress all recovery forever; use the existing cooldown.
    recoveryTimer = window.setTimeout(() => {
      recoveryTimer = 0;
      if (video === activeVideo && !document.hidden && !video.paused && !video.ended
        && bufferedAhead(video) < 0.5) reportStall("recovery-timeout");
    }, STALL_COOLDOWN_MS + 1);
    return true;
  }

  function waitForAppliedRoute(host) {
    if (appliedRouteHost === host) return Promise.resolve(true);
    return new Promise(resolve => {
      const waiter = { host, deadline:Date.now()+250, finish(value) {
        window.clearTimeout(waiter.timer);
        routePolicyWaiters.delete(waiter);
        resolve(value && Date.now() <= waiter.deadline);
      } };
      waiter.timer = window.setTimeout(() => waiter.finish(false), 250);
      routePolicyWaiters.add(waiter);
    });
  }

  function resetAppliedRoute() {
    appliedRouteHost = '';
    clearStartupBindings();
    for (const waiter of [...routePolicyWaiters]) waiter.finish(false);
  }

  function clearRecoveryWatchdog() {
    window.clearTimeout(recoveryTimer);
    recoveryTimer = 0;
    recoveryVideo = null;
  }

  function watchVideo(video) {
    if (video === activeVideo) return;
    activeVideo = video;
    clearStartupBindings();
    userPaused=false;hasPlayed=false;
    clearRecoveryWatchdog();
    videoStartedAt = Date.now();
    healthArmed = false;
    lastSeekAt = 0;
    userSeek = false;
    resetSeekEpisode();
    lastStallAt = 0;
    progressTime = Number(video.currentTime) || 0;
    progressAt = Date.now();
    lastRecoveryAt = 0;
    resetFrameProgress();
    bufferHistory.length = 0;
    if (!watchedVideos.has(video)) {
      watchedVideos.add(video);
      video.addEventListener("waiting", () => scheduleStallCheck(video, "waiting"));
      video.addEventListener("play", () => { if (video === activeVideo) periodicDiscovery(); });
      video.addEventListener("stalled", () => scheduleStallCheck(video, "stalled"));
      video.addEventListener("playing", () => { if (video === activeVideo) {hasPlayed=true;pagePlaybackObserved=true;userPaused=false;userSeek=false;resetSeekEpisode();clearRecoveryWatchdog();resetFrameProgress();} });
      for (const name of ['pause','ended']) video.addEventListener(name, () => {
        if (video !== activeVideo) return;
        clearStartupBindings();
        if(name==='pause')userPaused=lastUserInteractionAt>0&&Date.now()-lastUserInteractionAt<1500;
        cancelProbes(); window.clearTimeout(stallTimer); clearRecoveryWatchdog();
        resetSeekEpisode();
        resetFrameProgress();
      });
      video.addEventListener("seeking", () => {
        if (video !== activeVideo) return;
        clearStartupBindings();
        lastSeekAt = Date.now();
        // User ownership lasts until this seek completes, not merely until
        // the recent-input grace expires before a delayed native retry.
        userSeek = userSeek || recoveryVideo !== video && Date.now()-lastUserInteractionAt < 1500;
        observeSeekEpisode();
        resetFrameProgress();
        bufferHistory.length = 0;
        window.clearTimeout(stallTimer);
      });
      video.addEventListener('seeked', () => { if (video === activeVideo) { userSeek = false; resetSeekEpisode(); resetFrameProgress(); } });
    }
    if (!healthTimer) healthTimer = window.setInterval(sampleHealth, HEALTH_SAMPLE_INTERVAL_MS);
    if (!frameTimer) frameTimer = window.setInterval(sampleFrameHealth, FRAME_SAMPLE_INTERVAL_MS);
  }

  function locateVideo() {
    const video = displayVideo();
    if (video) watchVideo(video);
    else if (activeVideo) {
      activeVideo = null;
      clearStartupBindings();
      resetSeekEpisode();
      bufferHistory.length = 0;
      window.clearTimeout(stallTimer);
      clearRecoveryWatchdog();
    }
  }

  function reportNavigation(url = location.href) {
    const pageKey = playbackPageKey(url);
    if (pageKey === lastUrl) return;
    lastUrl = pageKey;
    resumeGeneration += 1;
    resetAppliedRoute();
    startupTimeoutReports.clear();
    cancelProbes();
    clearRecoveryWatchdog();
    discoveredUrls.clear();
    discoveredCandidateHosts.clear();
    trackKinds.clear();
    lastRoutedAudio = null; lastAudioRequestOrder = 0;
    trackBackups.clear();
    trackRates.clear();
    startupDeadline = 0;
    mediaOriginals.clear();
    observedResourceUrls.clear();
    observedResponseUrls.clear();
    observedRequestUrls.clear();
    seenResourceEntries.clear();
    reportSignatures.clear();
    navigationResourceTime = performance.now();
    bufferHistory.length = 0;
    videoStartedAt = Date.now();
    healthArmed = false;
    lastStallAt = 0;
    userPaused = false;
    hasPlayed = false;
    pagePlaybackObserved = false;
    lastSeekAt = 0;
    userSeek = false;
    resetSeekEpisode();
    window.clearTimeout(stallTimer);
    progressTime = Number(activeVideo?.currentTime) || 0;
    progressAt = Date.now();
    lastRecoveryAt = 0;
    resetFrameProgress();
    send({ type: "page-changed", url });
  }

  function scanPerformanceEntries(entries = performance.getEntriesByType?.("resource") || []) {
    const urls = [];
    for (const entry of entries) {
      const name = String(entry?.name || "");
      if (Number(entry.startTime) < navigationResourceTime) continue;
      if (!isMediaUrl(name)) continue;
      const key = `${name}\n${Number(entry.startTime) || 0}\n${Number(entry.duration) || 0}\n${entry.initiatorType || ""}`;
      if (seenResourceEntries.has(key)) continue;
      seenResourceEntries.add(key);
      urls.push(name);
    }
    reportUrls(urls, "performance", true);
  }

  function sendHeartbeat() {
    if (activeVideo && !activeVideo.paused && !activeVideo.ended && !document.hidden) {
      send({
        type: "media-heartbeat",
        activity: {
          visible: !document.hidden,
          paused: activeVideo.paused,
          ended: activeVideo.ended,
          seeking: activeVideo.seeking,
          bufferedAhead: Number(bufferedAhead(activeVideo).toFixed(3)),
          currentTime: activeVideo.currentTime,
        },
        connection: connectionHint(),
      });
    }
  }

  function periodicDiscovery(sendActivity = true) {
    reportNavigation(location.href);
    window.postMessage({ source: SOURCE, type: "rescan" }, location.origin);
    scanPerformanceEntries();
    if (sendActivity) sendHeartbeat();
  }

  function replayKnownMedia(sendActivity = true) {
    // Rebuild worker state from existing descriptors; no media is downloaded.
    for (const [known, observed] of [[discoveredUrls, false], [observedRequestUrls, false], [observedResourceUrls, true], [observedResponseUrls, true]]) {
      const urls = sanitizeUrls([...known].reverse());
      if (urls.length) send({ type: "media-discovered", preparedRouteHost, urls, observed, requested: known === observedRequestUrls,
        tracks: urls.map(url => ({ url, kind: trackKinds.get(new URL(url).pathname) || "unknown",
          backups: backupsFor(url), bandwidth:trackRates.get(new URL(url).pathname) || 0 })),
        originals: known === observedResponseUrls || known === observedRequestUrls ? urls.map(url => mediaOriginals.get(url)).filter(Boolean) : [],
        source: known === observedResponseUrls ? "page-response" : known === observedRequestUrls ? "page-request" : "rescan-cache", pageUrl: location.href, connection: connectionHint() });
    }
    periodicDiscovery(sendActivity);
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== SOURCE) return;
    if (event.data.pageUrl && playbackPageKey(event.data.pageUrl) !== playbackPageKey(location.href)) return;
    if (event.data.type === 'route-policy-applied') {
      appliedRouteHost = event.data.enabled === true && isMediaHost(event.data.host) ? event.data.host : '';
      for (const waiter of [...routePolicyWaiters]) if (waiter.host === appliedRouteHost) waiter.finish(true);
      return;
    }
    if (event.data.type === 'route-startup-timeout') {
      const d=event.data;
      if(d.kind==='audio') {
        if(d.reason!=='startup-audio-zero-response' || !d.pageUrl || !isMediaUrl(d.url) || !isMediaUrl(d.originalUrl)
          || !Number.isSafeInteger(d.attempts) || d.attempts<2 || !Number.isFinite(d.elapsedMs) || d.elapsedMs<3600)return;
        const actual=new URL(d.url),path=currentVideoPath(),audio=lastRoutedAudio;
        const key=startupFailureKey('audio',actual.hostname,actual.pathname,path);
        if(!routeConfiguration || routeConfiguration.enabled===false || (routeConfiguration.mode && routeConfiguration.mode!=='auto')
          || actual.hostname!==preparedRouteHost || new URL(d.originalUrl).pathname!==actual.pathname
          || d.videoPath!==path || !audio || audio.path!==actual.pathname || audio.host!==actual.hostname
          || audio.videoPath!==path || audio.video!==activeVideo || trackKinds.get(actual.pathname)!=='audio'
          || startupTimeoutReports.has(key) || !untouchedAudioStartup(activeVideo,path))return;
        startupTimeoutReports.add(key);
        send({type:'route-failed',url:d.url,originalUrl:d.originalUrl,kind:'audio',videoPath:path,status:0,
          reason:'startup-audio-zero-response',attempts:d.attempts,elapsedMs:d.elapsedMs,pageUrl:location.href,observedAt:Date.now(),
          activity:{visible:!document.hidden,paused:activeVideo.paused===true,seeking:activeVideo.seeking===true,
            ended:activeVideo.ended===true,userInteracting:false,currentTime:Number(activeVideo.currentTime),
            bufferedAhead:bufferedAhead(activeVideo),readyState:Number(activeVideo.readyState),hasPlayed:false,displayedFrames:0}});
        return;
      }
      if (d.reason!=='startup-native-zero-response' || !['abort','timeout'].includes(d.nativeEvent)
        || !d.pageUrl || !isMediaUrl(d.url) || !isMediaUrl(d.originalUrl) || d.kind!=='video'
        || !Number.isFinite(d.elapsedMs) || d.elapsedMs<1800 || !Number.isSafeInteger(d.aborts) || d.aborts<1) return;
      const actual=new URL(d.url),path=actual.pathname,routed=lastRoutedVideo;
      const key=startupFailureKey('video',actual.hostname,path);
      if (new URL(d.originalUrl).pathname!==path || startupTimeoutReports.has(key)
        || !routed || routed.path!==path || routed.host!==actual.hostname || routed.video!==activeVideo
        || !untouchedStartup(activeVideo,path)) return;
      if (!routeConfiguration || routeConfiguration.enabled===false || (routeConfiguration.mode && routeConfiguration.mode!=='auto')
        || actual.hostname!==preparedRouteHost) return;
      startupTimeoutReports.add(key);
      send({type:'route-failed',url:d.url,originalUrl:d.originalUrl,kind:'video',status:0,
        elapsedMs:d.elapsedMs,aborts:d.aborts,nativeEvent:d.nativeEvent,reason:'startup-native-zero-response',pageUrl:location.href,
        observedAt:Date.now(),activity:{visible:!document.hidden,paused:activeVideo.paused===true,seeking:activeVideo.seeking===true,
          ended:activeVideo.ended===true,userInteracting:false,currentTime:Number(activeVideo.currentTime),
          bufferedAhead:bufferedAhead(activeVideo),readyState:Number(activeVideo.readyState),hasPlayed:false,displayedFrames:0,totalFrames:0}});
      return;
    }
    if (['route-used','route-delivered','route-failed'].includes(event.data.type)) {
      const d=event.data;
      // Startup authorization only comes through the dedicated, locally
      // rechecked evidence path above, never a generic page failure message.
      if(d.type==='route-failed' && ['startup-native-zero-response','startup-audio-zero-response'].includes(d.reason))return;
      if(isMediaUrl(d.url)&&isMediaUrl(d.originalUrl)&&new URL(d.url).pathname===new URL(d.originalUrl).pathname
        && ['video','audio'].includes(d.kind)) {
        const actual=new URL(d.url), videoPath=currentVideoPath();
        if(d.type==='route-used' && d.kind==='video' && actual.pathname===videoPath && actual.hostname===preparedRouteHost)
          lastRoutedVideo={host:actual.hostname,path:actual.pathname,video:activeVideo};
        if(d.type==='route-used'&&d.kind==='audio'){
          // Audio identity comes from a real current-track request, never from
          // the later failure report itself. Its order is separate from video.
          if(!videoPath || d.videoPath!==videoPath || trackKinds.get(actual.pathname)!=='audio'
            || actual.hostname!==preparedRouteHost || !Number.isSafeInteger(d.requestOrder)
            || d.requestOrder<=lastAudioRequestOrder) return;
          lastAudioRequestOrder=d.requestOrder;
          lastRoutedAudio={host:actual.hostname,path:actual.pathname,videoPath,video:activeVideo};
        }
        const softFailure=d.type==='route-failed' && d.reason==='repeated-zero-response';
        const audioFailure=softFailure&&d.kind==='audio';
        const currentTrack=d.kind==='video' ? actual.pathname===videoPath
          : !!lastRoutedAudio && trackKinds.get(actual.pathname)==='audio' && d.videoPath===videoPath
            && lastRoutedAudio.videoPath===videoPath && lastRoutedAudio.path===actual.pathname
            && lastRoutedAudio.host===actual.hostname && lastRoutedAudio.video===activeVideo;
        if(softFailure && (!routeConfiguration || routeConfiguration.enabled===false
          || (routeConfiguration.mode && routeConfiguration.mode!=='auto') || !currentTrack
          || actual.hostname!==preparedRouteHost
          || !Number.isSafeInteger(d.attempts) || d.attempts<2 || !Number.isFinite(d.elapsedMs) || d.elapsedMs<3600
          || !hasPlayed || !activeVideo || activeVideo.paused || activeVideo.seeking || activeVideo.ended
          || document.hidden || !(Number(activeVideo.readyState)>=2) || !(Number(activeVideo.currentTime)>0)
          || Date.now()-lastUserInteractionAt<=1500 || (audioFailure&&!(bufferedAhead(activeVideo)>0)))) return;
        const range=d.completedRange;
        // EOF metadata is optional, bounded and never a replacement for the
        // current speed sample. Playback health comes from this isolated observer.
        const terminalCompletion=d.type==='route-delivered'&&d.kind==='video'&&currentTrack
          && actual.hostname===preparedRouteHost&&activeVideo&&d.status===206&&range
          && [range.start,range.end,range.total].every(Number.isSafeInteger)
          && range.start>0&&range.end>=range.start&&range.end+1===range.total
          && d.bytes===range.end-range.start+1;
        send({type:d.type,url:d.url,originalUrl:d.originalUrl,kind:d.kind,
          bytes:Number(d.bytes)||0,elapsedMs:Number(d.elapsedMs)||0,bandwidth:Number(d.bandwidth)||0,status:Number(d.status)||0,
          requestOrder:Number.isSafeInteger(d.requestOrder)&&d.requestOrder>0?d.requestOrder:0,pageUrl:location.href,
          ...(d.kind==='audio' && (d.type==='route-used'||audioFailure) ? {videoPath} : {}),
          ...(audioFailure ? {observedAt:Date.now(),activity:{visible:!document.hidden,paused:activeVideo.paused===true,
            seeking:activeVideo.seeking===true,ended:activeVideo.ended===true,userInteracting:false,
            currentTime:Number(activeVideo.currentTime),bufferedAhead:bufferedAhead(activeVideo),readyState:Number(activeVideo.readyState)}} : {}),
          ...(terminalCompletion ? {completedRange:{start:range.start,end:range.end,total:range.total},observedAt:Date.now(),
            activity:{visible:!document.hidden,paused:activeVideo.paused===true,seeking:activeVideo.seeking===true,
              ended:activeVideo.ended===true,userInteracting:Date.now()-lastUserInteractionAt<=1500,hasPlayed,
              currentTime:Number(activeVideo.currentTime),bufferedAhead:bufferedAhead(activeVideo),readyState:Number(activeVideo.readyState)}} : {}),
          ...(softFailure ? {reason:'repeated-zero-response',attempts:d.attempts} : {})});
      }
      return;
    }
    if (event.data?.type === 'startup-request') {
      startupDeadline = Math.min(Date.now()+2000, Number(event.data.deadline) || 0);
      return;
    }
    if (event.data?.type === "media-urls") {
      for (const track of (Array.isArray(event.data.tracks) ? event.data.tracks : []).slice(0, 128)) {
        if (isMediaUrl(track?.url) && ["video", "audio"].includes(track.kind)) {
          if (discoveredCandidateHosts.size < 12) discoveredCandidateHosts.add(new URL(track.url).hostname);
          trackKinds.set(new URL(track.url).pathname, track.kind);
          const backups = (Array.isArray(track.backups) ? track.backups : []).filter(isMediaUrl).slice(0,8);
          // Same-track CDN URLs share a pathname but have distinct signatures
          // and reciprocal backups. Do not overwrite one source's backup list.
          if (backups.length) trackBackups.set(new URL(track.url).href, backups);
          if (trackBackups.size > 512) trackBackups.delete(trackBackups.keys().next().value);
          if (Number(track.bandwidth)>0) trackRates.set(new URL(track.url).pathname, Number(track.bandwidth));
          if (trackKinds.size > 512) trackKinds.delete(trackKinds.keys().next().value);
        }
      }
      reportUrls(event.data.urls, `page-${event.data.reason || "playurl"}`, false);
      // An earlier transfer may have been reported as unknown. Re-send only
      // changed classifications/backups, without downloading or a new gate.
      const latestRequest = [...observedRequestUrls].reverse()
        .find(url => trackKinds.get(new URL(url).pathname) === 'video');
      const currentPath = latestRequest && new URL(latestRequest).pathname;
      const current = urls => [...urls].reverse().filter(url => !currentPath || new URL(url).pathname === currentPath);
      reportUrls(latestRequest ? [latestRequest] : [], 'page-request');
      reportUrls(current(observedResourceUrls), 'performance', true);
      reportUrls(current(observedResponseUrls), 'page-response', true);
    } else if (event.data?.type === "media-observed" || event.data?.type === "media-requested") {
      const requested = event.data.type === "media-requested";
      const previousVideoPath=currentVideoPath();
      for (const track of (Array.isArray(event.data.tracks) ? event.data.tracks : []).slice(0, 8)) {
        if (isMediaUrl(track?.url) && ["video", "audio"].includes(track.kind)) {
          trackKinds.set(new URL(track.url).pathname, track.kind);
          if (trackKinds.size > 512) trackKinds.delete(trackKinds.keys().next().value);
        }
      }
      for (const item of (Array.isArray(event.data.originals) ? event.data.originals : []).slice(0, 8)) {
        if (isMediaUrl(item?.url) && isMediaUrl(item.originalUrl)
          && new URL(item.url).pathname === new URL(item.originalUrl).pathname) {
          mediaOriginals.set(item.url, { url: item.url, originalUrl: item.originalUrl,
            startByte: Number.isSafeInteger(item.startByte) && item.startByte >= 0 && item.startByte <= 2 ** 40 ? item.startByte : 0 });
          if (mediaOriginals.size > 512) mediaOriginals.delete(mediaOriginals.keys().next().value);
          // Repeat transfers of one signed URL have different Range offsets.
          (requested ? observedRequestUrls : observedResponseUrls).delete(item.url);
        }
      }
      reportUrls(event.data.urls, requested ? "page-request" : "page-response", !requested);
      if(previousVideoPath!==currentVideoPath())clearStartupBindings();
      if(lastRoutedAudio && lastRoutedAudio.videoPath!==currentVideoPath())lastRoutedAudio=null;
    } else if (event.data?.type === "page-changed") {
      reportNavigation(String(event.data.url || location.href));
    }
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "get-playback-info") {
      sendResponse({ ok: true, playback: readPlaybackInfo() });
      return false;
    }
    if (message?.type === "cancel-probes") {
      cancelProbes();
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === "rescan") {
      // MV3 workers can sleep while the page stays open. Replay known media
      // without downloading or reclassifying resources from older videos.
      replayKnownMedia();
      return false;
    }
    if (message?.type === "probe-candidates") {
      probeCandidates(message).then(sendResponse).catch((error) => {
        sendResponse({ ok: false, error: String(error?.message || error), results: [] });
      });
      return true;
    }
    if (message?.type === "retry-playback") {
      // Startup routes change only future native requests. Do not even wait
      // for a controller ACK or turn an old startup command into a later seek.
      if (!hasPlayed || String(message.reason || '').startsWith('startup-')) {
        sendResponse({ ok: true, retried: false });
        return false;
      }
      if (isMediaHost(message.targetHost) && appliedRouteHost !== message.targetHost) {
        // Worker publication crosses ISOLATED -> MAIN asynchronously. Never
        // seek onto the old route while the new policy is still in transit.
        waitForAppliedRoute(message.targetHost).then(applied => {
          sendResponse({ ok: true, retried: applied && appliedRouteHost === message.targetHost && retryPlayback(message) });
        });
        return true;
      }
      sendResponse({ ok: true, retried: retryPlayback(message) });
      return false;
    }
    if (message?.type === "state-update") {
      writeDiagnostics(message.state);
      if(message.settings)publishRoutePolicy(message.settings,message.state||{});
      if (message.settings) window.postMessage({ source: SOURCE, type: 'startup-policy',
        enabled: message.settings.enabled && message.settings.mode === 'auto' }, location.origin);
      return false;
    }
    if (message?.type === 'startup-ready') {
      window.postMessage({ source: SOURCE, type: 'startup-ready', path: message.path }, location.origin);
      return false;
    }
    return false;
  });

  function cancelProbes() {
    probeGeneration += 1;
    for (const controller of probeControllers) controller.abort();
    probeControllers.clear();
  }

  const observer = new MutationObserver(locateVideo);
  function startObserver() {
    if (document.documentElement) observer.observe(document.documentElement, { childList: true, subtree: true });
    else document.addEventListener("readystatechange", startObserver, { once: true });
  }
  startObserver();
  // MAIN cannot access extension storage; fail open until the user's actual mode is known.
  function readRouteConfiguration(isCurrent = () => true) {
    const configuration = chrome.storage?.local?.get?.(['biliCdnAutoSettingsV2','biliCdnAutoBenchmarkV5']);
    return configuration?.then?.(stored => {
    if (!isCurrent()) return false;
    const saved = stored.biliCdnAutoSettingsV2 || {};
    const cache=stored.biliCdnAutoBenchmarkV5||{},now=Date.now();
    const fresh=(at,ttl)=>Number(at)>0&&Number(at)<=now&&now-Number(at)<ttl;
    const learned=(!cache.networkKey||cache.networkKey===connectionSignature())&&(cache.results||[]).find(r=>r.host===cache.winnerHost&&r.ok
      && (['playback','sustained'].includes(r.stage)?Number(r.bytes)>=1024*1024&&fresh(r.sampledAt,10800000):fresh(r.fullSampledAt,10800000)));
    // A completed real segment below this video's safety margin is not a
    // cross-video connection failure, nor does it become a verified winner.
    const completedPlaybackBelowMargin=r=>r?.ok===false&&r.stage==='playback'
      &&Number.isInteger(r.status)&&r.status>=200&&r.status<300&&Number.isFinite(r.bytes)&&r.bytes>=1024*1024;
    const failed=(!cache.networkKey||cache.networkKey===connectionSignature())&&(cache.results||[]).some(r=>r.host==='upos-sz-mirror08ct.bilivideo.com'&&!r.ok
      &&!completedPlaybackBelowMargin(r)&&fresh(r.sampledAt,600000));
    publishRoutePolicy(saved,saved.mode==='manual'?{}:learned?{routeHost:learned.host}:failed?{routeHost:''}:{});
    window.postMessage({ source: SOURCE, type: 'startup-policy', enabled: saved.enabled !== false
      && (!saved.mode || saved.mode === 'auto') }, location.origin);
    return true;
    }).catch(() => { if (isCurrent()) routeConfiguration = {}; return false; });
  }
  configurationReady = readRouteConfiguration();
  writeDiagnostics();
  document.addEventListener("DOMContentLoaded", () => {
    writeDiagnostics();
    locateVideo();
    scanPerformanceEntries();
  }, { once: true });
  window.addEventListener("popstate", () => reportNavigation(location.href));
  window.addEventListener("hashchange", () => reportNavigation(location.href));

  if (typeof PerformanceObserver !== "undefined") {
    try {
      const resourceObserver = new PerformanceObserver((list) => scanPerformanceEntries(list.getEntries()));
      resourceObserver.observe({ type: "resource", buffered: true });
    } catch {}
  }

  window.setInterval(periodicDiscovery, DISCOVERY_INTERVAL_MS);
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  let lastConnectionSignature = connectionSignature();
  function reportNetworkChange() {
    // effectiveType/rtt/downlink are traffic estimates, not route identity.
    // Probe traffic can change them; do not tear down a working route for that.
    const nextSignature = connectionSignature();
    if (nextSignature === lastConnectionSignature) return;
    lastConnectionSignature = nextSignature;
    startupTimeoutReports.clear();
    clearStartupBindings();
    window.postMessage({source:SOURCE,type:'route-reset',pageUrl:location.href},location.origin);
    send({ type: "network-changed", connection: connectionHint(), networkKey:connectionSignature() });
  }
  connection?.addEventListener?.("change", reportNetworkChange);
  window.addEventListener("online", reportNetworkChange);
  window.addEventListener("offline", reportNetworkChange);
  document.addEventListener('visibilitychange', () => { if (document.hidden) {cancelProbes();clearStartupBindings();} resetSeekEpisode(); resetFrameProgress(); });
  window.addEventListener('pagehide', () => { resumeGeneration += 1; resetAppliedRoute(); cancelProbes(); clearRecoveryWatchdog(); resetSeekEpisode(); window.clearTimeout(stallTimer); });
  window.addEventListener('pageshow', async event => {
    // BFCache restores the same browser document UUID. Only the native
    // persisted event may reactivate it; ordinary delayed messages cannot.
    if (event.isTrusted !== true || event.persisted !== true) return;
    const generation = ++resumeGeneration, pageUrl = location.href;
    const current = () => generation === resumeGeneration && playbackPageKey(pageUrl) === playbackPageKey(location.href);
    try {
      const reply = await chrome.runtime.sendMessage({type:'document-resumed',pageUrl,persisted:true});
      if (!current() || reply?.ok !== true || reply.ignored) return;
      lastRoutePolicyKey = '';
      configurationReady = readRouteConfiguration(current);
      if (await configurationReady && current()) replayKnownMedia(false);
    } catch {}
  });
  // Explicit user interaction cancels this narrowly scoped recovery watchdog.
  const userInteraction = () => {
    lastUserInteractionAt = Date.now();
    clearStartupBindings();
    if (activeVideo?.seeking) userSeek = true;
    resetSeekEpisode();
    clearRecoveryWatchdog();
  };
  window.addEventListener("pointerdown", userInteraction, { capture: true });
  window.addEventListener("keydown", userInteraction, { capture: true });
})();
