import { CDN_CATALOG } from './cdn-catalog.js';
import { DEFAULT_CANDIDATES, isCdnTargetHost, uniqueHosts } from './engine.js';

export const CORE_HOSTS = Object.freeze([...DEFAULT_CANDIDATES,
  'upos-sz-mirrorcos.bilivideo.com', 'upos-sz-mirrorhw.bilivideo.com',
  'upos-tf-all-hw.bilivideo.com', 'upos-tf-all-tx.bilivideo.com', 'upos-sz-mirrorali.bilivideo.com', 'upos-sz-mirror08ct.bilivideo.com']);
export const CATALOG_HOSTS = Object.freeze(uniqueHosts([...CORE_HOSTS, ...CDN_CATALOG.map(x => x.host)], 1024));
const regions = new Map(CDN_CATALOG.map(item => [item.host,item.region]));
const portableHosts = CATALOG_HOSTS.filter(host=>/^upos-(?:sz|tf)-/.test(host));
// Emergency recovery is not a catalog crawl. These portable alternatives come
// from the existing MIT catalog; their order is a shortlist, not speed proof.
const emergencyPortable = host => /^upos-(?:sz|tf)-/.test(host) && isCdnTargetHost(host);
const emergencySeeds = Object.freeze(uniqueHosts([
  'upos-sz-mirrorhw.bilivideo.com', 'upos-sz-mirrorali.bilivideo.com',
  'upos-sz-mirror08c.bilivideo.com', 'upos-sz-mirrorcos.bilivideo.com',
  'upos-sz-mirror08h.bilivideo.com', 'upos-sz-mirror08disp.bilivideo.com',
  'upos-sz-mirror08ct.bilivideo.com',
  ...CORE_HOSTS,
], 16).filter(host => CATALOG_HOSTS.includes(host) && emergencyPortable(host)));

export function emergencyCandidates(state, settings, limit = 4, preferredSeed = '') {
  const count = Math.max(0, Math.min(4, Math.trunc(Number(limit) || 0)));
  if (!count) return [];
  const excluded = new Set([
    ...(settings.disabledHosts || []), ...(state.failedHosts || []),
    ...(state.recoveryAttemptedHosts || []), state.selectedHost, state.actualHost,
  ]);
  const media = value => {
    try {
      const url = new URL(value);
      return ['http:', 'https:'].includes(url.protocol) && !url.port && !url.username && !url.password
        && url.pathname.includes('/upgcxcode/') ? url : null;
    } catch { return null; }
  };
  const path = media(state.sourceUrls?.[0])?.pathname || state.observedVideoPath;
  const native = [];
  // sourceUrls may already contain a rewritten host, whereas backupUrls is
  // indexed by the signed original. Match the video path, not the whole URL.
  for (const [source, backups] of state.backupUrls || []) {
    if (!path || media(source)?.pathname !== path) continue;
    for (const value of backups || []) {
      const url = media(value);
      if (url?.pathname === path && emergencyPortable(url.hostname)) native.push(url.hostname);
    }
  }
  const verified = (state.results || []).filter(item => item.ok && item.measuredThisVideo
    && state.verifiedHosts?.has(item.host) && emergencyPortable(item.host))
    .sort((a, b) => b.kbps - a.kbps).map(item => item.host);
  const nativeHosts = uniqueHosts(native, 4);
  // At most 16 distinct candidates per video. A candidate's real playback is
  // its trial; this order is not evidence that the 08 family is always faster.
  // Do not spend several consecutive native retry windows on the 08 family.
  // Try one ordinary mirror, then this track's signed native backups, before
  // exploring the remaining portable families. Still provisional, never a
  // fabricated benchmark winner or a permanent provider preference.
  // A caller may reorder an existing seed, never add a new candidate or skip
  // the shared queue cap/exclusions. Real same-video evidence remains first.
  const preferred = emergencySeeds.includes(preferredSeed) && !excluded.has(preferredSeed) ? [preferredSeed] : [];
  const queue = uniqueHosts([...verified, ...preferred, emergencySeeds[0],
    ...nativeHosts, ...emergencySeeds.slice(1)], 16);
  // Only a successfully applied target is consumed by the caller. Merely
  // returning a shortlist must not exhaust untried alternatives.
  return queue.filter(host => !excluded.has(host)).slice(0, count);
}
export function catalogOffset(trackPath, networkKey='') {
  let hash=2166136261;
  for(const char of String(trackPath)+'|'+String(networkKey))hash=Math.imul(hash^char.charCodeAt(0),16777619)>>>0;
  return hash%CATALOG_HOSTS.length;
}
export function selectCandidates(state, settings, limit = 8) {
  const disabled = new Set(settings.disabledHosts || []);
  const failed = state.failedHosts || new Set();
  const history = [...(state.results || [])].filter(x => x.ok).sort((a,b) => b.kbps-a.kbps).map(x => x.host);
  const round = Math.max(0, state.catalogCursor || 0);
  const allowed = host => isCdnTargetHost(host) && !disabled.has(host) && !failed.has(host);
  const primary = uniqueHosts([state.selectedHost, state.originalHost, ...(state.observedHosts || []),
    ...history, settings.manualHost, ...CORE_HOSTS].filter(allowed), Math.max(2,limit-2));
  const rest = [...CATALOG_HOSTS.slice(round), ...CATALOG_HOSTS.slice(0,round)].filter(host => allowed(host) && !primary.includes(host));
  const portable=[...portableHosts.slice(round%portableHosts.length),...portableHosts.slice(0,round%portableHosts.length)]
    .find(host=>allowed(host)&&!primary.includes(host));
  const explored=portable?[portable]:[],families=new Set(portable?[regions.get(portable)||portable]:[]);
  for(const host of rest){
    const family=regions.get(host)||host;
    if(families.has(family)||explored.includes(host))continue;
    explored.push(host);families.add(family);if(explored.length>=2)break;
  }
  return uniqueHosts([...primary,...explored,...rest],limit);
}
export function startupCandidates(state, settings) {
  const pool = selectCandidates(state, settings, 16);
  const preferred = [...(state.results || [])].filter(x => x.ok)
    .sort((a,b) => b.kbps-a.kbps).map(x => x.host)
    .find(host => host !== state.originalHost && pool.includes(host))
    || pool.find(host => host !== state.originalHost && state.observedHosts?.has(host))
    || pool.find(host => host !== state.originalHost && host.includes('cosov'))
    || pool.find(host => host !== state.originalHost);
  const native = [...(state.backupUrls?.get(state.sourceUrls?.[0]) || [])]
    .flatMap(url => { try { return [new URL(url).hostname]; } catch { return []; } })
    .find(host => host !== state.originalHost && host !== preferred && pool.includes(host))
    || pool.find(host => host !== state.originalHost && host !== preferred && state.observedHosts?.has(host));
  const chosen = [state.originalHost, preferred, native].filter(host => pool.includes(host));
  const round = Math.max(0, state.catalogCursor || 0);
  const exploration = [...portableHosts.slice(round%portableHosts.length), ...portableHosts.slice(0,round%portableHosts.length),
    ...CATALOG_HOSTS.slice(round), ...CATALOG_HOSTS.slice(0, round)]
    .find(host => !chosen.includes(host) && !(settings.disabledHosts || []).includes(host)
      && !state.failedHosts?.has(host));
  // History is a shortlist, not proof. Leave a slot for rotating exploration;
  // excluded/failed origins must not reduce the four-candidate recovery cap.
  return uniqueHosts([...chosen, exploration, ...pool].filter(Boolean), 4);
}
