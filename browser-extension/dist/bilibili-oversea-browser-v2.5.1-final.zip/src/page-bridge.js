(() => {
  "use strict";

  const SOURCE = "bili-cdn-auto-page-v2";
  const PLAYURL_PATTERN = /(?:\/playurl|\/play\/url)(?:\?|$)/i;
  const MAX_URLS = 8;
  const mediaRequests = new WeakMap();
  const knownTracks = new Map();
  let startupEnabled = false;
  let earlyRouting = false;
  const startupGates = new Map();
  const pendingSends = new WeakMap();
  const activeXhrs = new Map();
  const activeFetches = new Set();
  let requestedVideoPath = '';

  function pageIdentity(value = location.href) {
    const page = new URL(value);
    return `${page.origin}${page.pathname.replace(/\/$/, '')}?p=${page.searchParams.get('p') || '1'}&ep_id=${page.searchParams.get('ep_id') || ''}`;
  }

  function startupGate(value) {
    if (earlyRouting || !startupEnabled || !mediaUrl(value)) return null;
    const path = new URL(String(value)).pathname;
    if (knownTracks.get(path) !== 'video') return null;
    const video = document.querySelector?.('video');
    if (Number(video?.currentTime) > 0.2) return null;
    // One budget per video, not per representation. Codec/quality retries share
    // the existing gate so repeated startup requests cannot stack two-second waits.
    const key = pageIdentity();
    if (startupGates.has(key)) return startupGates.get(key);
    const deadline = Date.now() + 2000;
    let finish;
    const promise = new Promise(resolve => { finish = resolve; });
    const gate = { path, promise, released: false, release() {
      if (gate.released) return;
      gate.released = true; window.clearTimeout(timer); finish();
    }};
    const timer = window.setTimeout(() => gate.release(), 2000);
    startupGates.set(key, gate);
    if (startupGates.size > 16) {
      const oldest = startupGates.keys().next().value;
      startupGates.get(oldest).release(); startupGates.delete(oldest);
    }
    window.postMessage({ source: SOURCE, type: 'startup-request', deadline, pageUrl: location.href }, location.origin);
    return gate;
  }

  function mediaUrl(value) {
    try {
      const url = new URL(String(value));
      return ["http:", "https:"].includes(url.protocol)
        && (
          url.hostname.toLowerCase().endsWith(".bilivideo.com")
          || url.hostname.toLowerCase().endsWith(".mcdn.bilivideo.cn")
          || url.hostname.toLowerCase() === "upos-hz-mirrorakam.akamaized.net"
        )
        && url.pathname.includes("/upgcxcode/");
    } catch {
      return false;
    }
  }

  function collectMediaUrls(root) {
    const output = [];
    const seenObjects = new WeakSet();
    const seenUrls = new Set();
    const queue = [root];
    let visited = 0;
    while (queue.length && output.length < MAX_URLS && visited < 4_000) {
      const value = queue.shift();
      visited += 1;
      if (typeof value === "string") {
        if (mediaUrl(value) && !seenUrls.has(value)) {
          seenUrls.add(value);
          output.push(value);
        }
        continue;
      }
      if (!value || typeof value !== "object" || seenObjects.has(value)) continue;
      seenObjects.add(value);
      queue.push(...(Array.isArray(value) ? value : Object.values(value)).slice(0, 200));
    }
    return output;
  }

  function collectMediaTracks(root) {
    const tracks = new Map();
    const seen = new WeakSet();
    const queue = [root];
    let visited = 0;
    while (queue.length && visited++ < 4_000 && tracks.size < 128) {
      const value = queue.shift();
      if (!value || typeof value !== "object" || seen.has(value)) continue;
      seen.add(value);
      for (const kind of ["video", "audio"]) {
        for (const track of Array.isArray(value.dash?.[kind]) ? value.dash[kind].slice(0, 32) : []) {
          const urls = collectMediaUrls(track);
          for (const url of urls) {
            if (tracks.size < 128) tracks.set(url, { url, kind,
              ...(Number(track.bandwidth)>0 ? {bandwidth:Number(track.bandwidth)} : {}),
              ...(urls.length > 1 ? { backups: urls.filter(backup => backup !== url) } : {}) });
          }
        }
      }
      queue.push(...(Array.isArray(value) ? value : Object.values(value)).slice(0, 200));
    }
    return [...tracks.values()];
  }

  function announce(payload, reason = "playurl", pageUrl = location.href) {
    const urls = collectMediaUrls(payload);
    const tracks = collectMediaTracks(payload);
    for (const track of tracks) {
      knownTracks.set(new URL(track.url).pathname, track.kind);
      if (knownTracks.size > 512) knownTracks.delete(knownTracks.keys().next().value);
    }
    if (urls.length) window.postMessage({ source: SOURCE, type: "media-urls", reason, urls, tracks, pageUrl }, location.origin);
  }

  function looksLikePlayurl(value) {
    try {
      return PLAYURL_PATTERN.test(new URL(String(value), location.href).pathname);
    } catch {
      return false;
    }
  }

  function rangeStart(range) {
    const start = Number(String(range || "").match(/^bytes=(\d+)-/i)?.[1] || 0);
    return Number.isSafeInteger(start) && start >= 0 && start <= 2 ** 40 ? start : 0;
  }

  function observeResponse(value, originalUrl, startByte = 0, pageUrl = location.href) {
    if (mediaUrl(value)) window.postMessage({ source: SOURCE, type: "media-observed", urls: [value], pageUrl,
      originals: [{ url: value, originalUrl: mediaUrl(originalUrl) ? String(originalUrl) : value, startByte }] }, location.origin);
  }

  function observeRequest(url, startByte = 0) {
    if (!mediaUrl(url)) return;
    const path = new URL(String(url)).pathname;
    // SSR playinfo is usually assigned after our document-start microtask.
    // Bootstrap at the real request, not ten seconds later or at body completion.
    if (!knownTracks.has(path)) announce(window.__playinfo__, "request-bootstrap");
    const kind = knownTracks.get(path);
    if (kind === 'video') requestedVideoPath = path;
    window.postMessage({ source: SOURCE, type: "media-requested", urls: [String(url)], pageUrl: location.href,
      tracks: kind ? [{ url: String(url), kind }] : [],
      originals: [{ url: String(url), originalUrl: String(url), startByte }] }, location.origin);
  }

  const nativeFetch = window.fetch;
  if (typeof nativeFetch === "function") {
    window.fetch = async function biliCdnAutoFetch(input, init) {
      const pageUrl = location.href;
      const requestUrl = typeof input === "string" || input instanceof URL ? input : input?.url;
      const headers = typeof Headers === "function" ? new Headers(init?.headers || input?.headers) : null;
      // Bootstrap track descriptors before deciding whether the actual request is video.
      if (mediaUrl(requestUrl) && !knownTracks.has(new URL(String(requestUrl)).pathname)) announce(window.__playinfo__, 'request-bootstrap');
      const gate = startupGate(requestUrl);
      observeRequest(requestUrl, rangeStart(headers?.get("range")));
      const signal = init?.signal || input?.signal;
      if (gate && !gate.released) {
        let abort;
        try {
          await Promise.race([gate.promise, new Promise((_, reject) => {
            abort = () => reject(new DOMException('Request aborted', 'AbortError'));
            if (signal?.aborted) abort();
            else signal?.addEventListener('abort', abort, { once: true });
          })]);
        } finally { signal?.removeEventListener('abort', abort); }
      }
      if (signal?.aborted) throw new DOMException('Request aborted', 'AbortError');
      if (gate && pageIdentity() !== pageIdentity(pageUrl)) throw new DOMException('Page changed', 'AbortError');
      // Routing rules only affect future requests. Give confirmed recovery a
      // way to cancel a stuck current video transfer, without touching audio,
      // API traffic or the caller's abort semantics. Consumed responses are
      // harmless to abort; bounded entries retain no response bodies.
      let transfer;
      let options = init;
      if (mediaUrl(requestUrl) && knownTracks.get(new URL(String(requestUrl)).pathname) === 'video'
        && typeof AbortController === 'function'
        && (!signal || (typeof AbortSignal === 'function' && typeof AbortSignal.any === 'function'))) {
        const controller = new AbortController();
        transfer = {controller,path:new URL(String(requestUrl)).pathname,page:pageIdentity(pageUrl),
          host:new URL(String(requestUrl)).hostname,started:globalThis.performance?.now?.() ?? Date.now()};
        activeFetches.add(transfer);
        if (activeFetches.size > 64) activeFetches.delete(activeFetches.values().next().value);
        options = {...init,signal:signal ? AbortSignal.any([signal,controller.signal]) : controller.signal};
      }
      let response;
      try { response = await nativeFetch.call(this, input, options); }
      catch (error) { if (transfer) activeFetches.delete(transfer); throw error; }
      if (looksLikePlayurl(requestUrl)) response.clone().json().then((value) => announce(value, "fetch", pageUrl)).catch(() => {});
      if (mediaUrl(requestUrl)) {
        observeResponse(response.url, requestUrl, rangeStart(headers?.get("range")), pageUrl);
      }
      return response;
    };
  }

  const nativeOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function biliCdnAutoOpen(method, url, ...rest) {
    activeXhrs.delete(this);
    pendingSends.get(this)?.cancel();
    mediaRequests.delete(this);
    const pageUrl = location.href;
    if (looksLikePlayurl(url)) {
      this.addEventListener("load", () => {
        try {
          announce(this.responseType === "json" ? this.response : JSON.parse(this.responseText), "xhr", pageUrl);
        } catch {}
      }, { once: true });
    } else if (mediaUrl(url)) {
      mediaRequests.set(this, { originalUrl: String(url), startByte: 0, pageUrl, async: rest[0] !== false });
      this.addEventListener("load", () => {
        const request = mediaRequests.get(this);
        observeResponse(this.responseURL, request?.originalUrl, request?.startByte || 0, request?.pageUrl);
      }, { once: true });
    }
    return nativeOpen.call(this, method, url, ...rest);
  };

  const nativeSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  if (typeof nativeSetRequestHeader === "function") {
    XMLHttpRequest.prototype.setRequestHeader = function biliCdnAutoHeader(name, value) {
      if (String(name).toLowerCase() === "range" && mediaRequests.has(this)) mediaRequests.get(this).startByte = rangeStart(value);
      return nativeSetRequestHeader.call(this, name, value);
    };
  }

  const nativeSend = XMLHttpRequest.prototype.send;
  if (typeof nativeSend === "function") {
    XMLHttpRequest.prototype.send = function biliCdnAutoSend(...args) {
      const request = mediaRequests.get(this);
      if (request && !knownTracks.has(new URL(request.originalUrl).pathname)) announce(window.__playinfo__, 'request-bootstrap');
      const gate = request?.async ? startupGate(request.originalUrl) : null;
      if (request) observeRequest(request.originalUrl, request.startByte);
      const dispatch = () => {
        if (request?.async && knownTracks.get(new URL(request.originalUrl).pathname) === 'video') {
          const entry = {path:new URL(request.originalUrl).pathname,page:pageIdentity(request.pageUrl),
            host:new URL(request.originalUrl).hostname,started:globalThis.performance?.now?.() ?? Date.now()};
          activeXhrs.set(this,entry);
          this.addEventListener('loadend', () => { if (activeXhrs.get(this) === entry) activeXhrs.delete(this); }, {once:true});
        }
        return nativeSend.apply(this,args);
      };
      if (gate && !gate.released) {
        const identity = pageIdentity();
        const pending = { cancelled: false, cancel() { pending.cancelled = true; } };
        pendingSends.set(this, pending);
        gate.promise.then(() => {
          if (pendingSends.get(this) === pending) pendingSends.delete(this);
          if (!pending.cancelled && identity === pageIdentity()) dispatch();
        }).catch(() => { nativeAbort?.call(this); });
        return;
      }
      return dispatch();
    };
  }
  const nativeAbort = XMLHttpRequest.prototype.abort;
  if (typeof nativeAbort === 'function') XMLHttpRequest.prototype.abort = function(...args) {
    activeXhrs.delete(this);
    pendingSends.get(this)?.cancel(); pendingSends.delete(this);
    return nativeAbort.apply(this, args);
  };

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== SOURCE) return;
    if (event.data.type === 'route-recovery' && event.data.confirmedEmpty === true && event.data.pageUrl
      && Number.isFinite(event.data.cutoff)
      && (!event.data.path || event.data.path === requestedVideoPath)
      && pageIdentity(event.data.pageUrl) === pageIdentity()) {
      // MAIN already routes the player's own retries. Let its optional seek
      // own cancellation too: a second abort can kill a rewritten new request
      // whose caller URL still names the old host. Legacy DNR keeps its cutoff.
      if (earlyRouting) return;
      const stale=request=>request.page===pageIdentity() && request.path===requestedVideoPath
        && request.started < event.data.cutoff && request.host !== event.data.targetHost;
      for (const [xhr,request] of activeXhrs) if (stale(request)) {
        activeXhrs.delete(xhr); pendingSends.get(xhr)?.cancel(); nativeAbort?.call(xhr);
      }
      for (const transfer of activeFetches) if (stale(transfer)) {
        activeFetches.delete(transfer); transfer.controller.abort();
      }
    }
    if (event.data.type === 'route-policy') {
      // Mode and destination are independent. An empty MAIN target means
      // passive native passthrough, not permission to revive the legacy gate
      // or its second cancellation path while the worker still owns routing.
      earlyRouting = event.data.enabled === true;
      if (earlyRouting) for (const gate of startupGates.values()) gate.release();
    }
    if (event.data.type === 'startup-policy') {
      startupEnabled = event.data.enabled === true;
      if (!startupEnabled) for (const gate of startupGates.values()) gate.release();
    }
    if (event.data.type === 'startup-ready') {
      for (const gate of startupGates.values()) if (!event.data.path || gate.path === event.data.path) gate.release();
    }
    if (event.source === window && event.data?.source === SOURCE && event.data?.type === "rescan") {
      announce(window.__playinfo__, "rescan");
    }
  });

  for (const method of ["pushState", "replaceState"]) {
    const native = window.history?.[method];
    if (typeof native !== "function") continue;
    window.history[method] = function biliCdnAutoHistory(...args) {
      const previous = pageIdentity();
      const result = native.apply(this, args);
      if (previous !== pageIdentity()) {
        for (const gate of startupGates.values()) gate.release();
        startupGates.clear();
        knownTracks.clear();
        activeXhrs.clear(); activeFetches.clear(); requestedVideoPath = '';
      }
      window.postMessage({ source: SOURCE, type: "page-changed", url: location.href }, location.origin);
      return result;
    };
  }

  queueMicrotask(() => announce(window.__playinfo__, "initial"));
  document.addEventListener("DOMContentLoaded", () => announce(window.__playinfo__, "dom-ready"), { once: true });
})();
