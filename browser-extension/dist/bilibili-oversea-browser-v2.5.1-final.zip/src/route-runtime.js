// Independent, passive-first media routing. No third-party implementation is included.
(() => {
  'use strict';
  const SOURCE='bili-cdn-auto-page-v2';
  const pageKey=(value=location.href)=>{try{const u=new URL(value);return u.origin+u.pathname.replace(/\/$/,'')+'?p='+Math.max(1,Number.parseInt(u.searchParams.get('p'),10)||1)+'&ep_id='+(u.searchParams.get('ep_id')||'');}catch{return '';}};
  let policy={enabled:false,host:'',automatic:false}, identity=pageKey(),lastInventory='',requestOrder=0;
  const tracks=new Map(), originals=new Map(), failed=new Set(), xhrs=new WeakMap(), startup=new Map();
  let lastInteraction=-Infinity, startupPath='',connectionHint=null,priorPlayback=false;
  const zeroResponses=new Map();
  let zeroEpoch=0,nativeEpoch=0,activeAudioPath='';
  const watchedPlayers=new WeakMap();
  const clearZeroResponses=()=>{zeroResponses.clear();zeroEpoch++;};
  const invalidateUnstarted=()=>{clearZeroResponses();nativeEpoch++;};
  const clearZeroEntry=entry=>{const token=entry.zeroToken;if(token&&zeroResponses.get(token.key)===token)zeroResponses.delete(token.key);};
  const clearZeroTrack=(kind,path)=>{for(const [key,token]of zeroResponses)if(token.kind===kind&&token.path===path)zeroResponses.delete(key);};
  const clock=()=>performance.now();
  if(typeof document!=='undefined')for(const name of ['pointerdown','keydown','touchstart'])
    document.addEventListener(name,e=>{if(e.isTrusted){lastInteraction=clock();invalidateUnstarted();}},{capture:true,passive:true});
  if(typeof document!=='undefined')document.addEventListener('visibilitychange',()=>{if(document.hidden)invalidateUnstarted();});
  window.addEventListener('pagehide',invalidateUnstarted);
  const media=u=>{try{const x=new URL(String(u));return /^https?:$/.test(x.protocol)&&x.pathname.startsWith('/upgcxcode/')&&(x.hostname.endsWith('.bilivideo.com')||x.hostname==='upos-hz-mirrorakam.akamaized.net'||x.hostname.endsWith('.mcdn.bilivideo.cn'));}catch{return false;}};
  const host=h=>typeof h==='string'&&h.length<=253&&h.endsWith('.bilivideo.com')&&h.split('.').every(x=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(x));
  const post=(type,data={})=>window.postMessage({source:SOURCE,type,pageUrl:location.href,...data},location.origin);
  function syncPage(){if(identity!==pageKey()){identity=pageKey();tracks.clear();originals.clear();failed.clear();startup.clear();priorPlayback=false;startupPath='';activeAudioPath='';lastInventory='';requestOrder=0;clearZeroResponses();}}
  function hintConnection(){
    // Only warm the chosen origin. This hint never fetches media, waits for a
    // response, changes XHR credentials, or proves that a route is healthy.
    const origin=policy.enabled&&host(policy.host)?'https://'+policy.host+'/':'';
    if(connectionHint?.href===origin)return;
    connectionHint?.remove();connectionHint=null;
    if(!origin||typeof document==='undefined'||!document.createElement)return;
    const parent=document.head||document.documentElement;if(!parent)return;
    try{const link=document.createElement('link');link.rel='preconnect';link.crossOrigin='anonymous';link.href=origin;
      parent.appendChild(link);connectionHint=link;}catch{}
  }
  if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',hintConnection,{once:true});
  function frameCounts(video){
    try{
      const q=video.getVideoPlaybackQuality?.(),total=q?.totalVideoFrames??video.webkitDecodedFrameCount,
        dropped=q?.droppedVideoFrames??video.webkitDroppedFrameCount??0;
      return Number.isFinite(total)&&Number.isFinite(dropped)&&total>=dropped&&dropped>=0?{total,displayed:total-dropped}:null;
    }catch{return null;}
  }
  function observePlayer(){
    if(typeof document==='undefined')return null;
    const video=document.querySelector('#bilibili-player video, #bilibiliPlayer video, .bpx-player-container video')||document.querySelector('video');
    if(!video)return null;
    // This page/part latch survives decoder, element and quality resets. A
    // later zero frame counter must not turn mid-play failure into first start.
    const noteProgress=()=>{
      if(identity!==pageKey())return;
      if(Number(video.currentTime)>.01||frameCounts(video)?.displayed>0)priorPlayback=true;
    };
    if(watchedPlayers.get(video)!==identity){
      const page=identity;watchedPlayers.set(video,page);
      const current=()=>page===identity&&page===pageKey()&&(document.querySelector('#bilibili-player video, #bilibiliPlayer video, .bpx-player-container video')||document.querySelector('video'))===video;
      video.addEventListener?.('playing',()=>{if(current()){priorPlayback=true;invalidateUnstarted();}},{passive:true});
      video.addEventListener?.('timeupdate',()=>{if(current())noteProgress();},{passive:true});
      for(const event of ['pause','seeking','emptied','ended'])video.addEventListener?.(event,()=>{if(current())invalidateUnstarted();},{passive:true});
    }
    noteProgress();return video;
  }
  function startupPlayer(){
    const video=observePlayer(),frames=video&&frameCounts(video);
    if(!video||priorPlayback||document.hidden!==false||clock()-lastInteraction<1500
      ||video.paused!==false||video.seeking!==false||video.ended!==false||video.readyState!==0
      ||!Number.isFinite(video.currentTime)||video.currentTime<0||video.currentTime>=.01||video.buffered?.length!==0
      ||!frames||frames.total!==0||frames.displayed!==0)return null;
    return video;
  }
  function unstartedAudioSnapshot(){
    // Metadata is not a displayed frame. This exception requires positively
    // observed zero counters; unavailable frame APIs cannot prove first start.
    const video=observePlayer(),frames=video&&frameCounts(video);
    if(!video||priorPlayback||document.hidden||clock()-lastInteraction<1500
      ||video.paused||video.seeking||video.ended||![0,1].includes(video.readyState)||!frames||frames.total!==0||frames.displayed!==0
      ||!Number.isFinite(video.currentTime)||video.currentTime<0||video.currentTime>=.01||video.buffered?.length)return null;
    return {video,time:video.currentTime,frames:0,mode:'startup-audio'};
  }
  function recordStartup(entry,sending=false){
    if(!media(entry.target))return;
    const path=new URL(entry.target).pathname;
    if(tracks.get(path)?.kind!=='video')return;
    if(sending){startupPath=path;entry.startupVideo=observePlayer();entry.nativeEpoch=nativeEpoch;}
    let state=startup.get(path);
    if(!state){state={received:false,page:pageKey(),reportedHosts:new Set()};startup.set(path,state);}
    entry.startup=state;
  }
  function nativeStartupEvent(entry,nativeEvent){
    const state=entry.startup,elapsedMs=clock()-entry.start,video=startupPlayer();
    if(!state||state.received||entry.headersReceived||entry.bytes>0||!Number.isFinite(elapsedMs)||elapsedMs<1800
      ||entry.page!==pageKey()||state.page!==pageKey()||entry.nativeEpoch!==nativeEpoch||!video||video!==entry.startupVideo
      ||!policy.enabled||!policy.automatic)return;
    const target=new URL(entry.target);
    if(target.pathname!==startupPath||tracks.get(target.pathname)?.kind!=='video'||startup.get(target.pathname)!==state
      ||target.hostname!==policy.host||state.reportedHosts.has(target.hostname))return;
    // The native player has already cancelled/timed out this one request.
    // No wall-clock timer, active abort, synthetic seek or new probe is added.
    // Report each actually attempted host once for this track. This is not a
    // controller budget and does not change the route() failure suppression.
    state.reportedHosts.add(target.hostname);
    post('route-startup-timeout',{url:entry.target,originalUrl:entry.source,kind:'video',reason:'startup-native-zero-response',nativeEvent,elapsedMs,aborts:1});
  }
  function playingSnapshot(){
    const video=observePlayer();
    if(typeof document==='undefined'||document.hidden||clock()-lastInteraction<1500)return null;
    if(!video||video.paused||video.seeking||video.ended||video.readyState<2||!(video.currentTime>.01))return null;
    let buffered=false,frames=null;
    try{for(let i=0;i<video.buffered.length;i++)if(video.buffered.start(i)<=video.currentTime&&video.buffered.end(i)>video.currentTime+.05){buffered=true;break;}}catch{}
    if(!buffered)return null;
    try{const q=video.getVideoPlaybackQuality?.();
      if(Number.isFinite(q?.totalVideoFrames))frames=q.totalVideoFrames-(Number(q.droppedVideoFrames)||0);
      else if(Number.isFinite(video.webkitDecodedFrameCount))frames=video.webkitDecodedFrameCount-(Number(video.webkitDroppedFrameCount)||0);
    }catch{}
    return {video,time:video.currentTime,frames,mode:'playing'};
  }
  function beginZeroResponseWatch(entry){
    if(!media(entry.target))return;
    const target=new URL(entry.target),kind=tracks.get(target.pathname)?.kind;
    if(!['video','audio'].includes(kind))return;
    if(!policy.enabled||!policy.automatic){clearZeroResponses();return;}
    if(target.hostname!==policy.host)return;
    // Ambiguous Range headers cannot bridge two otherwise valid observations.
    // A different valid Range, however, owns an independent retry ledger.
    if(!entry.range){clearZeroTrack(kind,target.pathname);return;}
    if(kind==='audio'&&(!entry.videoPath||entry.videoPath!==startupPath||target.pathname!==activeAudioPath))return;
    const playing=playingSnapshot(),initial=playing?null:unstartedAudioSnapshot();
    const snapshot=playing||(kind==='audio'&&Number(entry.range.match(/^bytes=(\d+)-/)?.[1])>0?initial:null);
    if(!snapshot){if(!initial)clearZeroResponses();return;}
    const now=clock(),key=target.hostname+'|'+kind+'|'+target.pathname+'|'+entry.range+'|'+snapshot.mode;
    for(const [oldKey,token]of zeroResponses)if(now-token.first>15000)zeroResponses.delete(oldKey);
    let token=zeroResponses.get(key);
    if(!token){
      // Bounded passive state only; no request, polling timer or wider scan.
      while(zeroResponses.size>=16)zeroResponses.delete(zeroResponses.keys().next().value);
      token={key,kind,path:target.pathname,mode:snapshot.mode,first:entry.start,attempts:0,elapsedMs:0};zeroResponses.set(key,token);
    }
    entry.zeroToken=token;entry.zeroEpoch=zeroEpoch;entry.playingAtSend=snapshot;
  }
  function cancelledZeroResponse(entry){
    const token=entry.zeroToken;
    // A completed, evicted or expired attempt must never recreate its ledger.
    if(entry.zeroEpoch!==zeroEpoch||!token||zeroResponses.get(token.key)!==token)return;
    const before=entry.playingAtSend,now=token.mode==='startup-audio'?unstartedAudioSnapshot():playingSnapshot(),target=new URL(entry.target),elapsed=clock()-entry.start;
    if(!before||!now||now.video!==before.video||entry.page!==pageKey()||!policy.enabled||!policy.automatic||target.hostname!==policy.host){clearZeroResponses();return;}
    if(clock()-token.first>15000||entry.headersReceived||entry.bytes>0||elapsed<1800
      ||(token.kind==='video'?target.pathname!==startupPath:target.pathname!==activeAudioPath||entry.videoPath!==startupPath)){
      clearZeroEntry(entry);return;
    }
    if(token.mode==='playing'&&(now.time-before.time<.05||before.frames!==null&&(now.frames===null||now.frames<=before.frames))){clearZeroResponses();return;}
    token.attempts++;token.elapsedMs+=elapsed;
    if(token.attempts>=2){
      if(token.mode==='startup-audio'){
        const state=startup.get(entry.videoPath),key=target.hostname+'|'+target.pathname;
        if(state&&state.page===pageKey()&&!failed.has(key)){
          // Only report the real audio failure. The finite queue changes
          // future routing; the native player owns retries and play intent.
          failed.add(key);
          post('route-startup-timeout',{url:entry.target,originalUrl:entry.source,kind:'audio',videoPath:entry.videoPath,
            reason:'startup-audio-zero-response',attempts:token.attempts,aborts:token.attempts,elapsedMs:token.elapsedMs});
        }
        clearZeroResponses();return;
      }
      // Native retries already proved this exact segment unresponsive while
      // playback still has buffer. Change only future routing, never the player.
      failure(entry.source,entry.target,0,{reason:'repeated-zero-response',attempts:token.attempts,elapsedMs:token.elapsedMs,
        ...(token.kind==='audio'?{videoPath:entry.videoPath}:{})});
      clearZeroResponses();
    }
  }
  function bindActiveTrack(entry){
    if(!media(entry.target))return;
    const path=new URL(entry.target).pathname,kind=tracks.get(path)?.kind;
    if(kind==='video'&&path!==startupPath){activeAudioPath='';invalidateUnstarted();}
    if(kind==='audio'){
      if(activeAudioPath!==path)clearZeroTrack('audio',activeAudioPath);
      activeAudioPath=path;entry.videoPath=startupPath;
    }
  }
  function original(u){return originals.get(String(u))||String(u);}
  function route(u){
    if(!media(u))return String(u);
    syncPage();const source=original(u),path=new URL(source).pathname;
    if(!policy.enabled||!host(policy.host)||failed.has(policy.host+'|'+path))return source;
    const target=new URL(source);target.hostname=policy.host;
    originals.set(target.href,source);if(originals.size>1024)originals.delete(originals.keys().next().value);
    return target.href;
  }
  function used(source,target,videoPath=startupPath){
    if(!media(source)||!media(target)||!policy.enabled||!host(policy.host)||new URL(target).hostname!==policy.host)return;
    const t=tracks.get(new URL(source).pathname);
    if(t)post('route-used',{url:target,originalUrl:source,kind:t.kind,bandwidth:t.bandwidth||0,requestOrder:++requestOrder,
      ...(t.kind==='audio'?{videoPath}:{})});
  }
  function failure(source,target,status,details={}){
    if(!media(target))return;
    // The player may itself choose our preferred host. Its failure must still
    // stop us rewriting a native backup back to that same failed destination.
    if(source===target&&(!policy.enabled||new URL(target).hostname!==policy.host))return;
    const path=new URL(target).pathname,key=new URL(target).hostname+'|'+path;
    if(failed.has(key))return;failed.add(key);
    post('route-failed',{url:target,originalUrl:source,kind:tracks.get(path)?.kind||'unknown',status,...details});
  }
  function completedEofRange(xhr,entry,bytes,status){
    if(status!==206||entry.aborted||entry.rangeCount!==1||!Number.isSafeInteger(bytes)||typeof getResponseHeader!=='function')return null;
    try{
      const request=/^bytes=(\d+)-(\d*)$/.exec(entry.range),raw=getResponseHeader.call(xhr,'Content-Range');
      const response=typeof raw==='string'&&/^bytes\s+(\d+)-(\d+)\/(\d+)$/i.exec(raw.trim());
      if(!request||!response)return null;
      const [start,end,total]=response.slice(1).map(Number),requestedStart=Number(request[1]),requestedEnd=request[2]?Number(request[2]):null;
      if(![start,end,total,requestedStart].every(Number.isSafeInteger)||requestedEnd!==null&&!Number.isSafeInteger(requestedEnd)
        ||start<=0||end<start||end+1!==total||requestedStart!==start||requestedEnd!==null&&requestedEnd!==end||bytes!==end-start+1)return null;
      return {start,end,total};
    }catch{return null;}
  }
  function delivered(source,target,bytes,elapsedMs,status,xhr,entry){
    const t=media(target)&&tracks.get(new URL(target).pathname);
    if(t?.kind==='video'&&status>=200&&status<300&&bytes>=1024*1024&&elapsedMs>0){
      // Only accessible native headers can prove EOF; CDP visibility or a
      // short body alone cannot. Never export the raw response header.
      const completedRange=completedEofRange(xhr,entry,bytes,status);
      post('route-delivered',{url:target,originalUrl:source,kind:'video',bytes,elapsedMs,bandwidth:t.bandwidth||0,status,
        ...(completedRange?{completedRange}:{})});
    }
  }
  function prepare(payload){
    if(!payload||typeof payload!=='object')return payload;
    syncPage();const queue=[payload],seen=new WeakSet(),descriptors=[];let count=0;
    while(queue.length&&count++<4000){
      const obj=queue.shift();if(!obj||typeof obj!=='object'||seen.has(obj))continue;seen.add(obj);
      for(const kind of ['video','audio'])for(const t of (Array.isArray(obj.dash?.[kind])?obj.dash[kind]:[])){
        const key=media(t.baseUrl)?'baseUrl':media(t.base_url)?'base_url':null;if(!key)continue;
        const base=original(t[key]),backups=(t.backupUrl||t.backup_url||[]).filter?.(media)||[];
        const path=new URL(base).pathname;tracks.set(path,{kind,bandwidth:Number(t.bandwidth)||0});
        descriptors.push({url:base,kind,bandwidth:Number(t.bandwidth)||0,backups});
        const target=route(base);
        // Both aliases must agree, while original signed URLs remain recoverable.
        if(target!==base){t[key]=target;if('baseUrl'in t)t.baseUrl=target;if('base_url'in t)t.base_url=target;
          const rest=[...new Set([base,...backups])].filter(x=>x!==target);t.backupUrl=rest;if('backup_url'in t)t.backup_url=rest;}
        else {t[key]=base;if('baseUrl'in t)t.baseUrl=base;if('base_url'in t)t.base_url=base;}
      }
      queue.push(...(Array.isArray(obj)?obj:Object.values(obj)).slice(0,200));
    }
    while(tracks.size>512)tracks.delete(tracks.keys().next().value);
    const signature=JSON.stringify(descriptors);
    if(descriptors.length&&signature!==lastInventory){lastInventory=signature;post('media-urls',{reason:'route-origin',tracks:descriptors.slice(0,128),urls:descriptors.slice(0,8).map(t=>t.url)});}
    return payload;
  }
  let playinfo=window.__playinfo__;
  try{const d=Object.getOwnPropertyDescriptor(window,'__playinfo__');if(!d||d.configurable){
    Object.defineProperty(window,'__playinfo__',{configurable:true,enumerable:true,get:()=>playinfo,set:v=>{playinfo=prepare(v);}});
    if(playinfo)prepare(playinfo);
  }}catch{}
  window.addEventListener('message',e=>{
    if(e.source!==window||e.origin!==location.origin||e.data?.source!==SOURCE)return;
    if(e.data.type==='route-reset'&&e.data.pageUrl&&pageKey(e.data.pageUrl)===pageKey()){
      failed.clear();for(const state of startup.values())state.reportedHosts.clear();invalidateUnstarted();
    }
    // Legacy/delayed controller commands are inert. Startup routing never
    // rebuilds the player or interrupts its original pending play promise.
    if(e.data.type==='startup-recovery')return;
    if(e.data.type==='route-policy'){
      if(e.data.pageUrl&&pageKey(e.data.pageUrl)!==pageKey())return;
      const next={enabled:e.data.enabled===true,host:host(e.data.host)?e.data.host:'',automatic:e.data.automatic===true};
      // An explicit new manual choice overrides this page's suppression for
      // that host only. Routine same-policy updates cannot erase a new hard
      // failure, and older messages without automatic are not manual intent.
      if(next.enabled&&next.host&&e.data.automatic===false
        &&(!policy.enabled||policy.automatic||next.host!==policy.host)){
        for(const key of failed)if(key.startsWith(next.host+'|'))failed.delete(key);
      }
      if(next.enabled!==policy.enabled||next.host!==policy.host||next.automatic!==policy.automatic){clearZeroResponses();nativeEpoch++;}
      policy=next;
      if(playinfo)prepare(playinfo);
      hintConnection();
      post('route-policy-applied',{host:policy.host,enabled:policy.enabled});
    }
  });
  const api=u=>{try{return /\/(?:x\/player\/(?:wbi\/)?playurl|pgc\/player\/web\/(?:v2\/)?playurl|pugv\/player\/web\/playurl)$/.test(new URL(String(u),location.href).pathname);}catch{return false;}};
  const fetch=window.fetch;
  if(typeof fetch==='function')window.fetch=async function(input,init){
    const value=typeof input==='string'||input instanceof URL?String(input):input?.url;
    const source=media(value)?original(value):value,target=media(value)?route(value):value;
    const request=target!==value?(typeof input==='string'||input instanceof URL?target:new Request(target,input)):input;
    used(source,target);
    let response;
    try{response=await fetch.call(this,request,init);}catch(error){
      if(error?.name==='AbortError')throw error;
      failure(source,target,0);
      if(source!==target)return fetch.call(this,typeof input==='string'||input instanceof URL?source:new Request(source,input),init);
      throw error;
    }
    if(media(target)&&[403,404,451,500,502,503,504].includes(response.status)){
      failure(source,target,response.status);
      // One bounded native retry, preserving the caller's Range and abort signal.
      if(source!==target){await response.body?.cancel().catch(()=>{});return fetch.call(this,typeof input==='string'||input instanceof URL?source:new Request(source,input),init);}
    }
    if(api(value)&&policy.enabled){try{
      const payload=await response.clone().json();prepare(payload);
      const headers=new Headers(response.headers);headers.delete('content-length');headers.delete('content-encoding');
      const replacement=new Response(JSON.stringify(payload),{status:response.status,statusText:response.statusText,headers});
      Object.defineProperty(replacement,'url',{value:response.url});return replacement;
    }catch{}}
    // Fetch bodies are not cloned/read just to measure speed. XHR completes give passive proof.
    return response;
  };
  const proto=XMLHttpRequest.prototype,open=proto.open,send=proto.send,abort=proto.abort,setRequestHeader=proto.setRequestHeader,getResponseHeader=proto.getResponseHeader,apiGetters=new WeakSet();
  const responseDescriptor=Object.getOwnPropertyDescriptor(proto,'response'),textDescriptor=Object.getOwnPropertyDescriptor(proto,'responseText');
  proto.open=function(method,url,...rest){
    if(apiGetters.has(this)){delete this.response;delete this.responseText;apiGetters.delete(this);}
    const source=media(url)?original(url):String(url),target=media(url)?route(url):url;
    const entry={source,target:String(target),bytes:0,start:0,lastProgressAt:-Infinity,headersReceived:false,range:'',rangeCount:0,aborted:false,page:pageKey()};xhrs.set(this,entry);
    const result=open.call(this,method,target,...rest);
    if(api(url)&&responseDescriptor&&textDescriptor){
      let prepared=false,cached,raw;
      const parse=()=>{if(prepared||this.readyState!==4)return;prepared=true;
        try{if(this.responseType==='json')cached=prepare(responseDescriptor.get.call(this));
          else if(!this.responseType||this.responseType==='text'){raw=textDescriptor.get.call(this);cached=JSON.stringify(prepare(JSON.parse(raw)));}}catch{}};
      try{Object.defineProperty(this,'response',{configurable:true,get:()=>{parse();return cached===undefined?responseDescriptor.get.call(this):cached;}});
        Object.defineProperty(this,'responseText',{configurable:true,get:()=>{parse();return typeof cached==='string'?cached:textDescriptor.get.call(this);}});apiGetters.add(this);}catch{}
    }
    if(media(target)){
      this.addEventListener('readystatechange',()=>{if(xhrs.get(this)===entry&&this.readyState>=2&&this.status>0){entry.headersReceived=true;if(entry.startup)entry.startup.received=true;if(entry.zeroEpoch===zeroEpoch)clearZeroEntry(entry);}});
      this.addEventListener('progress',e=>{if(xhrs.get(this)===entry&&e.loaded>entry.bytes){entry.bytes=e.loaded;entry.lastProgressAt=clock();if(entry.startup)entry.startup.received=true;if(entry.zeroEpoch===zeroEpoch)clearZeroEntry(entry);}});
      this.addEventListener('load',()=>{
        if(xhrs.get(this)!==entry||entry.page!==pageKey())return;
        if(this.status>=400)failure(source,String(target),this.status);
        else delivered(source,this.responseURL||String(target),entry.bytes||(this.response?.byteLength||0),performance.now()-entry.start,this.status,this,entry);
      },{once:true});
      this.addEventListener('error',()=>{if(xhrs.get(this)===entry&&!entry.aborted&&entry.page===pageKey())failure(source,String(target),0);},{once:true});
      this.addEventListener('timeout',()=>{
        if(xhrs.get(this)!==entry||entry.aborted||entry.page!==pageKey())return;
        if(entry.startup&&!entry.startup.received){
          if(startupPlayer()){
            nativeStartupEvent(entry,'timeout');
            // ISOLATED independently verifies this actual native deadline
            // before changing only future routing, including failed replacements.
            return;
          }
          if(entry.startup.reportedHosts.size)return;
        }
        // A player's total transfer deadline is not a dead connection. In a
        // real failure, 93% of a segment was still arriving at the 5s limit.
        // Preserve native same-route retry; frame/buffer health still applies.
        if(entry.bytes>0&&clock()-entry.lastProgressAt<1500)return;
        failure(source,String(target),0);
      },{once:true});
    }
    return result;
  };
  if(setRequestHeader)proto.setRequestHeader=function(name,value,...rest){
    const result=setRequestHeader.call(this,name,value,...rest),entry=xhrs.get(this);
    // Observe only an unambiguous Range. Native arguments, return and errors
    // remain unchanged; duplicate headers are merged by XHR, not by this observer.
    if(entry&&typeof name==='string'&&name.toLowerCase()==='range'){
      entry.rangeCount++;entry.range=entry.rangeCount===1&&typeof value==='string'&&/^bytes=\d+-\d*$/i.test(value.trim())?value.trim().toLowerCase():'';
    }
    return result;
  };
  proto.send=function(...args){const e=xhrs.get(this);if(e){e.start=performance.now();bindActiveTrack(e);recordStartup(e,true);beginZeroResponseWatch(e);used(e.source,e.target,e.videoPath);}return send.apply(this,args);};
  if(abort)proto.abort=function(...args){
    const e=xhrs.get(this);
    if(e&&!e.aborted){
      e.aborted=true;
      cancelledZeroResponse(e);
      const result=abort.apply(this,args);
      // Observe the completed native call, not merely a caller's intention.
      // Synchronous player handlers may already replace/reuse this request.
      if(xhrs.get(this)!==e)return result;
      if(e.startup&&!e.startup.received&&clock()-e.start>=1800)nativeStartupEvent(e,'abort');
      return result;
    }
    return abort.apply(this,args);
  };
})();
