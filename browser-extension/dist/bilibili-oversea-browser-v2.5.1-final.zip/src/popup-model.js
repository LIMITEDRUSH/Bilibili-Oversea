import { BILI_AKAMAI_HOST, isBiliMediaHost, uniqueHosts } from "./engine.js";
import { CATALOG_HOSTS, CORE_HOSTS } from './candidates.js';

const hostNames = [
  ["mirrorali", "阿里云"], ["mirrorcos", "腾讯云"], ["mirrorhw", "华为云"],
  ["mirrorakam", "Akamai"], ["mcdn", "B 站边缘"],
];

export function hostLabel(host) {
  if (!host) return "等待选择";
  if (host === 'upos-sz-mirror08ct.bilivideo.com') return '线路 08CT';
  if (host === 'upos-tf-all-hw.bilivideo.com') return '华为云 · 通用';
  if (host === 'upos-tf-all-tx.bilivideo.com') return '腾讯云 · 通用';
  for (const [part, name] of hostNames) {
    if (host.includes(part)) return name + (host.includes("ov.") ? " · 海外" : "");
  }
  return host;
}

export function speedLabel(kbps) {
  const value = Math.max(0, Number(kbps) || 0) / 1000;
  return new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 1 }).format(value) + " Mbps";
}

// Export a bounded reason code, never a server error containing signed URLs.
export function probeFailureReason(item) {
  if (item.ok) return '';
  if (item.error === 'playback buffer-low') return 'buffer-low';
  if (String(item.error || '').startsWith('playback ')) return 'playback-stall';
  if (item.error === 'sample throughput below video bitrate margin') return 'below-bitrate';
  if (item.error === 'incomplete startup sample') return 'incomplete-sample';
  if (/cancel|abort/i.test(item.error || '')) return 'cancelled';
  if (/timeout|timed out/i.test(item.error || '')) return 'timeout';
  if (Number(item.status) >= 400) return 'http-error';
  if (Number(item.status) >= 200 && Number(item.status) < 300) return 'sample-rejected';
  return 'request-incomplete';
}

export function nodeMetrics(item, passthrough = false) {
  if (item.readOnly) return '不参与测速或固定';
  if (item.untested) return passthrough ? '未参与测速' : '未测速';
  const prefix = item.measuredThisVideo === true ? '本视频 · ' : '历史 · ';
  if (item.ok) return prefix + (item.stage === 'playback' ? '实播 · ' + speedLabel(item.kbps)
    : speedLabel(item.kbps) + ' · ' + Math.round(Number(item.ttfbMs) || 0) + ' ms');
  const reason = probeFailureReason(item);
  const text = {'below-bitrate':'速度不足', 'incomplete-sample':'样本不足', cancelled:'已取消',
    timeout:'测试超时', 'http-error':'HTTP ' + (Number(item.status) || 0),
    'sample-rejected':'样本未通过', 'request-incomplete':'请求未完成',
    'buffer-low':'缓冲不足', 'playback-stall':'播放停滞'}[reason];
  return prefix + text + (item.kbps > 0 ? ' · ' + speedLabel(item.kbps) : '');
}

export function popupRows(settings, state, { candidateHosts = [], scope = 'preferred', query = '' } = {}) {
  const rows = new Map((state?.results || []).map(item => [item.host, { ...item }]));
  const observed = uniqueHosts([state?.originalHost, state?.actualHost, ...candidateHosts], 12);
  const selected = uniqueHosts([state?.selectedHost], 1);
  // Discovery and measurements are different: never hide a real candidate
  // merely because no result exists yet, or after native passthrough clears it.
  if (scope === 'all' || state?.lastDetectedAt || observed.length || selected.length || rows.size) {
    const directory = scope === 'all' ? CATALOG_HOSTS : CORE_HOSTS;
    for (const host of uniqueHosts([state?.originalHost, ...selected, ...directory, ...observed], 1024)) {
      if (!rows.has(host)) rows.set(host, { host, ok: false, untested: true, kbps: 0,
        observed: observed.includes(host), preset: CORE_HOSTS.includes(host) });
    }
  }
  if ([state?.originalHost, state?.actualHost, ...candidateHosts].includes(BILI_AKAMAI_HOST)) {
    rows.set(BILI_AKAMAI_HOST, { host: BILI_AKAMAI_HOST, ok: false, untested: true, readOnly: true, observed: true, kbps: 0 });
  }
  for (const host of settings.disabledHosts || []) {
    if (!rows.has(host)) rows.set(host, { host, ok: false, untested: true, kbps: 0 });
  }
  const disabled = new Set(settings.disabledHosts || []);
  const verified = new Set(state?.verifiedHosts || []);
  return [...rows.values()].map(item => ({...item, currentVideoVerified:verified.has(item.host)}))
    .filter(item => !query || (item.host+' '+hostLabel(item.host)).toLowerCase().includes(query.toLowerCase().trim()))
    .sort((a, b) => Number(disabled.has(a.host)) - Number(disabled.has(b.host))
    || Number(b.currentVideoVerified) - Number(a.currentVideoVerified)
    || Number(b.ok) - Number(a.ok) || Number(a.untested === true) - Number(b.untested === true)
    || (Number(b.kbps) || 0) - (Number(a.kbps) || 0));
}

export function diagnostics(settings, state, version) {
  const host = (value) => isBiliMediaHost(value) ? value : "";
  return {
    version, enabled: settings.enabled, mode: settings.mode, phase: state?.phase || "waiting",
    selectedHost: host(state?.selectedHost), actualHost: host(state?.actualHost),
    originalHost: host(state?.originalHost),
    videoTrackKnown: state?.videoTrackKnown === true,
    startupAttempted: state?.startupAttempted === true,
    recoveryPolicy: state?.recoveryPolicy === 'empty-buffer-only' ? 'empty-buffer-only' : 'unknown',
    startupProbePolicy: ['split-range','passive-first'].includes(state?.startupProbePolicy) ? state.startupProbePolicy : 'unknown',
    lastQuickTestedAt: Number(state?.lastQuickTestedAt) || 0,
    passthroughReason: state?.passthroughReason === 'baseline-akamai' ? 'baseline-akamai' : '',
    sourceKind: ["video", "audio"].includes(state?.sourceKind) ? state.sourceKind : "unknown",
    ruleInstalled: state?.ruleInstalled === true,
    routeMechanism: state?.routeMechanism === 'pre-route' ? 'pre-route' : 'verified-rule',
    routeVerified: state?.routeVerified === true,
    results: (state?.results || []).map((item) => ({
      host: host(item.host), ok: item.ok === true, kbps: Number(item.kbps) || 0,
      ttfbMs: Number(item.ttfbMs) || 0, status: Number(item.status) || 0,
      measuredThisVideo: item.measuredThisVideo === true,
      verified: (state?.verifiedHosts || []).includes(item.host),
      sampledAt: Number(item.sampledAt) || 0,
      bytes: Number(item.bytes) || 0, capacityKbps: Number(item.capacityKbps) || 0,
      sampleSegments: item.sampleSegments === 2 ? 2 : 1,
      stage: ['quick','verify','sustained','playback'].includes(item.stage) ? item.stage : 'unknown',
      reason: probeFailureReason(item),
    })),
  };
}

export function popupView(settings, state, { supported = true, error = "" } = {}) {
  const ruleError = state?.phase === "error" && state?.ruleInstalled === true;
  const baselinePassthrough = settings.enabled && settings.mode !== "original"
    && state?.passthroughReason === "baseline-akamai";
  const phase = ruleError ? "error" : !settings.enabled ? "paused" : state?.phase || "waiting";
  const title = {
    paused: "已暂停优化", waiting: "等待视频", testing: "正在寻找快线路",
    verifying: "正在复核线路", active: "自动优化中", manual: "已固定线路",
    original: "使用原始 CDN", error: "已回退原始线路",
  }[phase] || "等待视频";
  const message = {
    paused: "视频继续使用原始线路，打开开关可恢复优化。",
    waiting: "开始播放视频后，自动识别并选择线路。",
    testing: "播放继续进行。缓冲充足后再做完整复测。",
    verifying: "只比较当前与备用节点，避免频繁测速。",
    active: "监测缓冲变化，线路失效时自动切换备用节点。",
    manual: "当前线路由你指定，选择自动可恢复智能切换。",
    original: "使用 B 站提供的线路，暂不测速或切换。",
    error: "候选线路暂不可用，继续播放并稍后重试。",
  }[phase] || "";
  const selected = settings.enabled ? state?.selectedHost || "" : "";
  let applied = "等待媒体请求";
  if (ruleError) applied = "规则仍可能生效";
  else if (!settings.enabled || settings.mode === "original" || baselinePassthrough) applied = "原始请求直通";
  else if (selected) {
    applied = state.actualHost === selected ? state.routeMechanism === 'pre-route'
      ? state.routeVerified ? '本视频已验证' : '实播验证中' : "目标请求已确认"
      : state.ruleInstalled ? "规则已就绪"
        : "等待后续请求";
  }
  return {
    phase: error ? "error" : phase,
    title: error ? "操作未完成" : !supported ? "打开 B 站播放页" : ruleError ? "规则更新未完成" : title,
    message: error || (!supported
      ? "在视频、番剧或课程播放页使用线路优化。"
      : state?.lastError || (baselinePassthrough ? "此视频没有已验证的同轨原生备用，保持原始直通，不盲目跨 CDN 改道。" : message)),
    applied,
    selected,
    busy: phase === "testing" || phase === "verifying",
    canRetest: supported && settings.enabled && !baselinePassthrough && (state?.originalHost !== BILI_AKAMAI_HOST || state?.routeMechanism === 'pre-route') && Boolean(state?.lastDetectedAt),
  };
}
// The action popup initially measures in a tiny viewport. Keep its intrinsic
// height until Edge supplies its real available area, then fit without vh loops.
export function popupHeight(viewportHeight) {
  return Number.isFinite(viewportHeight) && viewportHeight >= 420 ? Math.min(600, viewportHeight) : 600;
}
