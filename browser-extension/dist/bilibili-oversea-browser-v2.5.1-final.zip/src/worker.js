import {
  ADAPTIVE_POLICY,
  BILI_AKAMAI_HOST,
  DEFAULT_CANDIDATES,
  DEFAULT_SETTINGS,
  isCdnTargetHost,
  isMediaUrl,
  makeRedirectRule,
  publicTabState,
  rankResults,
  resultFromTiming,
  replaceMediaHost,
  sanitizeBenchmarkCache,
  sanitizeSettings,
  shouldSwitchAfterVerification,
  uniqueHosts,
} from "./engine.js";
import { fetchProbe, probeReferrerRule, PROBE_REFERRER_RULE_ID } from "./network-probe.js";
import { CATALOG_HOSTS, catalogOffset, selectCandidates, startupCandidates, emergencyCandidates } from './candidates.js';
import { initialRoute } from './route-policy.js';
import { attachRequestObserver } from './request-observer.js';

const SETTINGS_KEY = "biliCdnAutoSettingsV2";
const BENCHMARK_CACHE_KEY = "biliCdnAutoBenchmarkV5";
const QUICK_PROBE_BYTES = 128 * 1024;
const QUICK_PROBE_TIMEOUT_MS = 4_500;
const SUSTAINED_PROBE_BYTES = 1024 * 1024;
const SUSTAINED_PROBE_TIMEOUT_MS = 9_000;
const SUSTAINED_FINALISTS = 3;
const tabStates = new Map();
// Browser-provided document identity is separate from playback state: a URL
// cleanup is not a reload, and a retired document cannot bootstrap itself again.
const tabDocuments = new Map();
const closedTabs = new Set();
const CONTENT_MESSAGES = new Set(['route-prepared', 'route-used', 'route-delivered', 'route-failed',
  'fetch-probe', 'cancel-probe', 'media-discovered', 'media-heartbeat', 'page-changed',
  'playback-stall', 'network-changed', 'document-resumed']);
const DOCUMENT_BOOTSTRAPS = new Set(['route-prepared', 'media-discovered', 'page-changed', 'document-resumed']);
const ruleQueues = new Map();
let probeHeadersReady;

const ruleId = (tabId) => 1_000_000 + tabId;

function newTabState() {
  return {
    phase: "waiting",
    earlyRouting: false,
    routeBypass: false,
    earlyOriginalHost: '',
    lastPassiveAt: 0,
    lastPassiveSavedAt: 0,
    tailCacheProof: null,
    recoveryAttemptedHosts: new Set(),
    recoveryTargetAt: 0,
    lastRouteRequestOrder: 0,
    lastRoutedVideo: null,
    lastAudioRequestOrder: 0,
    lastRoutedAudio: null,
    playbackObserved: false,
    navigationGeneration: 0,
    lastLightVerifiedAt: 0,
    lightVerifiedVideoKey: '',
    sourceUrls: [],
    trackKinds: new Map(),
    observedVideoPath: "",
    requestedVideoUrl: "",
    pendingMedia: new Map(),
    mediaOrder: 0,
    lastVideoRequestOrder: 0,
    cacheLoaded: false,
    probeOffsets: new Map(),
    appliedSourceHosts: new Set(),
    pendingCandidateMaintenance: false,
    passthroughReason: "",
    originalHost: "",
    observedHosts: new Set(),
    selectedHost: "",
    actualHost: "",
    actualHostSource: "",
    ruleInstalled: false,
    discoverySource: "",
    lastDetectedAt: 0,
    pageUrl: "",
    videoKey: "",
    verifiedVideoKey: "",
    results: [],
    lastTestedAt: 0,
    lastQuickTestedAt: 0,
    lastVerifiedAt: 0,
    lastMaintenanceAttemptAt: 0,
    lastError: "",
    failedHosts: new Set(),
    runId: 0,
    testing: null,
    verificationPending: false,
    probeControllers: new Map(),
    verifiedHosts: new Set(),
    startupAttempted: false,
    startupDeadline: 0,
    networkKey: '',
    recovering: null,
    catalogCursor: 0,
    backupUrls: new Map(),
    nativeTarget: null,
    nativeRuleDirty: false,
    extendedRecoveryHosts: new Set(),
    trackRates: new Map(),
  };
}

function stateFor(tabId) {
  if (!tabStates.has(tabId)) tabStates.set(tabId, newTabState());
  return tabStates.get(tabId);
}

const isBiliPage = url => /^https:\/\/(?:www|m)\.bilibili\.com\//i.test(String(url || ''));

function discardPlayback(tabId) {
  requestObserver.clear(tabId);
  cancelTesting(tabId);
  tabStates.delete(tabId);
  return clearRule(tabId);
}

function bindContentDocument(tabId, message, sender) {
  if (closedTabs.has(tabId) || (Number.isInteger(sender.frameId) && sender.frameId !== 0)
    || (sender.documentLifecycle && sender.documentLifecycle !== 'active')) return null;
  const id = typeof sender.documentId === 'string' ? sender.documentId : '';
  // A genuine BFCache restore reuses its old document UUID. ISOLATED sends this
  // handshake only for a trusted persisted pageshow; the browser must also
  // confirm the top-level document is active. Ordinary retired messages never
  // get this exception, nor can any handshake resurrect a closed tab.
  const resumed = message.type === 'document-resumed';
  if (resumed && (!id || sender.frameId !== 0 || sender.documentLifecycle !== 'active'
    || message.persisted !== true || !message.pageUrl)) return null;
  let document = tabDocuments.get(tabId);
  // Old Chromium/test callers retain the legacy path only until a real browser
  // document has been bound. An unidentifiable message cannot replace it.
  if (!id) return document ? null : { legacy: true };
  if (!isBiliPage(sender.url)) return null;
  const senderKey = pageVideoKey(sender.url, '');
  const messageUrl = message.type === 'page-changed' ? message.url : message.pageUrl;
  if (messageUrl && pageVideoKey(messageUrl, '') !== senderKey) return null;
  if (!document) {
    document = { id, pageKey: senderKey, retired: new Set(), suspended: false, ready: null };
    tabDocuments.set(tabId, document);
  } else if (document.id !== id || resumed) {
    if ((document.retired.has(id) && !resumed) || !DOCUMENT_BOOTSTRAPS.has(message.type)) return null;
    if (document.id && document.id !== id) document.retired.add(document.id);
    document.id = id;
    document.pageKey = senderKey;
    document.suspended = false;
    // Invalidate old async work before waiting for serialized DNR cleanup.
    document.ready = discardPlayback(tabId);
    const fresh = stateFor(tabId);
    fresh.pageUrl = sender.url;
    fresh.videoKey = senderKey;
  } else {
    if (document.suspended && sender.documentLifecycle !== 'active') return null;
    if (document.pageKey !== senderKey) {
      if (!DOCUMENT_BOOTSTRAPS.has(message.type)) return null;
      document.pageKey = senderKey;
      document.ready = resetForNavigation(tabId, sender.url);
    }
    document.suspended = false;
  }
  return { document, id, pageKey: senderKey, ready: document.ready };
}

function isCurrentDocument(tabId, context) {
  if (context.legacy) return !closedTabs.has(tabId) && !tabDocuments.has(tabId);
  const current = tabDocuments.get(tabId);
  return current === context.document && current.id === context.id
    && current.pageKey === context.pageKey && !current.suspended;
}

async function readSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return sanitizeSettings(stored[SETTINGS_KEY] || DEFAULT_SETTINGS);
}

async function writeSettings(settings) {
  const safe = sanitizeSettings(settings);
  await chrome.storage.local.set({ [SETTINGS_KEY]: safe });
  return safe;
}

async function readBenchmarkCache() {
  const stored = await chrome.storage.local.get(BENCHMARK_CACHE_KEY);
  return sanitizeBenchmarkCache(stored[BENCHMARK_CACHE_KEY]);
}

async function writeBenchmarkCache(value) {
  const safe = sanitizeBenchmarkCache(value);
  await chrome.storage.local.set({ [BENCHMARK_CACHE_KEY]: safe });
  return safe;
}

function mergeResults(previous, updates) {
  const merged = new Map((previous || []).map((item) => [item.host, item]));
  for (const item of updates || []) {
    const previous = merged.get(item.host);
    const fullSampledAt = ['sustained','playback'].includes(previous?.stage)
      ? (previous.bytes >= SUSTAINED_PROBE_BYTES ? previous.sampledAt : 0) : previous?.fullSampledAt;
    merged.set(item.host, {...item, ...(item.ok && item.stage !== 'sustained' && fullSampledAt ? {fullSampledAt} : {})});
  }
  return [...merged.values()];
}

function stampResults(results, sampledAt = Date.now()) {
  return (results || []).map((item) => ({ ...item, sampledAt }));
}

function currentPlaybackResult(state) {
  return state.earlyRouting && state.results.find(item => item.host === state.selectedHost
    && item.measuredThisVideo && item.stage === 'playback' && item.bytes >= SUSTAINED_PROBE_BYTES);
}

function freshHealthyPlayback(state) {
  const item = currentPlaybackResult(state), age = Date.now() - Number(item?.sampledAt);
  return state.healthyRoute && item?.ok && !state.failedHosts.has(item.host)
    && age >= 0 && age < 30_000 ? item : null;
}

function deferRecoveryMaintenance(state) {
  if (!state.earlyRouting || !state.recoveryTargetAt) return false;
  // A recovered route gets the normal quiet-review interval, not the old
  // route's almost-expired maintenance window. Real failures stay actionable.
  return Date.now() - state.recoveryTargetAt < ADAPTIVE_POLICY.lightVerifyIntervalMs
    || (state.selectedHost && !(currentPlaybackResult(state)?.sampledAt >= state.recoveryTargetAt));
}

function mergeAutomaticResults(state, updates) {
  // Read at commit, not only when the optional probe began: real segments can
  // finish while a synthetic sample is pending. Keep their timestamp/bytes.
  const playback = freshHealthyPlayback(state);
  state.results = mergeResults(state.results, playback ? updates.filter(item => item.host !== playback.host) : updates);
  // probeCandidates maintains this set before returning; restore real proof
  // if its superseded synthetic result removed qualification.
  if (playback) state.verifiedHosts.add(playback.host);
  return playback;
}

function qualifiedBeforeMarginalTail(state, message, actual, sample, settings) {
  const previous=state.results.find(item=>item.host===actual.hostname), range=message.completedRange;
  const activity=message.activity, now=Date.now(), age=now-message.observedAt;
  const bitrate=state.trackRates.get(actual.pathname)/1000;
  if (!state.earlyRouting || settings.mode!=='auto' || !settings.enabled || state.routeBypass
    || state.selectedHost!==actual.hostname || state.lastRoutedVideo?.host!==actual.hostname
    || state.lastRoutedVideo?.path!==actual.pathname || state.observedVideoPath!==actual.pathname
    || !state.videoKey || state.verifiedVideoKey!==state.videoKey || state.failedHosts.has(actual.hostname)
    || !state.verifiedHosts.has(actual.hostname) || !message.pageUrl || !state.pageUrl
    || pageVideoKey(message.pageUrl,'')!==pageVideoKey(state.pageUrl,'')
    || !Number.isFinite(bitrate) || bitrate<=0 || sample.ok || sample.kbps<bitrate || sample.kbps>=bitrate*1.25
    || message.status!==206 || !range || ![range.start,range.end,range.total].every(Number.isSafeInteger)
    || range.start<=0 || range.end<range.start || range.end+1!==range.total
    || !Number.isSafeInteger(sample.bytes) || sample.bytes!==range.end-range.start+1
    || !previous?.ok || !previous.measuredThisVideo || previous.stage!=='playback'
    || previous.bytes<SUSTAINED_PROBE_BYTES || sample.bytes>=previous.bytes || previous.kbps<bitrate*1.25
    || !Number.isFinite(previous.sampledAt) || now-previous.sampledAt<0 || now-previous.sampledAt>=30000
    || !Number.isFinite(message.observedAt) || age<0 || age>3000 || !activity
    || activity.visible!==true || activity.paused!==false || activity.seeking!==false || activity.ended!==false
    || activity.userInteracting!==false || activity.hasPlayed!==true
    || !Number.isInteger(activity.readyState) || activity.readyState<2 || activity.readyState>4
    || !Number.isFinite(activity.currentTime) || activity.currentTime<=0
    || !Number.isFinite(activity.bufferedAhead) || activity.bufferedAhead<ADAPTIVE_POLICY.safeBufferSeconds) return null;
  return previous;
}

async function persistStateCache(state, winnerHost = state.selectedHost) {
  const proof=state.tailCacheProof;
  const preserve=proof && tabStates.get(proof.tabId)===state && state.navigationGeneration===proof.navigationGeneration
    && state.videoKey===proof.videoKey && state.networkKey===proof.networkKey && !state.routeBypass
    && state.selectedHost===winnerHost && winnerHost===proof.qualified.host && !state.failedHosts.has(winnerHost)
    && state.lastRoutedVideo?.host===winnerHost && state.lastRoutedVideo?.path===state.observedVideoPath
    && state.results.find(item=>item.host===winnerHost)===proof.latestResult;
  if (proof && !preserve) state.tailCacheProof=null;
  return writeBenchmarkCache({
    networkKey: state.networkKey,
    winnerHost,
    // The latest measurement remains below-margin in state/UI. Reuse only the
    // preceding real proof, retaining its original bytes/rate/time and TTL.
    results: state.results.filter(item => !String(item.error || '').startsWith('playback '))
      .map(item=>preserve && item===proof.latestResult ? proof.qualified : item),
    lastFullTestedAt: state.lastTestedAt,
    lastVerifiedAt: state.lastVerifiedAt,
  });
}

async function setBadge(tabId, phase) {
  const badges = {
    testing: ["…", "#f59e0b"], verifying: ["·", "#f59e0b"], active: ["A", "#00a1d6"],
    manual: ["M", "#fb7299"], original: ["—", "#64748b"], error: ["!", "#dc2626"],
    waiting: ["", "#64748b"],
  };
  const [text, color] = badges[phase] || badges.waiting;
  await Promise.all([
    chrome.action.setBadgeText({ tabId, text }).catch(() => {}),
    chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {}),
  ]);
}

async function publish(tabId) {
  const expected = tabStates.get(tabId), runId = expected?.runId;
  const settings = await readSettings();
  const internal=tabStates.get(tabId);
  if (internal !== expected || internal?.runId !== runId) return;
  const state = publicTabState(internal);
  if(state) {
    const needsCache = settings.enabled && settings.mode === 'auto' && !internal.routeBypass
      && !internal.selectedHost && !internal.startupAttempted;
    const cache = needsCache ? await readBenchmarkCache() : {};
    if (tabStates.get(tabId) !== internal || internal.runId !== runId) return;
    state.routeHost = !settings.enabled || settings.mode === 'original' ? ''
      : settings.mode === 'manual' ? initialRoute(settings,cache,internal.networkKey)
      : internal.routeBypass ? '' : internal.selectedHost || (internal.startupAttempted ? '' : initialRoute(settings,cache,internal.networkKey));
  }
  chrome.runtime.sendMessage({ type: "state-updated", tabId, settings, state }).catch(() => {});
  chrome.tabs.sendMessage(tabId, { type: "state-update", state, settings }).catch(() => {});
}

function queueRuleUpdate(tabId, operation) {
  // A close/removal must finish after an already-started installation, while
  // another tab's rules remain independent. Rejections do not poison the queue.
  const task = (ruleQueues.get(tabId) || Promise.resolve()).catch(() => {}).then(operation);
  ruleQueues.set(tabId, task);
  const release = () => { if (ruleQueues.get(tabId) === task) ruleQueues.delete(tabId); };
  task.then(release, release);
  return task;
}

async function clearRule(tabId) {
  const expectedState = tabStates.get(tabId);
  const runId = expectedState?.runId;
  try {
    await queueRuleUpdate(tabId, () => chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId(tabId)] }));
  } catch {
    const state = tabStates.get(tabId);
    if (state && state === expectedState && state.runId === runId) {
      state.phase = "error";
      state.lastError = "无法撤销线路规则，请在扩展管理页重新加载插件。";
      await setBadge(tabId, "error");
      await publish(tabId);
    }
    throw new Error("无法撤销线路规则，请在扩展管理页重新加载插件。");
  }
  if (expectedState && tabStates.get(tabId) === expectedState && expectedState.runId === runId) expectedState.ruleInstalled = false;
}

function cancelTesting(tabId) {
  const state = tabStates.get(tabId);
  if (!state) return;
  state.tailCacheProof = null;
  state.runId += 1;
  // Cache/settings reads and rule installation are also asynchronous work.
  if (!state.testing && !state.verificationPending && !state.probeControllers.size) return;
  state.testing = null;
  state.verificationPending = false;
  for (const controller of state.probeControllers.values()) controller.abort();
  state.probeControllers.clear();
  chrome.tabs.sendMessage(tabId, { type: "cancel-probes" }).catch(() => {});
}

async function handleProbeFetch(tabId, message) {
  if (!isMediaUrl(message.sourceUrl) || !isCdnTargetHost(message.host)
    || !/^[a-z0-9-]{1,64}$/i.test(message.probeId || "")) throw new TypeError("invalid probe request");
  const state = stateFor(tabId);
  const controller = new AbortController();
  const runId = state.runId;
  state.probeControllers.get(message.probeId)?.abort();
  state.probeControllers.set(message.probeId, controller);
  const timeout = setTimeout(() => controller.abort(), Math.min(15_000, Math.max(1000, Number(message.timeoutMs) || 4500)));
  try {
    if (!probeHeadersReady) {
      probeHeadersReady = chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [PROBE_REFERRER_RULE_ID], addRules: [probeReferrerRule(chrome.runtime.id)] });
      probeHeadersReady.catch(() => { probeHeadersReady = null; });
    }
    await probeHeadersReady;
    if (controller.signal.aborted || state.runId !== runId) return { ok: false, cancelled: true };
    return await fetchProbe({ ...message, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
    if (state.probeControllers.get(message.probeId) === controller) state.probeControllers.delete(message.probeId);
  }
}

async function applyTarget(tabId, targetHost, phase = "active") {
  const state = tabStates.get(tabId);
  if (!state) return false;
  if(state.earlyRouting){
    if(!isCdnTargetHost(targetHost))return false;
    const runId = state.runId;
    await clearRule(tabId);if(tabStates.get(tabId)!==state || state.runId !== runId)return false;
    if(state.selectedHost!==targetHost){state.lastRoutedVideo=null;state.lastRoutedAudio=null;state.tailCacheProof=null;}
    state.selectedHost=targetHost;state.routeBypass=false;state.phase=phase;
    await setBadge(tabId,phase);await publish(tabId);return tabStates.get(tabId)===state;
  }
  // Akamai may only use a verified, exact same-track signed backup. A manual
  // catalog selection must not silently turn that rule into a generic transform.
  if (state.originalHost === BILI_AKAMAI_HOST && state.nativeTarget?.host !== targetHost) return false;
  const runId = state.runId;
  let rule;
  const applied = await queueRuleUpdate(tabId, async () => {
    if (tabStates.get(tabId) !== state || state.runId !== runId) return false;
    rule = state.nativeTarget && state.nativeTarget.host === targetHost
      ? { id: ruleId(tabId), priority: 2, action: { type:'redirect', redirect:{url:state.nativeTarget.url} },
        condition: { tabIds:[tabId], initiatorDomains:['bilibili.com'],
          regexFilter: '^(?:'+(state.nativeTarget.sources || [state.nativeTarget.source])
            .filter(url=>url!==state.nativeTarget.url)
            .map(url=>url.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')$',
          resourceTypes:['media','xmlhttprequest','other'] } }
      : makeRedirectRule({ id: ruleId(tabId), tabId, sourceHosts: [...state.observedHosts], targetHost, sourcePath:state.observedVideoPath });
    const update = { removeRuleIds: [ruleId(tabId)] };
    if (rule) update.addRules = [rule];
    await chrome.declarativeNetRequest.updateSessionRules(update);
    return true;
  });
  if (!applied || tabStates.get(tabId) !== state || state.runId !== runId) return false;
  state.selectedHost = targetHost;
  state.ruleInstalled = Boolean(rule);
  state.nativeRuleDirty = false;
  state.appliedSourceHosts = new Set(state.observedHosts);
  state.phase = phase;
  await setBadge(tabId, phase);
  await publish(tabId);
  return tabStates.get(tabId) === state && state.runId === runId;
}

async function probeCandidates(tabId, sourceUrl, candidates, {
  byteLimit = QUICK_PROBE_BYTES,
  timeoutMs = QUICK_PROBE_TIMEOUT_MS,
  stage = "quick",
  waitForBufferSeconds = 0,
  waitTimeoutMs = 0,
  firstSuccess = false,
  minimumKbps,
  deadline = 0,
  compareBeforeDeadline = 0,
  sampleSegments = 1,
} = {}) {
  const state = tabStates.get(tabId);
  if (!state) return null;
  minimumKbps ??= (state.trackRates.get(new URL(sourceUrl).pathname) || 0) / 1000 * 1.5;
  const runId = state.runId;
  const failedAtStart = new Set(state.failedHosts);
  let response;
  try {
    response = await chrome.tabs.sendMessage(tabId, {
      type: "probe-candidates",
      sourceUrl,
      hosts: candidates,
      byteLimit,
      timeoutMs,
      waitForBufferSeconds,
      waitTimeoutMs,
      firstSuccess,
      minimumKbps,
      deadline: compareBeforeDeadline,
      sampleSegments,
      startByte: state.probeOffsets.get(new URL(sourceUrl).pathname) || 0,
    });
  } catch (error) {
    response = { ok: false, error: String(error?.message || error), results: [] };
  }
  if (tabStates.get(tabId) !== state || state.runId !== runId || response?.skipped || (deadline && Date.now() >= deadline)) return null;
  const rawResults = Array.isArray(response?.results) ? response.results : [];
  const byHost = new Map(rawResults
    .filter((item) => candidates.includes(String(item?.host || "").toLowerCase()))
    .map((item) => [String(item.host).toLowerCase(), item]));
  const measuredHosts = firstSuccess || compareBeforeDeadline ? candidates.filter(host => byHost.has(host)) : candidates;
  const results = measuredHosts.map((host) => {
    if(state.failedHosts.has(host) && !failedAtStart.has(host)){
      // A late hard failure may retire another host without cancelling this
      // probe. Its newer failure wins; a later explicit test remains allowed.
      const failed=state.results.find(item=>item.host===host&&!item.ok);
      return failed ? {...failed} : resultFromTiming({host,ok:false,error:'route failure',stage:'verify'});
    }
    const item = byHost.get(host);
    return resultFromTiming({
      host,
      ok: item?.ok === true,
      status: Number(item?.status) || 0,
      bytes: Math.min(byteLimit, Math.max(0, Number(item?.bytes) || 0)),
      elapsedMs: Math.max(0, Number(item?.elapsedMs) || 0),
      ttfbMs: Math.max(0, Number(item?.ttfbMs) || 0),
      headerWaitMs: Math.max(0, Number(item?.headerWaitMs ?? item?.ttfbMs) || 0),
      error: item
        ? (item.error || "")
        : (response?.error || (response?.ok === false ? "probe unavailable" : "missing result")),
      stage,
    });
  });
  for (const result of results) {
    if (result.ok && result.bytes < byteLimit) {
      result.ok = false; result.error = 'incomplete startup sample';
    }
    if (result.ok && result.capacityKbps < minimumKbps) {
      result.ok = false; result.error = 'sample throughput below video bitrate margin';
    }
    result.measuredThisVideo = true;
    result.sampleSegments = byHost.get(result.host)?.sampleSegments === 2 ? 2 : 1;
    if (result.ok) state.verifiedHosts.add(result.host);
    else state.verifiedHosts.delete(result.host);
  }
  if (results.length && (compareBeforeDeadline || firstSuccess)) state.lastQuickTestedAt = Date.now();
  return results;
}

async function startupSelect(tabId, {recovery = false} = {}) {
  const state = tabStates.get(tabId);
  if (!state || state.startupAttempted) return null;
  state.startupAttempted = true;
  const runId = ++state.runId;
  const deadline = state.startupDeadline || Date.now() + 2000;
  const operation = (async () => {
    const settings = await readSettings();
    if (tabStates.get(tabId) !== state || runId !== state.runId || !settings.enabled || settings.mode !== 'auto') return null;
    const remaining = deadline - Date.now();
    if (remaining <= 0) { state.phase = 'original'; return null; }
    state.phase = 'testing';
    await publish(tabId);
    const candidates = startupCandidates(state, settings);
    // Reserve rule/message delivery time inside the existing two-second gate.
    // Very short remaining budgets keep a proportional reserve rather than
    // granting another two seconds to the queued candidates.
    const reserve = Math.min(300, Math.floor(remaining / 4));
    const probeDeadline = deadline - reserve;
    const selectionDeadline = deadline - Math.min(100, Math.floor(reserve / 3));
    let timer;
    const results = await Promise.race([
      probeCandidates(tabId, state.sourceUrls[0], candidates, {
        timeoutMs: remaining, byteLimit: QUICK_PROBE_BYTES, deadline: selectionDeadline,
        compareBeforeDeadline: probeDeadline,
        sampleSegments:2,
        minimumKbps:(state.trackRates.get(new URL(state.sourceUrls[0]).pathname)||0)/1000*1.5 }),
      new Promise(resolve => { timer = setTimeout(() => resolve(null), Math.max(0, selectionDeadline-Date.now())); }),
    ]).finally(() => clearTimeout(timer));
    if (tabStates.get(tabId) !== state || runId !== state.runId) return null;
    // Invalidate late probe results without invalidating this operation's rule install.
    for (const controller of state.probeControllers.values()) controller.abort();
    chrome.tabs.sendMessage(tabId, { type: 'cancel-probes' }).catch(() => {});
    const needed=(state.trackRates.get(new URL(state.sourceUrls[0]).pathname)||0)/1000*1.5;
    const ranked = rankResults(results || [], state.originalHost).filter(result => result.capacityKbps >= needed);
    state.results = mergeResults(state.results, stampResults(results || []));
    const winner = ranked[0];
    let selected = null;
    if (winner && Date.now() < deadline) {
      if (await applyTarget(tabId, winner.host)) {
        selected = winner;
        if (tabStates.get(tabId) === state && runId === state.runId) await persistStateCache(state, winner.host);
      }
    } else {
      state.phase = 'original';
      state.lastError = '';
      if (recovery) {
        for (const result of results || []) if (!result.ok) state.failedHosts.add(result.host);
      }
    }
    state.catalogCursor = (state.catalogCursor + 1) % CATALOG_HOSTS.length;
    return selected;
  })();
  state.testing = operation;
  try { return await operation; }
  finally {
    if (state.testing === operation) state.testing = null;
    if (tabStates.get(tabId) === state && runId === state.runId) {
      chrome.tabs.sendMessage(tabId, { type: 'startup-ready', path: state.observedVideoPath }).catch(() => {});
      await publish(tabId);
    }
  }
}

async function benchmark(tabId, reason = "automatic") {
  const state = tabStates.get(tabId);
  if (!state) return null;
  const automatic = reason !== 'manual';
  if (automatic && deferRecoveryMaintenance(state)) return null;
  const playbackAtStart = automatic && freshHealthyPlayback(state);
  if (playbackAtStart) return playbackAtStart;
  if (state.originalHost === BILI_AKAMAI_HOST && !state.earlyRouting) return null;
  if (state.testing) return state.testing;
  if (state.verificationPending) return null;
  const sourceUrl = state.sourceUrls.find(isMediaUrl);
  if (!sourceUrl) return null;
  const testedVideoKey = state.videoKey;
  const testing = (async () => {
    const runId = ++state.runId;
    const settings = await readSettings();
    if (runId !== state.runId) return null;
    const disabled = new Set(settings.disabledHosts);
    const candidates = selectCandidates(state, settings, 8);
    state.catalogCursor = (state.catalogCursor + 2) % CATALOG_HOSTS.length;
    state.phase = "testing";
    state.lastError = "";
    await setBadge(tabId, "testing");
    await publish(tabId);

    if (runId !== state.runId) return null;
    const quickResults = await probeCandidates(tabId, sourceUrl, candidates, {
      waitForBufferSeconds: 12, waitTimeoutMs: 4000 });
    if (runId !== state.runId) return null;
    if (!quickResults) {
      state.phase = state.selectedHost ? "active" : state.observedVideoPath ? "original" : "waiting";
      await setBadge(tabId, state.phase);
      await publish(tabId);
      return null;
    }
    const playback = automatic ? mergeAutomaticResults(state, quickResults) : null;
    if (!automatic) state.results = mergeResults(state.results, quickResults);
    if (playback) {
      state.phase = 'active'; state.lastError = '';
      await persistStateCache(state, playback.host);
      await setBadge(tabId, 'active'); await publish(tabId);
      return playback;
    }
    const quickRanked = rankResults(quickResults, state.originalHost);
    if (!quickRanked.length) {
      const now = Date.now();
      state.results = mergeResults(state.results, stampResults(quickResults, now));
      state.lastTestedAt = now;
      state.lastVerifiedAt = now;
      state.verifiedVideoKey = testedVideoKey;
      state.pendingCandidateMaintenance = false;
      state.phase = "error";
      state.lastError = `测速没有可用节点（${reason}）`;
      // Missing/short samples are inconclusive. A complete current-host
      // sample below bitrate, however, is actual evidence against its rule.
      const current = quickResults.find(item => item.host === state.selectedHost);
      if (current?.error === 'sample throughput below video bitrate margin') {
        state.selectedHost = ''; state.phase = 'original';
        await clearRule(tabId);
      }
      // An inconclusive retest must not tear down a previously working route.
      if (state.selectedHost) state.phase = 'active';
      else await clearRule(tabId);
      if (runId !== state.runId || tabStates.get(tabId) !== state) return null;
      if (!state.selectedHost) await persistStateCache(state, "");
      await setBadge(tabId, state.phase);
      await publish(tabId);
      return null;
    }

    if (!state.selectedHost && !await applyTarget(tabId, quickRanked[0].host, "testing")) return null;
    if (runId !== state.runId) return null;
    const finalists = quickRanked.slice(0, SUSTAINED_FINALISTS).map((item) => item.host);
    const sustainedResults = await probeCandidates(tabId, sourceUrl, finalists, {
      byteLimit: SUSTAINED_PROBE_BYTES,
      timeoutMs: SUSTAINED_PROBE_TIMEOUT_MS,
      stage: "sustained",
      waitForBufferSeconds: 10,
      waitTimeoutMs: 15_000,
    });
    if (runId !== state.runId) return null;
    // A failed larger transfer supersedes a successful tiny sample.
    const sustainedByHost = new Map((sustainedResults || []).map(item => [item.host, item]));
    const now = Date.now();
    const updates = stampResults(quickResults.map(item => sustainedByHost.get(item.host) || item), now);
    const actualPlayback = automatic ? mergeAutomaticResults(state, updates) : null;
    if (!automatic) state.results = mergeResults(state.results, updates);
    state.lastTestedAt = now;
    state.lastVerifiedAt = now;
    state.verifiedVideoKey = testedVideoKey;
    state.pendingCandidateMaintenance = [...state.observedHosts].some(host => isCdnTargetHost(host) && !candidates.includes(host));
    // Unrelated failed routes remain excluded for this video; old cache cannot
    // silently rehabilitate them after a different host's successful test.
    for (const item of sustainedResults || []) {
      if (item.host === actualPlayback?.host) continue;
      if (item.ok) state.failedHosts.delete(item.host);
      else if (item.error !== 'incomplete startup sample') state.failedHosts.add(item.host);
    }
    const finalRanked = rankResults(sustainedResults || [], state.originalHost);
    const winner = finalRanked[0] || (!sustainedResults ? quickRanked[0] : null);
    const latestSettings = await readSettings();
    if (runId !== state.runId) return null;
    if (!latestSettings.enabled || latestSettings.mode !== "auto") {
      await honorMode(tabId);
      return winner;
    }
    // A higher synthetic speed alone does not justify moving a healthy player.
    const currentResult = state.results.find(item => item.host === state.selectedHost && item.measuredThisVideo);
    // EOF/sample shortage cannot prove the healthy route is slow. Preserve
    // it without labelling the incomplete result qualified or long-lived.
    const currentInconclusive = currentResult?.error === 'incomplete startup sample';
    const target = state.healthyRoute && (currentResult?.ok || currentInconclusive) && state.selectedHost
      ? state.selectedHost : winner?.host;
    if (!target) {
      state.selectedHost = ''; state.phase = 'original';
      state.lastError = '较大样本没有满足当前画质的线路，已回退原始请求。';
      await clearRule(tabId); await persistStateCache(state, ''); await publish(tabId);
      return null;
    }
    if (!await applyTarget(tabId, target, "active")) return null;
    if (runId === state.runId && tabStates.get(tabId) === state) await persistStateCache(state, target);
    return winner;
  })();
  state.testing = testing;
  const release = () => {
    if (state.testing === testing) state.testing = null;
  };
  testing.then(release, release);
  return testing;
}

async function hydrateFromCache(tabId, settings) {
  const state = tabStates.get(tabId);
  if (!state) return true;
  if (state.cacheLoaded) return false;
  const runId = state.runId;
  const disabled = new Set(settings.disabledHosts);
  const cache = await readBenchmarkCache();
  if (tabStates.get(tabId) !== state || state.runId !== runId) return true;
  state.cacheLoaded = true;
  const results = cache.networkKey && state.networkKey && cache.networkKey !== state.networkKey ? []
    : cache.results.filter((item) => !disabled.has(item.host) && !state.failedHosts.has(item.host)
      && !state.results.some(current => current.host === item.host && current.measuredThisVideo));
  // Do not erase this video's failure evidence on subsequent media requests.
  state.results = mergeResults(state.results, results.map(item => ({...item, measuredThisVideo:false})));
  state.lastTestedAt = cache.lastFullTestedAt;
  state.lastVerifiedAt = cache.lastVerifiedAt;
  // Host/network history is a shortlist, never proof for another signed video.
  // Let startupSelect validate this video's actual representation before use.
  return false;
}

async function honorMode(tabId, { forceRetest = false, backgroundBenchmark = false } = {}) {
  const state = stateFor(tabId);
  const pendingRunId = state.runId;
  const settings = await readSettings();
  if (tabStates.get(tabId) !== state || state.runId !== pendingRunId) return;
  const runBenchmark = (reason) => {
    const task = benchmark(tabId, reason);
    if (!backgroundBenchmark) return task;
    const runId = state.runId;
    task.catch(async () => {
      if (tabStates.get(tabId) !== state || state.runId !== runId) return;
      state.phase = state.selectedHost ? "active" : "error";
      state.lastError = "线路测试未完成，请检查网络后重测。";
      await setBadge(tabId, state.phase);
      await publish(tabId);
    });
    return null;
  };
  if (!settings.enabled || settings.mode === "original") {
    cancelTesting(tabId);
    if (state.phase === "original" && !state.ruleInstalled) {await publish(tabId);return;}
    state.phase = "original";
    state.selectedHost = "";
    state.lastError = "";
    await clearRule(tabId);
    await setBadge(tabId, "original");
    await publish(tabId);
    return;
  }
  // Retain passthrough unless this video supplies a verifiable native backup.
  if(state.earlyRouting){
    if(settings.mode==='manual'){state.selectedHost=settings.manualHost;state.routeBypass=false;state.phase='manual';}
    else {
      if(await hydrateFromCache(tabId,settings))return;
      if(settings.disabledHosts.includes(state.selectedHost)){state.selectedHost='';state.routeBypass=false;}
      if(!state.selectedHost&&!state.routeBypass)state.selectedHost=initialRoute(settings,await readBenchmarkCache(),state.networkKey);
      if(tabStates.get(tabId)!==state||state.runId!==pendingRunId)return;
      state.phase=state.selectedHost?'active':'original';
    }
    await publish(tabId);return;
  }
  if (state.originalHost === BILI_AKAMAI_HOST && !state.nativeTarget) {
    if (state.testing) return;
    if (!state.startupAttempted && state.observedVideoPath && (state.backupUrls.get(state.sourceUrls[0]) || []).length) {
      state.startupAttempted = true;
      state.phase = 'testing';
      const operation = recoverNativeBackup(tabId, {retry:false, deadline:state.startupDeadline || Date.now()+2000});
      state.testing = operation;
      try { await operation; }
      finally {
        if (state.testing === operation) state.testing = null;
        if (tabStates.get(tabId) === state) {
          chrome.tabs.sendMessage(tabId,{type:'startup-ready',path:state.observedVideoPath}).catch(() => {});
          await publish(tabId);
        }
      }
      return;
    }
    cancelTesting(tabId);
    state.phase = "original";
    state.selectedHost = "";
    state.lastError = "";
    state.pendingCandidateMaintenance = false;
    state.passthroughReason = "baseline-akamai";
    if (state.ruleInstalled) await clearRule(tabId);
    chrome.tabs.sendMessage(tabId,{type:'startup-ready',path:state.observedVideoPath}).catch(() => {});
    await setBadge(tabId, "original");
    return;
  }
  state.passthroughReason = "";
  if (settings.mode === "manual" && isCdnTargetHost(settings.manualHost)) {
    cancelTesting(tabId);
    state.lastError = "";
    if (state.phase === "manual" && state.selectedHost === settings.manualHost
      && !state.nativeRuleDirty
      && [...state.observedHosts].every(host => state.appliedSourceHosts.has(host))) return;
    await applyTarget(tabId, settings.manualHost, "manual");
    return;
  }
  if (settings.disabledHosts.includes(state.selectedHost)) {
    cancelTesting(tabId);
    state.results = state.results.filter((item) => !settings.disabledHosts.includes(item.host));
    state.selectedHost = "";
    await clearRule(tabId);
  }
  if (forceRetest) return runBenchmark("manual");
  if (!state.selectedHost || !state.results.length) {
    if (!await hydrateFromCache(tabId, settings)) {
      if (tabStates.get(tabId) !== state) return;
      // SSR may advertise a different quality/signature from the actual HD
      // player request. History only prioritizes candidates; validate the
      // actual track within the shared startup budget before applying it.
      if (state.trackKinds.size && !state.observedVideoPath) return;
      const startup = startupSelect(tabId);
      if (backgroundBenchmark) { startup.catch(() => {}); return null; }
      return startup;
    }
    return;
  }
  if (state.nativeRuleDirty || (state.phase !== "active" && state.phase !== "verifying" && state.phase !== "testing")
    || (!state.pendingCandidateMaintenance && !state.testing
      && [...state.observedHosts].some(host => !state.appliedSourceHosts.has(host)))) {
    await applyTarget(tabId, state.selectedHost, "active");
  }
}

function pageVideoKey(pageUrl, sourceUrl) {
  try {
    const page = new URL(String(pageUrl || ""));
    const part = Math.max(1, Number.parseInt(page.searchParams.get("p"), 10) || 1);
    return `${page.origin}${page.pathname.replace(/\/$/, "")}?p=${part}&ep_id=${page.searchParams.get("ep_id") || ""}`;
  } catch {
    try {
      const media = new URL(String(sourceUrl || ""));
      return `${media.hostname}${media.pathname}`;
    } catch {
      return "";
    }
  }
}

async function rememberMedia(tabId, urls, { source = "page", observed = false, requested = false, pageUrl = "", tracks = [], originals = [] } = {}) {
  const state = stateFor(tabId);
  const order = ++state.mediaOrder;
  const validUrls = [...new Set((Array.isArray(urls) ? urls : []).filter(isMediaUrl))];
  if (!validUrls.length) return;
  for (const track of (Array.isArray(tracks) ? tracks : []).slice(0, 128)) {
    if (isMediaUrl(track?.url) && ["video", "audio"].includes(track.kind)) {
      state.trackKinds.set(new URL(track.url).pathname, track.kind);
      if (Number(track.bandwidth)>0) state.trackRates.set(new URL(track.url).pathname,Number(track.bandwidth));
      if (state.trackRates.size > 512) state.trackRates.delete(state.trackRates.keys().next().value);
      if (track.kind === 'video' && Array.isArray(track.backups) && track.backups.length) {
        state.backupUrls.set(track.url, track.backups.filter(isMediaUrl).slice(0,8));
        if (state.backupUrls.size > 128) state.backupUrls.delete(state.backupUrls.keys().next().value);
      }
      if (state.trackKinds.size > 512) state.trackKinds.delete(state.trackKinds.keys().next().value);
      // Retain host-only candidates from the complete video descriptor, without
      // promoting another advertised quality to the actual benchmark source.
      const host = new URL(track.url).hostname.toLowerCase();
      if (track.kind === "video" && isCdnTargetHost(host) && state.observedHosts.size < 12) {
        if (!state.observedHosts.has(host) && state.results.length
          && !state.results.some(item => item.host === host)) state.pendingCandidateMaintenance = true;
        state.observedHosts.add(host);
      }
    }
  }
  const kind = url => state.trackKinds.get(new URL(url).pathname) || "unknown";
  // Requests can precede DASH metadata. Keep bounded evidence, not a guessed
  // track. Only replay a request once the server identifies its path as video.
  if (requested || observed) {
    for (const url of validUrls.filter(url => kind(url) === 'unknown')) {
      state.pendingMedia.set((requested ? 'request:' : 'response:') + url,
        {url, source, observed, requested, pageUrl, originals, order});
      if (state.pendingMedia.size > 128) state.pendingMedia.delete(state.pendingMedia.keys().next().value);
    }
    if (requested && validUrls.some(url => kind(url) === 'video')) state.lastVideoRequestOrder = order;
  } else {
    const classified = [...state.pendingMedia.entries()].filter(([,item]) => kind(item.url) !== 'unknown');
    for (const [key] of classified) state.pendingMedia.delete(key);
    const videos = classified.map(([,item]) => item).filter(item => kind(item.url) === 'video');
    const request = videos.filter(item => item.requested && item.order > state.lastVideoRequestOrder)
      .sort((a,b) => b.order-a.order)[0];
    const path = request ? new URL(request.url).pathname
      : state.requestedVideoUrl ? new URL(state.requestedVideoUrl).pathname : '';
    const response = videos.filter(item => item.observed && (!path || new URL(item.url).pathname === path))
      .sort((a,b) => b.order-a.order)[0];
    if (request || response) {
      if (request) await rememberMedia(tabId, [request.url], request);
      if (tabStates.get(tabId) !== state) return;
      if (response) await rememberMedia(tabId, [response.url], response);
      return;
    }
  }
  if (requested) {
    const current = validUrls.find(url => kind(url) === 'video');
    if (current) { state.requestedVideoUrl = current; state.originalHost = new URL(current).hostname; }
    if (current && current.length<=1600 && state.nativeTarget
      && new URL(current).pathname===new URL(state.nativeTarget.url).pathname) {
      // playurl can re-sign the same track during a retry. Refresh only exact
      // observed aliases, keeping the already-verified destination's own URL.
      if (new URL(current).hostname===BILI_AKAMAI_HOST) state.nativeTarget.source=current;
      const alias=[current,...(state.backupUrls.get(current)||[])].find(url=>url!==state.nativeTarget.source
        && url.length<=1600 && new URL(url).pathname===new URL(state.nativeTarget.url).pathname);
      const sources=[...new Set([state.nativeTarget.source,...(alias?[alias]:[])])];
      if (JSON.stringify(sources)!==JSON.stringify(state.nativeTarget.sources)) {
        state.nativeTarget.sources=sources;state.nativeRuleDirty=true;
      }
    }
  }
  // A late completion for the previous quality must not take track ownership
  // back from the newest real request, or invalidate its recovery/probes.
  const requestedPath = state.requestedVideoUrl && new URL(state.requestedVideoUrl).pathname;
  const relevantUrls = validUrls.filter(url => !observed || !requestedPath || kind(url) !== 'video'
    || new URL(url).pathname === requestedPath);
  if (!relevantUrls.length) return;
  const weight = url => ({ video: 0, audio: 2 }[kind(url)] ?? 1);
  const valid = relevantUrls.sort((left, right) => weight(left) - weight(right)).slice(0, 4);
  for (const item of (Array.isArray(originals) ? originals : []).slice(0, 8)) {
    if (!valid.includes(item?.url) || !isMediaUrl(item.originalUrl)
      || new URL(item.url).pathname !== new URL(item.originalUrl).pathname) continue;
    if (kind(item.url) === "video" && Number.isSafeInteger(item.startByte) && item.startByte >= 0 && item.startByte <= 2 ** 40) {
      state.probeOffsets.set(new URL(item.url).pathname, item.startByte);
      if (state.probeOffsets.size > 512) state.probeOffsets.delete(state.probeOffsets.keys().next().value);
      state.originalHost = new URL(item.originalUrl).hostname;
    }
  }
  const videoUrls = valid.filter(url => kind(url) === "video");
  if (observed && videoUrls.length && !state.requestedVideoUrl
    && new URL(videoUrls[0]).pathname !== state.observedVideoPath
    && !originals.some(item => item?.url === videoUrls[0] && isMediaUrl(item.originalUrl))) {
    state.originalHost = new URL(videoUrls[0]).hostname;
  }
  const retained = state.sourceUrls.filter(isMediaUrl);
  // Track descriptors come from playurl, never guessed from filename numbers.
  // Recent audio completions cannot replace the actual video benchmark source.
  state.sourceUrls = [...new Set([
    ...(state.requestedVideoUrl ? [state.requestedVideoUrl] : []),
    ...(observed || requested ? videoUrls : []),
    ...retained.filter(url => kind(url) === "video"), ...videoUrls,
    ...valid.filter(url => kind(url) === "unknown"),
    ...retained.filter(url => kind(url) === "unknown"),
    ...valid.filter(url => kind(url) === "audio"),
  ])].slice(0, 8);
  if ((observed || requested) && videoUrls.length) {
    const actualPath = new URL(videoUrls[0]).pathname;
    if (actualPath !== state.observedVideoPath) {
      cancelTesting(tabId); state.verifiedHosts.clear();
      state.lastRoutedVideo=null;state.lastRoutedAudio=null;
      state.lastMaintenanceAttemptAt = 0;
      state.results = state.results.map(item => ({...item, measuredThisVideo:false}));
      state.actualHost = ''; state.actualHostSource = ''; state.healthyRoute = false;
      state.nativeTarget = null;
      if (!state.earlyRouting && (state.selectedHost || state.ruleInstalled)) { state.selectedHost = ''; await clearRule(tabId); }
      // A playing quality switch does not hold playback for another startup
      // gate; maintenance validates its new track once the buffer is safe.
      if (!state.earlyRouting && (!state.startupDeadline || Date.now() < state.startupDeadline)) state.startupAttempted = false;
    }
    state.observedVideoPath = actualPath;
  }
  const nextVideoKey = pageVideoKey(pageUrl || state.pageUrl, valid[0])
    + (state.observedVideoPath ? `\n${state.observedVideoPath}` : "");
  if (nextVideoKey && nextVideoKey !== state.videoKey) {
    state.videoKey = nextVideoKey;
    state.verifiedVideoKey = "";
  }
  if (pageUrl) state.pageUrl = String(pageUrl);
  for (const value of valid) {
    const host = new URL(value).hostname.toLowerCase();
    if (!state.observedHosts.has(host) && isCdnTargetHost(host) && state.results.length
      && !state.results.some(item => item.host === host)) state.pendingCandidateMaintenance = true;
    state.observedHosts.add(host);
  }
  state.originalHost ||= new URL(valid[0]).hostname.toLowerCase();
  state.discoverySource = String(source || "page").slice(0, 40);
  state.lastDetectedAt = Date.now();
  const priority = value => ({'network-response':3, 'page-response':2}[value] || 1);
  if (observed && priority(source) >= priority(state.actualHostSource)
    && (videoUrls.length || (!state.observedVideoPath && kind(valid[0]) !== "audio"))) {
    state.actualHost = new URL((videoUrls[0] || valid[0])).hostname.toLowerCase();
    state.actualHostSource = source;
  }
  await honorMode(tabId);
  if (!state.earlyRouting && !state.testing && state.selectedHost && tabStates.get(tabId) === state) {
    chrome.tabs.sendMessage(tabId,{type:'startup-ready',path:state.observedVideoPath}).catch(() => {});
  }
  await publish(tabId);
}

async function resetForNavigation(tabId, pageUrl) {
  const state = stateFor(tabId);
  state.navigationGeneration += 1;
  cancelTesting(tabId);
  state.runId += 1;
  state.testing = null;
  state.sourceUrls = [];
  state.trackKinds.clear();
  state.observedVideoPath = "";
  state.requestedVideoUrl = "";
  state.pendingMedia.clear();
  state.earlyRouting=false;state.routeBypass=false;state.earlyOriginalHost='';state.lastPassiveAt=0;
  state.lastPassiveSavedAt=0;state.recoveryAttemptedHosts.clear();state.recoveryTargetAt=0;
  state.lastRouteRequestOrder=0;state.lastRoutedVideo=null;
  state.lastAudioRequestOrder=0;state.lastRoutedAudio=null;
  state.playbackObserved=false;
  state.mediaOrder = 0;
  state.lastVideoRequestOrder = 0;
  state.cacheLoaded = false;
  state.probeOffsets.clear();
  state.appliedSourceHosts.clear();
  state.pendingCandidateMaintenance = false;
  state.passthroughReason = "";
  state.phase = "waiting";
  state.originalHost = "";
  state.actualHost = "";
  state.actualHostSource = "";
  state.selectedHost = "";
  state.results = [];
  state.lastTestedAt = 0;
  state.lastQuickTestedAt = 0;
  state.lastVerifiedAt = 0;
  state.lastLightVerifiedAt = 0;
  state.lightVerifiedVideoKey = '';
  state.lastMaintenanceAttemptAt = 0;
  state.healthyRoute = false;
  state.lastPlayhead = 0;
  state.lastRecoveryAt = 0;
  state.recovering = null;
  state.observedHosts.clear();
  state.failedHosts.clear();
  state.discoverySource = "";
  state.lastDetectedAt = 0;
  state.pageUrl = String(pageUrl || "");
  state.videoKey = pageVideoKey(pageUrl, "");
  state.verifiedVideoKey = "";
  state.verifiedHosts.clear();
  state.backupUrls.clear();
  state.trackRates.clear();
  state.nativeTarget = null;
  state.extendedRecoveryHosts.clear();
  state.startupAttempted = false;
  state.startupDeadline = 0;
  await clearRule(tabId);
  await setBadge(tabId, "waiting");
  await publish(tabId);
}

function markHostFailed(state, host, reason) {
  state.tailCacheProof = null;
  const failed = resultFromTiming({
    host, ok: false, status: 0, bytes: 0, elapsedMs: 1, error: reason, stage: "verify",
  });
  failed.sampledAt = Date.now();
  failed.measuredThisVideo = true;
  state.verifiedHosts.delete(host);
  state.results = mergeResults(state.results, [failed]);
}

function currentBufferWarning(state, message) {
  const activity=message?.activity, age=Date.now()-message?.observedAt;
  if (!state || !message?.pageUrl || !state.pageUrl || !Number.isFinite(message.observedAt) || !Number.isFinite(age) || age<0 || age>3000
    || pageVideoKey(message.pageUrl,'')!==pageVideoKey(state.pageUrl,'')
    || message.path!==state.observedVideoPath || !isCdnTargetHost(message.targetHost)
    || message.targetHost!==state.selectedHost || !activity || activity.visible!==true
    || activity.paused!==false || activity.seeking!==false || activity.ended!==false
    || !Number.isFinite(activity.currentTime) || activity.currentTime<=0
    || !Number.isFinite(activity.bufferedAhead) || activity.bufferedAhead<=0 || activity.bufferedAhead>=8) return false;
  // A new policy is not yet a trial until the player requests this video on
  // it. Do not spend another candidate on buffered evidence from the old route.
  return !state.earlyRouting || state.lastRoutedVideo?.host===message.targetHost
    && state.lastRoutedVideo.path===message.path;
}

function currentTransferFailure(state, message) {
  return !message?.host || message.path===state.observedVideoPath
    && (!state.selectedHost || message.host===state.selectedHost)
    && (!state.actualHost || message.host===state.actualHost);
}

function currentNativeStartupFailure(state, message, actual, recovering = false) {
  const activity=message?.activity,age=Date.now()-message?.observedAt,video=state.lastRoutedVideo;
  if(message?.reason!=='startup-native-zero-response'||message.kind!=='video'||message.status!==0
    || !['abort','timeout'].includes(message.nativeEvent)||!Number.isSafeInteger(message.aborts)||message.aborts<1
    || !Number.isFinite(message.elapsedMs)||message.elapsedMs<1800||!state.earlyRouting||state.playbackObserved
    || !message.pageUrl||!state.pageUrl||pageVideoKey(message.pageUrl,'')!==pageVideoKey(state.pageUrl,'')
    || !Number.isFinite(message.observedAt)||!Number.isFinite(age)||age<0||age>3000
    || !activity||activity.visible!==true||activity.paused!==false||activity.seeking!==false
    || activity.ended!==false||activity.userInteracting!==false||activity.hasPlayed!==false
    || activity.totalFrames!==0||activity.displayedFrames!==0||activity.readyState!==0
    || !Number.isFinite(activity.currentTime)||activity.currentTime<0||activity.currentTime>=.01
    || activity.bufferedAhead!==0)return false;
  // The failure must belong to a real current video request. During the
  // internal recovery only, that same failed host may have been deselected.
  const currentTarget=actual.hostname===state.selectedHost
    || recovering&&state.routeBypass&&!state.selectedHost&&state.failedHosts.has(actual.hostname);
  return currentTarget && actual.pathname===state.observedVideoPath
    && video?.path===actual.pathname && video.host===actual.hostname;
}

function currentAudioFailure(state, message, actual, recovering = false) {
  const activity=message.activity,age=Date.now()-message.observedAt,audio=state.lastRoutedAudio,video=state.lastRoutedVideo;
  const startup=message.reason==='startup-audio-zero-response';
  if((!startup&&message.reason!=='repeated-zero-response')||message.status!==0||!state.earlyRouting
    ||!message.pageUrl||!state.pageUrl||pageVideoKey(message.pageUrl,'')!==pageVideoKey(state.pageUrl,'')
    ||!Number.isFinite(message.observedAt)||!Number.isFinite(age)||age<0||age>3000
    ||!activity||activity.visible!==true||activity.paused!==false||activity.seeking!==false
    ||activity.ended!==false||activity.userInteracting!==false
    ||!Number.isFinite(activity.currentTime)||!Number.isFinite(activity.bufferedAhead)
    ||!Number.isInteger(activity.readyState))return false;
  if(startup){
    // A decoder/element/quality reset is not another first-ever start. Require
    // explicit frame evidence, not missing counters coerced to zero.
    if(state.playbackObserved||activity.hasPlayed!==false||activity.displayedFrames!==0
      ||activity.currentTime<0||activity.currentTime>=.01||activity.bufferedAhead!==0
      ||activity.readyState<0||activity.readyState>1)return false;
  }else if(activity.currentTime<=0||activity.bufferedAhead<=0
    ||activity.readyState<2||activity.readyState>4)return false;
  // Audio is actionable only as an independently observed part of this current
  // video. It never replaces the video identity or supplies video throughput.
  const currentTarget=actual.hostname===state.selectedHost
    || recovering&&startup&&state.routeBypass&&!state.selectedHost&&state.failedHosts.has(actual.hostname);
  return currentTarget && message.videoPath===state.observedVideoPath
    && video?.path===message.videoPath && video.host===actual.hostname
    && audio?.path===actual.pathname && audio.host===actual.hostname && audio.videoPath===message.videoPath;
}

async function recoverFromStall(tabId, reason = "stall", warning, confirmedFailedHost = '') {
  const state = tabStates.get(tabId);
  if (!state) return null;
  const pendingRunId = state.runId;
  const settings = await readSettings();
  if (tabStates.get(tabId) !== state || state.runId !== pendingRunId) return null;
  if (!currentTransferFailure(state,warning)) return null;
  if (!settings.enabled || settings.mode !== "auto") return null;
  if (reason==='startup-audio-zero-response'
    && !currentAudioFailure(state,warning,new URL(warning.url),true)) return null;
  if (reason==='startup-native-zero-response'
    && !currentNativeStartupFailure(state,warning,new URL(warning.url),true)) return null;
  // Falling buffer is a warning, not a failed transfer. Change future requests
  // only: no player nudge, failure label, or additional competing download.
  if (reason === 'buffer-low') {
    if (!currentBufferWarning(state,warning)) return null;
    const retainedTail=state.tailCacheProof;
    state.tailCacheProof = null;
    if (retainedTail) {
      // A genuine drain warning contradicts the healthy-tail exception even
      // when the normal cooldown/finite queue prevents choosing another host.
      await persistStateCache(state,'');
      if (tabStates.get(tabId)!==state || state.runId!==pendingRunId || !currentBufferWarning(state,warning)) return null;
    }
    if (Date.now()-state.recoveryTargetAt<8000) return null;
    if (!state.earlyRouting && (state.originalHost === BILI_AKAMAI_HOST || state.nativeTarget)) return null;
    const next = rankResults(state.results, state.originalHost).find(item =>
      item.host !== (state.actualHost || state.originalHost) && item.host !== state.selectedHost
      && item.measuredThisVideo && state.verifiedHosts.has(item.host)
      && !state.recoveryAttemptedHosts.has(item.host)
      && !state.failedHosts.has(item.host) && !settings.disabledHosts.includes(item.host));
    const host=next?.host || (state.earlyRouting ? emergencyCandidates(state,settings,1)[0] : '');
    if (!host) return null;
    cancelTesting(tabId);
    const runId=state.runId;
    if (!await applyTarget(tabId,host) || tabStates.get(tabId)!==state || state.runId!==runId) return null;
    state.recoveryAttemptedHosts.add(host);state.recoveryTargetAt=Date.now();
    // A provisional route earns cross-video cache eligibility only after its
    // own real segment completes. Merely trying it is not a speed result.
    if (next) await persistStateCache(state,host);
    return next || {host,provisional:true};
  }
  if (state.earlyRouting) return recoverEarlyRoute(tabId, state, settings, reason, confirmedFailedHost, warning);
  if (!state.earlyRouting && (state.originalHost === BILI_AKAMAI_HOST || state.nativeTarget)) return recoverNativeBackup(tabId);
  cancelTesting(tabId);
  const runId = state.runId;
  const previousSelection = state.selectedHost;
  const failingHost = state.actualHost || state.selectedHost || state.originalHost;
  if (isCdnTargetHost(failingHost)) {
    state.failedHosts.add(failingHost);
    state.verifiedHosts.delete(failingHost);
    markHostFailed(state,failingHost,`playback ${reason}`);
  }
  if (state.earlyRouting && failingHost === state.selectedHost) {
    // Stop forcing the failed route immediately. Native retries must be able
    // to use their preserved originals while bounded recovery runs.
    state.routeBypass = true;
    state.selectedHost = '';
    await publish(tabId);
    if (tabStates.get(tabId) !== state || state.runId !== runId) return null;
  }
  if (!previousSelection || !state.results.length) {
    state.startupAttempted = false; state.startupDeadline = Date.now()+2000;
    const winner = await startupSelect(tabId,{recovery:true});
    if (winner && tabStates.get(tabId) === state) requestPlaybackRecovery(tabId,state,'stall-recovery');
    return winner;
  }
  // After a gentle route update, an old in-flight transfer can still fail.
  // That is not evidence that the newly installed, not-yet-used target failed.
  const disabled = new Set(settings.disabledHosts);
  let next = rankResults(state.results, state.originalHost)
    .find((item) => !state.failedHosts.has(item.host) && !disabled.has(item.host));
  if (next && !state.verifiedHosts.has(next.host)) {
    const verification=await probeCandidates(tabId,state.sourceUrls[0],[next.host],{
      byteLimit:128*1024,timeoutMs:2000,firstSuccess:true});
    if (tabStates.get(tabId)!==state || state.runId !== runId) return null;
    state.results = mergeResults(state.results,stampResults(verification || []));
    if (!verification?.[0]?.ok) {state.failedHosts.add(next.host);next=null;}
  }
  if (next) {
    if (!await applyTarget(tabId, next.host, "active")) return null;
    await persistStateCache(state, next.host);
    requestPlaybackRecovery(tabId,state,'stall-recovery');
    return next;
  }
  state.startupAttempted = false;
  state.startupDeadline = Date.now()+2000;
  const winner = await startupSelect(tabId,{recovery:true});
  if (winner) requestPlaybackRecovery(tabId,state,'stall-recovery');
  else if (tabStates.get(tabId) === state && state.failedHosts.has(state.selectedHost)) {
    state.selectedHost = ''; state.phase = 'original'; await clearRule(tabId); await publish(tabId);
  }
  return winner;
}

// One bounded route trial, using the player's own download as the measurement.
// A starving player never competes with another batch of synthetic probes.
async function recoverEarlyRoute(tabId, state, settings, reason, confirmedFailedHost = '', warning) {
  if (!state.sourceUrls[0] || Date.now()-state.recoveryTargetAt < 8000) return null;
  cancelTesting(tabId);
  const runId=state.runId;
  const failing=state.actualHost || state.selectedHost || state.originalHost;
  if (!['route-failure','repeated-zero-response','startup-audio-zero-response','startup-native-zero-response'].includes(reason) && isCdnTargetHost(failing) && !state.failedHosts.has(failing)) {
    state.failedHosts.add(failing);markHostFailed(state,failing,`playback ${reason}`);
  }
  // Revoke failed cross-video evidence, but never cache the provisional target
  // chosen below. It earns verification only from a later real segment.
  await persistStateCache(state,'');
  if (tabStates.get(tabId)!==state || state.runId!==runId) return null;
  if (reason==='startup-audio-zero-response'
    && !currentAudioFailure(state,warning,new URL(warning.url),true)) return null;
  if (reason==='startup-native-zero-response'
    && !currentNativeStartupFailure(state,warning,new URL(warning.url),true)) return null;
  const qualified=rankResults(state.results,state.originalHost).find(item =>
    item.measuredThisVideo && state.verifiedHosts.has(item.host)
    && item.host!==state.selectedHost && item.host!==state.actualHost
    && !state.recoveryAttemptedHosts.has(item.host)
    && !state.failedHosts.has(item.host) && !settings.disabledHosts.includes(item.host));
  // Only this confirmed zero-response pair gets a different provisional trial:
  // 08CT and HW have been observed sharing a failed H2 session. This is not a
  // permanent vendor/IP verdict; qualified real playback still comes first.
  const preferredSeed=['repeated-zero-response','startup-audio-zero-response'].includes(reason)
    && confirmedFailedHost==='upos-sz-mirror08ct.bilivideo.com'
    ? 'upos-sz-mirror08c.bilivideo.com' : '';
  const host=qualified?.host || emergencyCandidates(state,settings,1,preferredSeed)[0];
  if (!host) {
    state.lastError='本视频备用线路已尝试，保留播放器原生重试';
    state.routeBypass=true;state.selectedHost='';state.phase='original';
    await publish(tabId);return null;
  }
  if (!await applyTarget(tabId,host) || tabStates.get(tabId)!==state || state.runId!==runId) return null;
  // No other host is consumed, and no throughput/ok result is fabricated.
  state.recoveryAttemptedHosts.add(host);
  state.recoveryTargetAt=Date.now();state.lastError='';
  // Startup failures, like buffered zero-response failures, change only future
  // requests. Preserve the player's pending play intent and native retry loop.
  // The existing confirmed empty-buffer recovery after playback is unchanged.
  if (!['repeated-zero-response','startup-audio-zero-response','startup-native-zero-response'].includes(reason)
    && tabStates.get(tabId)===state && state.runId===runId) {
    requestPlaybackRecovery(tabId,state,'stall-recovery');
  }
  return qualified || {host, provisional:true};
}

function requestPlaybackRecovery(tabId, state, reason) {
  chrome.tabs.sendMessage(tabId, {type:'retry-playback',reason,
    pageUrl:state.pageUrl,path:state.observedVideoPath,targetHost:state.selectedHost}).catch(() => {});
}

async function recoverNativeBackup(tabId, {retry = true, deadline = Date.now()+2000} = {}) {
  const state = tabStates.get(tabId);
  if (!state) return null;
  cancelTesting(tabId);
  const runId = state.runId;
  const source = state.nativeTarget?.source || state.sourceUrls[0];
  const settings = await readSettings();
  if (tabStates.get(tabId) !== state || state.runId !== runId || !settings.enabled || settings.mode !== 'auto') return null;
  const signedSources = (state.backupUrls.get(source) || []).filter(url => {
    return isCdnTargetHost(new URL(url).hostname) && new URL(url).pathname === new URL(source).pathname;
  });
  // Player failover can request the bilivideo backup directly. An exact rule
  // for Akamai alone then never sees the next retry. Include at most one
  // current same-track alias; each full URL is observed/server supplied.
  const alias = [state.requestedVideoUrl,...signedSources].find(url=>url && url!==source
    && isMediaUrl(url) && url.length<=1600 && new URL(url).pathname===new URL(source).pathname);
  const exactSources = [...new Set([source,...(alias ? [alias] : [])])];
  const candidates = signedSources.filter(url => {
    const host = new URL(url).hostname;
    return isCdnTargetHost(host) && !settings.disabledHosts.includes(host) && !state.failedHosts.has(host);
  });
  if (state.nativeTarget) state.failedHosts.add(state.nativeTarget.host);
  const backup = candidates.find(url => !state.failedHosts.has(new URL(url).hostname));
  const restoreOriginal = async () => {
    if (tabStates.get(tabId) !== state || state.runId !== runId) return;
    state.nativeTarget = null; state.selectedHost = ''; state.passthroughReason = 'baseline-akamai'; state.phase = 'original';
    await clearRule(tabId); await publish(tabId);
  };
  const exploreSignedBackup = async () => {
    // Recovery only: never widen an Akamai startup or invent an Akamai host
    // transform. Use the server-signed bilivideo backup as the probe's source;
    // install an exact URL only after that derived URL passes this track's
    // larger throughput sample. Eight explored hosts maximum per video.
    if (!retry || !signedSources.length || state.extendedRecoveryHosts.size >= 8 || Date.now() >= deadline) return null;
    const base = signedSources[0];
    const hosts = selectCandidates(state,settings,16)
      .filter(host=>!state.extendedRecoveryHosts.has(host) && !signedSources.some(url=>new URL(url).hostname===host))
      .slice(0,Math.min(2,8-state.extendedRecoveryHosts.size));
    if (!hosts.length) return null;
    for (const host of hosts) state.extendedRecoveryHosts.add(host);
    let timer;
    const results = await Promise.race([
      probeCandidates(tabId,base,hosts,{byteLimit:512*1024,timeoutMs:Math.max(1,deadline-Date.now()),
        firstSuccess:true,deadline,minimumKbps:(state.trackRates.get(new URL(source).pathname)||0)/1000*1.5}),
      new Promise(resolve=>{timer=setTimeout(()=>resolve(null),Math.max(0,deadline-Date.now()));}),
    ]).finally(()=>clearTimeout(timer));
    for (const controller of state.probeControllers.values()) controller.abort();
    chrome.tabs.sendMessage(tabId,{type:'cancel-probes'}).catch(()=>{});
    if (tabStates.get(tabId)!==state || state.runId!==runId) return null;
    state.results=mergeResults(state.results,stampResults(results||[]));
    const winner=rankResults(results||[])[0];
    if (!winner || Date.now()>=deadline) { for (const host of hosts) state.failedHosts.add(host); return null; }
    const target=replaceMediaHost(base,winner.host);
    if (target.length>1600) return null;
    state.nativeTarget={source,sources:exactSources,url:target,host:winner.host};state.passthroughReason='';
    if (!await applyTarget(tabId,winner.host)) return null;
    requestPlaybackRecovery(tabId,state,'native-backup');
    return winner;
  };
  if (source.length > 1600 || deadline <= Date.now()) { await restoreOriginal(); return null; }
  if (!backup) {
    const winner=await exploreSignedBackup();
    if (winner) return winner;
    await restoreOriginal(); return null;
  }
  const host = new URL(backup).hostname;
  const minimumKbps = (state.trackRates.get(new URL(source).pathname) || 0) / 1000 * 1.5;
  let timer;
  const results = await Promise.race([
    probeCandidates(tabId, backup, [host], {timeoutMs:Math.max(1,deadline-Date.now()),byteLimit:128*1024,firstSuccess:true,deadline,minimumKbps,sampleSegments:retry ? 1 : 2}),
    new Promise(resolve=>{timer=setTimeout(()=>resolve(null),Math.max(0,deadline-Date.now()));}),
  ]).finally(()=>clearTimeout(timer));
  for (const controller of state.probeControllers.values()) controller.abort();
  chrome.tabs.sendMessage(tabId,{type:'cancel-probes'}).catch(()=>{});
  if (tabStates.get(tabId) !== state || state.runId !== runId) return null;
  if (!results?.[0]?.ok || results[0].capacityKbps < minimumKbps) {
    state.failedHosts.add(host); state.verifiedHosts.delete(host);
    state.results = mergeResults(state.results,stampResults(results || []));
    const winner=await exploreSignedBackup();
    if (winner) return winner;
    await restoreOriginal(); return null;
  }
  state.nativeTarget = { source, sources:exactSources, url:backup, host };
  state.passthroughReason = '';
  state.results = mergeResults(state.results,stampResults(results));
  if (!await applyTarget(tabId,host)) return null;
  if (retry) requestPlaybackRecovery(tabId,state,'native-backup');
  return results[0];
}

async function recoverSerialized(tabId, reason, warning, confirmedFailedHost = '') {
  const state = tabStates.get(tabId);
  if (!state || state.recovering) return state?.recovering;
  if (!currentTransferFailure(state,warning)) return null;
  if (reason==='buffer-low' && !currentBufferWarning(state,warning)) return null;
  if (Date.now() - (state.lastRecoveryAt || 0) < 2000) return null;
  state.lastRecoveryAt = Date.now();
  const recovery = recoverFromStall(tabId, reason, warning, confirmedFailedHost);
  state.recovering = recovery;
  try { return await recovery; } finally { if (state.recovering === recovery) state.recovering = null; }
}

async function lightVerify(tabId, reason = "periodic") {
  const state = tabStates.get(tabId);
  if (!state) return null;
  if (state.testing || state.verificationPending) return state.testing;
  const sourceUrl = state.sourceUrls.find(isMediaUrl);
  if (!sourceUrl || !state.selectedHost) return null;
  const testedVideoKey = state.videoKey;
  const pendingRunId = state.runId;
  state.verificationPending = true;
  let settings;
  try { settings = await readSettings(); }
  finally { state.verificationPending = false; }
  if (tabStates.get(tabId) !== state || pendingRunId !== state.runId) return null;
  if (!settings.enabled || settings.mode !== "auto" || deferRecoveryMaintenance(state)) return null;
  const disabled = new Set(settings.disabledHosts);
  const ranked = rankResults(state.results, state.originalHost)
    .filter((item) => !disabled.has(item.host) && !state.failedHosts.has(item.host));
  const freshCandidate = state.pendingCandidateMaintenance && state.actualHost !== state.selectedHost
    && isCdnTargetHost(state.actualHost) && !disabled.has(state.actualHost)
    && !state.failedHosts.has(state.actualHost) ? {host:state.actualHost} : null;
  const backup = freshCandidate || ranked.find((item) => item.host !== state.selectedHost)
    || selectCandidates(state, settings, 8).filter(host => host !== state.selectedHost
      && !state.failedHosts.has(host)).map(host => ({host}))[0];
  if (!backup) return null;
  // Recent full real delivery already measures the current host. Spend only
  // the backup's small sample, rather than competing with playback again.
  const passiveCurrent = freshHealthyPlayback(state);
  const hosts = uniqueHosts([...(passiveCurrent ? [] : [state.selectedHost]), backup.host], 2);
  const operation = (async () => {
    const runId = ++state.runId;
    state.phase = "verifying";
    state.lastError = "";
    await setBadge(tabId, "verifying");
    await publish(tabId);
    const now = Date.now();
    if (runId !== state.runId) return null;
    const probeResults = await probeCandidates(tabId, sourceUrl, hosts, {
      byteLimit: ADAPTIVE_POLICY.lightProbeBytes,
      timeoutMs: ADAPTIVE_POLICY.lightProbeTimeoutMs,
      stage: "verify",
      waitForBufferSeconds: ADAPTIVE_POLICY.safeBufferSeconds,
      waitTimeoutMs: 4_000,
    });
    if (runId !== state.runId) return null;
    if (!probeResults) {
      state.phase = "active";
      await setBadge(tabId, "active");
      await publish(tabId);
      return null;
    }
    const verified = stampResults(probeResults, now);
    const currentPlayback = mergeAutomaticResults(state, verified);
    state.lastVerifiedAt = now;
    state.lastLightVerifiedAt = now;
    state.lightVerifiedVideoKey = testedVideoKey;
    state.verifiedVideoKey = testedVideoKey;
    state.pendingCandidateMaintenance = false;
    const byHost = new Map(verified.map((item) => [item.host, item]));
    const current = currentPlayback || byHost.get(state.selectedHost);
    const alternative = byHost.get(backup.host);
    const shouldSwitch = (!state.healthyRoute || !current?.ok)
      && shouldSwitchAfterVerification(current, alternative);
    const needsFull = !current?.ok && !alternative?.ok;
    if (shouldSwitch) {
      if (!await applyTarget(tabId, alternative.host, "active")) return null;
    }
    else {
      state.phase = "active";
      await setBadge(tabId, "active");
      await publish(tabId);
    }
    if (tabStates.get(tabId) !== state || runId !== state.runId) return null;
    await persistStateCache(state, state.selectedHost);
    return { needsFull, reason };
  })();
  state.testing = operation;
  let outcome;
  try {
    outcome = await operation;
  } finally {
    if (state.testing === operation) state.testing = null;
  }
  if (outcome?.needsFull) return benchmark(tabId, `verify-${reason}`);
  return outcome;
}

function activityAllowsProbe(activity) {
  return activity?.visible === true
    && activity.paused === false
    && activity.ended === false
    && activity.seeking === false
    && Number(activity.bufferedAhead) >= ADAPTIVE_POLICY.safeBufferSeconds;
}

async function maybeAdaptiveMaintenance(tabId, activity) {
  const state = tabStates.get(tabId);
  if (!state) return;
  if (state.testing || !state.sourceUrls.length || !activityAllowsProbe(activity)) return;
  if (deferRecoveryMaintenance(state)) return;
  if (state.originalHost === BILI_AKAMAI_HOST && !state.earlyRouting) return;
  const settings = await readSettings();
  if (tabStates.get(tabId) !== state) return;
  if (!settings.enabled || settings.mode !== "auto") return;
  const now = Date.now();
  // A skipped/cancelled maintenance must not become a full download every
  // heartbeat. Startup sampling and full-cache freshness are separate.
  if (state.lastMaintenanceAttemptAt && now - state.lastMaintenanceAttemptAt < 30_000) return;
  state.lastMaintenanceAttemptAt = now;
  if (!state.selectedHost) {
    if (!state.lastTestedAt || now-state.lastTestedAt >= ADAPTIVE_POLICY.failureCacheMs) await benchmark(tabId,'retry-no-winner');
    return;
  }
  if (state.lastTestedAt && now - state.lastTestedAt >= ADAPTIVE_POLICY.successCacheMs) {
    await benchmark(tabId, "cache-expired");
    return;
  }
  const newVideoNeedsVerification = Boolean(state.videoKey && (state.earlyRouting
    ? state.lightVerifiedVideoKey !== state.videoKey : state.verifiedVideoKey !== state.videoKey));
  const reviewedAt = state.earlyRouting ? state.lastLightVerifiedAt : state.lastVerifiedAt;
  const periodicVerificationDue = !reviewedAt
    || now - reviewedAt >= ADAPTIVE_POLICY.lightVerifyIntervalMs;
  if (state.pendingCandidateMaintenance || newVideoNeedsVerification || periodicVerificationDue) {
    await lightVerify(tabId, newVideoNeedsVerification ? "new-video" : "periodic");
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const run = async () => {
    const senderTabId = sender.tab?.id;
    if (CONTENT_MESSAGES.has(message?.type) && Number.isInteger(senderTabId)) {
      const context = bindContentDocument(senderTabId, message, sender);
      if (!context) return { ok: true, ignored: true };
      if (context.ready) await context.ready;
      if (!isCurrentDocument(senderTabId, context)) return { ok: true, ignored: true };
    }
    if (message?.type === 'document-resumed' && Number.isInteger(senderTabId)) return { ok: true };
    if(message?.type==='route-prepared'&&Number.isInteger(senderTabId)) {
      if(message.enabled!==true || (message.host!=='' && !isCdnTargetHost(message.host)))return {ok:true};
      const state=stateFor(senderTabId);
      if(state.pageUrl&&message.pageUrl&&pageVideoKey(state.pageUrl,'')!==pageVideoKey(message.pageUrl,''))return {ok:false};
      // Trusted ISOLATED has read the actual preferences before enabling MAIN.
      // Establish this capability before metadata can enter legacy startup.
      if(!state.earlyRouting)cancelTesting(senderTabId);
      state.earlyRouting=true;
      if(message.pageUrl)state.pageUrl=message.pageUrl;
      if(message.networkKey)state.networkKey=String(message.networkKey).slice(0,80);
      return {ok:true};
    }
    if(['route-used','route-delivered','route-failed'].includes(message?.type)&&Number.isInteger(senderTabId)) {
      if(!isMediaUrl(message.url)||!isMediaUrl(message.originalUrl)||!['video','audio'].includes(message.kind))return {ok:false};
      const actual=new URL(message.url),origin=new URL(message.originalUrl);
      if(actual.pathname!==origin.pathname||!isCdnTargetHost(actual.hostname))return {ok:false};
      const state=stateFor(senderTabId),runId=state.runId,navigationGeneration=state.navigationGeneration,settings=await readSettings();
      if(tabStates.get(senderTabId)!==state || state.navigationGeneration!==navigationGeneration
        || (message.type!=='route-used'&&state.runId!==runId))return {ok:true,cancelled:true};
      if(!settings.enabled||settings.mode==='original'||settings.disabledHosts.includes(actual.hostname))return {ok:false};
      if(state.pageUrl&&message.pageUrl&&pageVideoKey(state.pageUrl,'')!==pageVideoKey(message.pageUrl,''))return {ok:false};
      if(message.kind==='audio'){
        if(message.type==='route-used'){
          if(!state.earlyRouting||!message.pageUrl||!state.pageUrl
            ||message.videoPath!==state.observedVideoPath||state.lastRoutedVideo?.path!==message.videoPath
            ||actual.pathname===message.videoPath||state.trackKinds.get(actual.pathname)==='video'
            ||!Number.isSafeInteger(message.requestOrder)||message.requestOrder<=state.lastAudioRequestOrder)return {ok:true,ignored:true};
          state.lastAudioRequestOrder=message.requestOrder;
          state.lastRoutedAudio={host:actual.hostname,path:actual.pathname,videoPath:message.videoPath};
          state.trackKinds.set(actual.pathname,'audio');
          return {ok:true};
        }
        // Only the new zero-response transport evidence can recover audio. Keep
        // audio completions and generic errors out of the video measurement path.
        if(message.type!=='route-failed'||!currentAudioFailure(state,message,actual))return {ok:true,ignored:true};
      }
      if(message.type==='route-used'){
        const order=Number.isSafeInteger(message.requestOrder)&&message.requestOrder>0?message.requestOrder:state.lastRouteRequestOrder+1;
        if(order<=state.lastRouteRequestOrder)return {ok:true,ignored:true};
        state.lastRouteRequestOrder=order;
        if(!state.earlyRouting){cancelTesting(senderTabId);state.catalogCursor=catalogOffset(origin.pathname,state.networkKey);}
        if(state.observedVideoPath!==actual.pathname){
          cancelTesting(senderTabId);state.verifiedHosts.clear();state.verifiedVideoKey='';
          state.lastPassiveAt=0;state.lightVerifiedVideoKey='';state.lastMaintenanceAttemptAt=0;
          state.lastPassiveSavedAt=0;state.recoveryAttemptedHosts.clear();state.recoveryTargetAt=0;
          state.results=state.results.map(r=>({...r,measuredThisVideo:false}));
          state.actualHost='';state.actualHostSource='';
        }
        state.requestedVideoUrl=actual.href;state.observedVideoPath=actual.pathname;state.originalHost=origin.hostname;
        if(state.lastRoutedVideo?.host!==actual.hostname)state.tailCacheProof=null;
        if(state.lastRoutedVideo?.host!==actual.hostname||state.lastRoutedVideo?.path!==actual.pathname)state.lastRoutedAudio=null;
        state.lastRoutedVideo={host:actual.hostname,path:actual.pathname};
        state.lastDetectedAt=Date.now();
        state.trackKinds.set(actual.pathname,'video');
        if(Number(message.bandwidth)>0)state.trackRates.set(actual.pathname,Number(message.bandwidth));
        state.sourceUrls=[actual.href,...state.sourceUrls.filter(u=>u!==actual.href)].slice(0,8);
        if(message.pageUrl)state.pageUrl=message.pageUrl;
        state.videoKey=pageVideoKey(state.pageUrl,actual.href)+'\n'+actual.pathname;
        state.earlyRouting=true;state.startupAttempted=true;state.earlyOriginalHost=origin.hostname;
        if(!state.failedHosts.has(actual.hostname)&&!state.routeBypass)state.selectedHost=actual.hostname;
        state.phase=state.selectedHost?'active':'original';state.passthroughReason='';
        await publish(senderTabId);return {ok:true};
      }
      if(message.kind==='video'){
        if(state.requestedVideoUrl&&new URL(state.requestedVideoUrl).pathname!==actual.pathname)return {ok:true};
        if(!state.earlyRouting||state.observedVideoPath&&state.observedVideoPath!==actual.pathname)return {ok:true};
      }
      if(message.type==='route-failed'){
        const futureOnly=message.reason==='repeated-zero-response';
        const startupAudio=message.reason==='startup-audio-zero-response';
        const startupNative=message.reason==='startup-native-zero-response';
        if(startupAudio&&message.kind!=='audio')return {ok:true,ignored:true};
        if(startupNative&&(settings.mode!=='auto'||!currentNativeStartupFailure(state,message,actual)))return {ok:true,ignored:true};
        if((futureOnly||startupAudio) && (settings.mode!=='auto' || !Number.isSafeInteger(message.attempts) || message.attempts<2
          || !Number.isFinite(message.elapsedMs) || message.elapsedMs<3600)) return {ok:true,ignored:true};
        if(state.selectedHost&&state.selectedHost!==actual.hostname){
          if(futureOnly || state.observedVideoPath!==actual.pathname || state.failedHosts.has(actual.hostname))return {ok:true,ignored:true};
          // MAIN already suppresses this old host for the current track. Keep
          // that evidence without disturbing the newer route or its work.
          state.failedHosts.add(actual.hostname);markHostFailed(state,actual.hostname,'route failure');
          await persistStateCache(state);await publish(senderTabId);
          return {ok:true};
        }
        if(state.failedHosts.has(actual.hostname))return {ok:true,ignored:true};
        if(state.recovering && state.routeBypass && !state.selectedHost){
          state.failedHosts.add(actual.hostname);markHostFailed(state,actual.hostname,'route failure');
          return {ok:true,ignored:true};
        }
        const pendingRecovery=state.recovering;
        cancelTesting(senderTabId);state.failedHosts.add(actual.hostname);markHostFailed(state,actual.hostname,'route failure');
        const failureRunId=state.runId;
        state.recoveryTargetAt=0;state.lastRecoveryAt=0;
        state.routeBypass=true;state.selectedHost='';state.phase='original';
        await clearRule(senderTabId);
        // A future-only warning may still be publishing or saving its previous
        // target. Let that invalidated work settle before persisting the newer
        // failure and starting recovery, rather than dropping this failure on
        // the existing serialization lock or allowing its old cache write last.
        if(pendingRecovery)await pendingRecovery.catch(()=>{});
        if(tabStates.get(senderTabId)!==state || state.runId!==failureRunId
          || !state.routeBypass || state.selectedHost)return {ok:true,cancelled:true};
        await persistStateCache(state,'');await publish(senderTabId);
        if(tabStates.get(senderTabId)!==state || state.runId!==failureRunId
          || !state.routeBypass || state.selectedHost)return {ok:true,cancelled:true};
        // A confirmed request failure is actionable even before the first
        // playing event; do not wait through the startup grace + empty-buffer timer.
        await recoverSerialized(senderTabId,startupAudio||startupNative?message.reason:futureOnly?'repeated-zero-response':'route-failure',
          startupAudio||startupNative?message:undefined,actual.hostname);return {ok:true};
      }
      const bytes=Number(message.bytes),elapsed=Number(message.elapsedMs);
      if(state.failedHosts.has(actual.hostname))return {ok:true,ignored:true};
      if(bytes<1048576||!Number.isFinite(bytes)||!Number.isFinite(elapsed)||elapsed<=0||message.status<200||message.status>=300)return {ok:false};
      const sample=resultFromTiming({host:actual.hostname,ok:true,bytes,elapsedMs:elapsed,status:message.status,stage:'playback'});
      sample.ok=sample.kbps>=Number(message.bandwidth||0)/1000*1.25;
      if(!sample.ok)sample.error='sample throughput below video bitrate margin';
      sample.measuredThisVideo=true;sample.sampledAt=Date.now();
      const tailQualified=qualifiedBeforeMarginalTail(state,message,actual,sample,settings);
      state.tailCacheProof=null;
      state.results=mergeResults(state.results,[sample]);state.lastPassiveAt=Date.now();
      if(tailQualified)state.tailCacheProof={tabId:senderTabId,navigationGeneration:state.navigationGeneration,
        latestResult:state.results.find(item=>item.host===actual.hostname),qualified:tailQualified,
        videoKey:state.videoKey,networkKey:state.networkKey};
      if(sample.ok){state.verifiedHosts.add(actual.hostname);state.verifiedVideoKey=state.videoKey;state.lastVerifiedAt=Date.now();
        if(state.selectedHost===actual.hostname && Date.now()-state.lastPassiveSavedAt>=30000){
          state.lastPassiveSavedAt=Date.now();await persistStateCache(state,actual.hostname);}}
      else {
        state.verifiedHosts.delete(actual.hostname);
        if(state.selectedHost===actual.hostname){state.lastPassiveSavedAt=0;await persistStateCache(state,tailQualified?actual.hostname:'');}
      }
      await publish(senderTabId);return {ok:true};
    }
    if (message?.type === "fetch-probe" && Number.isInteger(senderTabId)) {
      return handleProbeFetch(senderTabId, message);
    }
    if (message?.type === "cancel-probe" && Number.isInteger(senderTabId)) {
      tabStates.get(senderTabId)?.probeControllers.get(message.probeId)?.abort();
      return { ok: true };
    }
    if (message?.type === "media-discovered" && Number.isInteger(senderTabId)) {
      const state = stateFor(senderTabId);
      // Navigation/worker restart may clear a preceding capability message.
      // Each trusted ISOLATED discovery carries its current policy too, so
      // metadata cannot accidentally re-enter the legacy startup benchmark.
      if (message.earlyRouting === true || isCdnTargetHost(message.preparedRouteHost)) {
        if (!state.earlyRouting) cancelTesting(senderTabId);
        state.earlyRouting = true;
      }
      if (Number(message.startupDeadline) > Date.now()) state.startupDeadline = Math.min(Date.now()+2000, Number(message.startupDeadline));
      if (message.networkKey) state.networkKey = String(message.networkKey).slice(0,80);
      await rememberMedia(senderTabId, message.urls, {
        source: message.source,
        observed: message.observed === true,
        requested: message.requested === true && message.source === "page-request",
        pageUrl: message.pageUrl,
        tracks: message.tracks,
        originals: message.originals,
      });
      return { ok: true };
    }
    if (message?.type === "media-heartbeat" && Number.isInteger(senderTabId)) {
      const state = stateFor(senderTabId);
      const time = Number(message.activity?.currentTime);
      // This latch belongs to the page/part, not a media element or quality.
      // A later zero-time heartbeat must not enable startup-only recovery.
      if(Number.isFinite(time)&&time>0 || message.activity?.hasPlayed===true
        || Number(message.activity?.displayedFrames)>0)state.playbackObserved=true;
      state.healthyRoute = Number.isFinite(time) && time > (state.lastPlayhead || 0)
        && Number(message.activity?.bufferedAhead) >= 12;
      if (Number.isFinite(time)) state.lastPlayhead = time;
      if (state.sourceUrls.length) {
        await honorMode(senderTabId);
        await maybeAdaptiveMaintenance(senderTabId, message.activity);
      } else chrome.tabs.sendMessage(senderTabId, { type: "rescan" }).catch(() => {});
      return { ok: true };
    }
    if (message?.type === "page-changed" && Number.isInteger(senderTabId)) {
      const state = tabStates.get(senderTabId);
      if (!state?.pageUrl || pageVideoKey(state.pageUrl, '') !== pageVideoKey(message.url, '')) {
        await resetForNavigation(senderTabId, message.url);
      }
      return { ok: true };
    }
    if (message?.type === "playback-stall" && Number.isInteger(senderTabId)) {
      // The startup-audio exception is earned only by the validated real audio
      // route-failed branch above, never by a generic health hint.
      if(['startup-audio-zero-response','startup-native-zero-response'].includes(message.reason))return {ok:true,ignored:true};
      await recoverSerialized(senderTabId, message.reason || 'stall', message);
      return { ok: true };
    }
    if (message?.type === "network-changed" && Number.isInteger(senderTabId)) {
      const state = stateFor(senderTabId);
      const networkKey = String(message.networkKey || '').slice(0,80);
      if (networkKey === state.networkKey) return { ok: true, ignored: true };
      state.networkKey = networkKey;
      state.lastRoutedVideo=null;state.lastRoutedAudio=null;
      state.cacheLoaded = false;
      cancelTesting(senderTabId);
      state.lastQuickTestedAt = 0;
      state.lastTestedAt = 0;
      state.lastVerifiedAt = 0;
      state.lastLightVerifiedAt = 0;
      state.lightVerifiedVideoKey = '';
      state.lastMaintenanceAttemptAt = 0;
      state.selectedHost = "";
      state.routeBypass = false;
      state.failedHosts.clear();
      state.recoveryAttemptedHosts.clear();state.recoveryTargetAt=0;
      state.verifiedHosts.clear();
      state.results = state.results.map(item => ({...item, measuredThisVideo:false}));
      state.nativeTarget = null;
      state.extendedRecoveryHosts.clear();
      state.startupAttempted = false;
      state.startupDeadline = Date.now() + 2000;
      await clearRule(senderTabId);
      if (tabStates.get(senderTabId) !== state) return { ok: true, cancelled: true };
      const settings = await readSettings();
      if (tabStates.get(senderTabId) !== state) return { ok: true, cancelled: true };
      if (state.sourceUrls.length && settings.enabled && settings.mode === "auto") {
        if (state.originalHost === BILI_AKAMAI_HOST) await honorMode(senderTabId);
        else await benchmark(senderTabId, "network-change");
      } else await honorMode(senderTabId);
      return { ok: true };
    }
    const tabId = Number(message?.tabId);
    if (message?.type === "get-state" && Number.isInteger(tabId)) {
      if (!tabStates.has(tabId)) chrome.tabs.sendMessage(tabId, { type: "rescan" }).catch(() => {});
      return { settings: await readSettings(), state: publicTabState(tabStates.get(tabId)) };
    }
    if (message?.type === "set-settings" && Number.isInteger(tabId)) {
      const commandState = tabStates.get(tabId);
      const previousSettings = await readSettings();
      if (commandState?.originalHost === BILI_AKAMAI_HOST && message.settings?.mode === 'manual'
        && !commandState.earlyRouting
        && commandState.nativeTarget?.host !== message.settings.manualHost) {
        return {ok:false,error:'此视频仅能固定已验证的同轨原生备用，不能盲目替换 Akamai 主机。'};
      }
      const settings = await writeSettings(message.settings);
      for(const state of tabStates.values())state.tailCacheProof=null;
      // Explicit manual intent supersedes pending automatic work on every
      // affected tab. Routine manual heartbeats must not cancel test-host.
      if(settings.enabled && settings.mode==='manual' && (!previousSettings.enabled
        || previousSettings.mode!=='manual' || previousSettings.manualHost!==settings.manualHost)) {
        for(const [id,state] of tabStates)if(state.testing || state.verificationPending || state.recovering)cancelTesting(id);
      }
      if(commandState?.earlyRouting && settings.enabled && settings.mode==='auto'
        && (!previousSettings.enabled || previousSettings.mode!=='auto')) {
        commandState.routeBypass=false;commandState.selectedHost='';
      }
      if (!settings.enabled || settings.mode !== "auto") {
        await Promise.all([...tabStates.keys()].filter((id) => id !== tabId).map((id) => honorMode(id)));
      }
      if (commandState && tabStates.get(tabId) !== commandState) return { ok: true, settings, state: null, cancelled: true };
      await honorMode(tabId, { forceRetest: message.forceRetest === true, backgroundBenchmark: true });
      if (message.applyNow === true) {
        chrome.tabs.sendMessage(tabId, { type: "retry-playback", reason: "manual-switch" }).catch(() => {});
      }
      return { ok: true, settings, state: publicTabState(tabStates.get(tabId)) };
    }
    if (message?.type === 'test-host' && Number.isInteger(tabId)) {
      const state = tabStates.get(tabId);
      if (!state?.sourceUrls.length || !isCdnTargetHost(message.host)) return {ok:false,error:'尚未识别视频或节点无效。'};
      if (state.testing) return {ok:false,error:'已有验证任务正在进行。'};
      if (state.originalHost === BILI_AKAMAI_HOST && !state.earlyRouting) return {ok:false,error:'Akamai 仅使用本视频签发的原生备用。'};
      const settings=await readSettings();
      if (!settings.enabled || tabStates.get(tabId)!==state || state.testing) return {ok:false,error:'优化已关闭、页面已变化或验证正在进行。'};
      const retainedTail=state.tailCacheProof;
      state.tailCacheProof=null;
      const runId=++state.runId;
      const phase=state.phase;
      const operation=(async () => {
        if (retainedTail) {
          await persistStateCache(state,'');
          if (tabStates.get(tabId)!==state || runId!==state.runId) return {ok:false,error:'验证已取消。'};
        }
        state.phase='verifying'; await publish(tabId);
        const results=await probeCandidates(tabId,state.sourceUrls[0],[message.host],{
          byteLimit:256*1024,timeoutMs:5000,stage:'verify',waitForBufferSeconds:12,waitTimeoutMs:0});
        if (tabStates.get(tabId)!==state || runId!==state.runId) return {ok:false,error:'验证已取消。'};
        if (!results) return {ok:false,error:'缓冲不足 12 秒，未进行额外下载。'};
        state.results=mergeResults(state.results,stampResults(results));
        await persistStateCache(state); return {ok:true};
      })();
      state.testing=operation;
      let outcome;
      try { outcome=await operation; } finally {
        if (state.testing===operation) state.testing=null;
        if (tabStates.get(tabId)===state && state.runId===runId) {state.phase=phase;await publish(tabId);}
      }
      return {...outcome,state:publicTabState(state)};
    }
    if (message?.type === "retest" && Number.isInteger(tabId)) {
      const state = stateFor(tabId);
      if (!state.sourceUrls.length) return { ok: false, error: "尚未发现视频请求，请先开始播放。" };
      const settings = await writeSettings({ ...await readSettings(), enabled: true, mode: "auto", manualHost: "" });
      if (tabStates.get(tabId) !== state) return { ok: true, settings, state: null, cancelled: true };
      const retainedTail = state.tailCacheProof;
      cancelTesting(tabId);
      const runId = state.runId;
      if (retainedTail) {
        // Explicit remeasurement ends this one-tail exception immediately,
        // even when the normal all-failed retest keeps the current route.
        await persistStateCache(state, '');
        if (tabStates.get(tabId) !== state || state.runId !== runId) return { ok: true, settings, state: null, cancelled: true };
      }
      state.lastTestedAt = 0;
      state.lastVerifiedAt = 0;
      state.failedHosts.clear();
      await benchmark(tabId, "manual");
      return { ok: true, settings, state: publicTabState(state) };
    }
    return { ok: false };
  };
  run().then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  closedTabs.add(tabId);
  tabDocuments.delete(tabId);
  discardPlayback(tabId).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const document = tabDocuments.get(tabId);
  const url = changeInfo.url || tab?.url || '';
  if (url && !isBiliPage(url)) {
    if (document?.id) { document.retired.add(document.id); document.id = ''; document.suspended = true; }
    discardPlayback(tabId).catch(() => {});
    setBadge(tabId, 'waiting');
    return;
  }
  if (document && url && pageVideoKey(url, '') !== document.pageKey) {
    document.pageKey = pageVideoKey(url, '');
    document.ready = resetForNavigation(tabId, url);
    document.ready.catch(() => {});
    return;
  }
  if (changeInfo.status !== 'loading') return;
  if (document) {
    // Bilibili history.replaceState may emit loading without creating another
    // document. With the same playback identity, keep the active recovery and
    // failed set intact. A real reload is identified by its new documentId.
    const state = tabStates.get(tabId);
    if (url && state?.earlyRouting && !state.ruleInstalled) return;
    // Without URL access, clear possible legacy rules immediately and stop
    // pending work. Only a browser-confirmed active incumbent can resume it.
    document.suspended = !url;
    cancelTesting(tabId);
    document.ready = clearRule(tabId);
    document.ready.catch(() => {});
    return;
  }
  // Legacy callers without document identity cannot distinguish a reload from
  // leaving host access; retain the conservative cleanup behavior.
  discardPlayback(tabId).catch(() => {});
  setBadge(tabId, 'waiting');
});

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  if (!stored[SETTINGS_KEY]) await writeSettings(DEFAULT_SETTINGS);
});

const requestObserver = attachRequestObserver({ getState:tabId => tabStates.get(tabId),
  recover:recoverSerialized, publish, rescan:tabId => chrome.tabs.sendMessage(tabId,{type:'rescan'}).catch(() => {}) });
